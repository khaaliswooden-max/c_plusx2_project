// filepath: examples/xor_mlp.cpp
// XOR Neural Network Training Example
// Phase 3: Demonstrates automatic differentiation for deep learning
//
// The XOR problem is a classic test because it's NOT linearly separable:
//   Input    Output
//   0, 0  ->   0
//   0, 1  ->   1
//   1, 0  ->   1
//   1, 1  ->   0
//
// This requires a hidden layer to learn - a single neuron cannot solve it.
#include <iostream>
#include <iomanip>
#include <vector>

#include "autograd/autograd.hpp"

using namespace micrograd::autograd;

int main()
{
    std::cout << "================================================================\n";
    std::cout << "  MicroGrad++ XOR Neural Network Training\n";
    std::cout << "  Phase 3: Automatic Differentiation in Action\n";
    std::cout << "================================================================\n\n";

    // ========================================================================
    // 1. Define the Network
    // ========================================================================
    
    // MLP: 2 inputs -> 8 hidden neurons (tanh) -> 1 output (linear)
    // The hidden layer learns to create a non-linear feature space
    // where XOR becomes linearly separable.
    MLP model(2, {8, 1});
    
    std::cout << "Network Architecture:\n";
    std::cout << "  Input:  2 neurons\n";
    std::cout << "  Hidden: 8 neurons (tanh activation)\n";
    std::cout << "  Output: 1 neuron  (linear)\n";
    std::cout << "  Total parameters: " << model.num_parameters() << "\n\n";

    // ========================================================================
    // 2. Training Data (XOR Truth Table)
    // ========================================================================
    
    std::vector<std::vector<double>> X = {
        {0.0, 0.0},
        {0.0, 1.0},
        {1.0, 0.0},
        {1.0, 1.0}
    };
    
    std::vector<double> Y = {0.0, 1.0, 1.0, 0.0};
    
    std::cout << "Training Data (XOR):\n";
    for (size_t i = 0; i < X.size(); ++i) {
        std::cout << "  [" << X[i][0] << ", " << X[i][1] << "] -> " << Y[i] << "\n";
    }
    std::cout << "\n";

    // ========================================================================
    // 3. Training Loop
    // ========================================================================
    
    const double learning_rate = 0.5;
    const int epochs = 500;
    
    SGD optimizer(model.parameters(), learning_rate);
    
    std::cout << "Training...\n";
    std::cout << std::setw(8) << "Epoch" 
              << std::setw(12) << "Loss" 
              << std::setw(40) << "Predictions\n";
    std::cout << std::string(60, '-') << "\n";
    
    for (int epoch = 0; epoch < epochs; ++epoch) {
        // Step 1: Zero gradients
        optimizer.zero_grad();
        
        // Step 2: Forward pass - compute predictions and loss
        ValuePtr total_loss = make_value(0.0);
        std::vector<double> predictions;
        
        for (size_t i = 0; i < X.size(); ++i) {
            // Create input Values
            std::vector<ValuePtr> inputs = {
                make_value(X[i][0]),
                make_value(X[i][1])
            };
            
            // Forward pass
            auto pred = model(inputs)[0];
            predictions.push_back(pred->data);
            
            // Compute loss: (pred - target)²
            auto target = make_value(Y[i]);
            total_loss = total_loss + (pred - target)->pow(2);
        }
        
        // Step 3: Backward pass - compute gradients
        total_loss->backward();
        
        // Step 4: Update parameters
        optimizer.step();
        
        // Print progress every 50 epochs
        if (epoch % 50 == 0 || epoch == epochs - 1) {
            std::cout << std::setw(8) << epoch
                      << std::setw(12) << std::fixed << std::setprecision(4) << total_loss->data
                      << "    [";
            for (size_t i = 0; i < predictions.size(); ++i) {
                std::cout << std::fixed << std::setprecision(2) << predictions[i];
                if (i < predictions.size() - 1) std::cout << ", ";
            }
            std::cout << "]\n";
        }
    }
    
    std::cout << std::string(60, '-') << "\n";

    // ========================================================================
    // 4. Final Evaluation
    // ========================================================================
    
    std::cout << "\nFinal Results:\n";
    std::cout << std::setw(10) << "Input" 
              << std::setw(10) << "Target" 
              << std::setw(12) << "Predicted"
              << std::setw(10) << "Rounded\n";
    std::cout << std::string(42, '-') << "\n";
    
    int correct = 0;
    for (size_t i = 0; i < X.size(); ++i) {
        std::vector<ValuePtr> inputs = {
            make_value(X[i][0]),
            make_value(X[i][1])
        };
        
        auto pred = model(inputs)[0];
        int rounded = pred->data > 0.5 ? 1 : 0;
        bool match = (rounded == static_cast<int>(Y[i]));
        correct += match ? 1 : 0;
        
        std::cout << "  [" << static_cast<int>(X[i][0]) << "," << static_cast<int>(X[i][1]) << "]"
                  << std::setw(10) << static_cast<int>(Y[i])
                  << std::setw(12) << std::fixed << std::setprecision(4) << pred->data
                  << std::setw(10) << rounded
                  << (match ? "  ✓" : "  ✗")
                  << "\n";
    }
    
    std::cout << std::string(42, '-') << "\n";
    std::cout << "Accuracy: " << correct << "/4 = " 
              << (correct * 100 / 4) << "%\n\n";

    // ========================================================================
    // 5. Gradient Inspection (Educational)
    // ========================================================================
    
    std::cout << "Sample Gradients (first 5 parameters):\n";
    auto params = model.parameters();
    for (size_t i = 0; i < std::min(size_t(5), params.size()); ++i) {
        std::cout << "  param[" << i << "]: data=" 
                  << std::setw(8) << std::fixed << std::setprecision(4) << params[i]->data
                  << ", grad=" 
                  << std::setw(8) << std::fixed << std::setprecision(4) << params[i]->grad
                  << "\n";
    }
    
    std::cout << "\n================================================================\n";
    std::cout << "Key Concepts Demonstrated:\n";
    std::cout << "  1. Computational graph: Each operation creates a node\n";
    std::cout << "  2. Forward pass: Compute predictions through the network\n";
    std::cout << "  3. Backward pass: Gradients flow backward via chain rule\n";
    std::cout << "  4. Parameter update: SGD adjusts weights to minimize loss\n";
    std::cout << "================================================================\n";

    return 0;
}
