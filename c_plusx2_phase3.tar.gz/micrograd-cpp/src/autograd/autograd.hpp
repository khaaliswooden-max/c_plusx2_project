// filepath: src/autograd/autograd.hpp
// Autograd Module - Convenience Header
// Phase 3: Automatic Differentiation
#pragma once

#include "value.hpp"
#include "nn.hpp"

/// @file autograd.hpp
/// @brief Include this for automatic differentiation support
/// 
/// ## What is Automatic Differentiation?
/// 
/// A technique to compute exact derivatives of any function composed of
/// elementary operations (+, *, exp, etc.), without manual derivation.
/// 
/// ### Manual Differentiation (tedious, error-prone):
/// ```
/// f(x) = (x + 3) * (x - 5)
/// f'(x) = (x + 3) + (x - 5) = 2x - 2  // Manual chain rule
/// ```
/// 
/// ### Automatic Differentiation (computed for you):
/// ```cpp
/// auto x = make_value(4.0);
/// auto f = (x + 3) * (x - 5);  // Builds computation graph
/// f->backward();               // Computes df/dx automatically
/// std::cout << x->grad;        // 6.0 (= 2*4 - 2)
/// ```
/// 
/// ## Two Modes of Autodiff
/// 
/// 1. **Forward Mode**: Compute derivatives alongside values
///    - Good for: few inputs, many outputs
///    - Complexity: O(inputs)
/// 
/// 2. **Reverse Mode** (this library): Compute derivatives backward
///    - Good for: many inputs, few outputs (neural networks!)
///    - Complexity: O(outputs)
///    - Also called: backpropagation
/// 
/// ## Usage Example: Training a Neural Network
/// 
/// ```cpp
/// #include <autograd/autograd.hpp>
/// using namespace micrograd::autograd;
/// 
/// // Create network: 2 inputs -> 4 hidden -> 1 output
/// MLP model(2, {4, 1});
/// 
/// // Training data (XOR problem)
/// std::vector<std::vector<double>> X = {{0,0}, {0,1}, {1,0}, {1,1}};
/// std::vector<double> Y = {0, 1, 1, 0};
/// 
/// // Training loop
/// SGD optimizer(model.parameters(), 0.1);
/// 
/// for (int epoch = 0; epoch < 100; ++epoch) {
///     // Zero gradients
///     optimizer.zero_grad();
///     
///     // Forward pass + loss
///     ValuePtr total_loss = make_value(0.0);
///     for (size_t i = 0; i < X.size(); ++i) {
///         auto inputs = {make_value(X[i][0]), make_value(X[i][1])};
///         auto pred = model(inputs)[0];
///         auto target = make_value(Y[i]);
///         total_loss = total_loss + (pred - target)->pow(2);
///     }
///     
///     // Backward pass
///     total_loss->backward();
///     
///     // Update weights
///     optimizer.step();
/// }
/// ```
/// 
/// ## Key Classes
/// 
/// | Class | Purpose |
/// |-------|---------|
/// | Value | Scalar with gradient tracking |
/// | Neuron | Single neuron (weights, bias, activation) |
/// | Layer | Collection of neurons |
/// | MLP | Multi-layer perceptron |
/// | SGD | Stochastic gradient descent optimizer |

namespace micrograd {
namespace autograd {
    // All types already in autograd namespace
} // namespace autograd
} // namespace micrograd
