// filepath: src/autograd/value.hpp
// Value - Scalar with Automatic Differentiation
// Phase 3: Reverse-mode autodiff (backpropagation)
//
// This is the core abstraction: a scalar value that tracks its computational
// history and can compute gradients via reverse-mode autodiff.
//
// Inspired by Karpathy's micrograd, implemented in modern C++.
#pragma once

#include <memory>
#include <vector>
#include <functional>
#include <cmath>
#include <string>
#include <unordered_set>
#include <algorithm>
#include <iostream>
#include <iomanip>
#include <sstream>

namespace micrograd {
namespace autograd {

// Forward declaration
class Value;

/// @brief Shared pointer to Value (enables shared ownership in graph)
using ValuePtr = std::shared_ptr<Value>;

/// @brief Create a new Value (convenience function)
/// @param data The scalar value
/// @param label Optional name for debugging
/// @return Shared pointer to new Value
[[nodiscard]] inline ValuePtr make_value(double data, const std::string& label = "");

// ============================================================================
// Value Class - Scalar with Gradient Tracking
// ============================================================================

/// @brief A scalar value that tracks gradients for automatic differentiation
/// 
/// ## How It Works
/// 
/// 1. **Forward Pass**: Operations build a directed acyclic graph (DAG)
///    ```cpp
///    auto a = make_value(2.0);
///    auto b = make_value(3.0);
///    auto c = a * b;  // c.data = 6.0, c._prev = {a, b}
///    ```
/// 
/// 2. **Backward Pass**: Gradients flow backward through the graph
///    ```cpp
///    c->backward();   // Computes dc/da and dc/db
///    // a->grad = 3.0 (dc/da = b)
///    // b->grad = 2.0 (dc/db = a)
///    ```
/// 
/// ## Key Concepts
/// 
/// - **grad**: Gradient of the final output with respect to this value
/// - **_prev**: Children in the computational graph (inputs to this op)
/// - **_backward**: Lambda that computes gradients for children
/// - **Topological sort**: Ensures we process nodes in correct order
/// 
/// ## Memory Model
/// 
/// Values are managed via shared_ptr for automatic cleanup and shared
/// ownership in the computational graph.
class Value : public std::enable_shared_from_this<Value>
{
public:
    double data;        ///< The scalar value
    double grad = 0.0;  ///< Gradient (d(output)/d(this))
    std::string label;  ///< Optional name for debugging

    // ========================================================================
    // Constructors
    // ========================================================================

    /// @brief Construct a Value with data and optional label
    explicit Value(double data, const std::string& label = "")
        : data(data), label(label) {}

    /// @brief Construct from children (used by operations)
    Value(double data, std::vector<ValuePtr> children, const std::string& op = "")
        : data(data), _prev(std::move(children)), _op(op) {}

    // ========================================================================
    // Backward Pass (Reverse-Mode Autodiff)
    // ========================================================================

    /// @brief Compute gradients via reverse-mode automatic differentiation
    /// 
    /// Algorithm:
    /// 1. Set this node's gradient to 1.0 (d(self)/d(self) = 1)
    /// 2. Topologically sort the graph (children before parents)
    /// 3. Process nodes in reverse order, calling _backward for each
    /// 
    /// ## Why Topological Sort?
    /// 
    /// Consider: L = (a + b) * c
    /// Graph: a, b -> (+) -> temp -> (*) -> L
    ///                        c ----^
    /// 
    /// We must compute dL/d(temp) before we can compute dL/da and dL/db.
    /// Topological sort guarantees this ordering.
    /// 
    /// ## Gradient Accumulation
    /// 
    /// If a value is used multiple times, gradients accumulate:
    /// ```cpp
    /// auto a = make_value(2.0);
    /// auto b = a + a;  // b = 2a
    /// b->backward();
    /// // a->grad = 2.0 (not 1.0!)
    /// ```
    void backward()
    {
        // Build topological order
        std::vector<Value*> topo;
        std::unordered_set<Value*> visited;
        
        std::function<void(Value*)> build_topo = [&](Value* v) {
            if (visited.find(v) == visited.end()) {
                visited.insert(v);
                for (const auto& child : v->_prev) {
                    build_topo(child.get());
                }
                topo.push_back(v);
            }
        };
        
        build_topo(this);
        
        // Set output gradient to 1
        this->grad = 1.0;
        
        // Backpropagate in reverse topological order
        for (auto it = topo.rbegin(); it != topo.rend(); ++it) {
            if ((*it)->_backward) {
                (*it)->_backward();
            }
        }
    }

    /// @brief Reset gradient to zero (call before new backward pass)
    void zero_grad()
    {
        grad = 0.0;
        for (auto& child : _prev) {
            child->zero_grad();
        }
    }

    // ========================================================================
    // Arithmetic Operations (Build Computational Graph)
    // ========================================================================

    /// @brief Addition: out = this + other
    /// 
    /// Gradient: d(out)/d(this) = 1, d(out)/d(other) = 1
    [[nodiscard]] ValuePtr operator+(const ValuePtr& other) const
    {
        auto self = const_cast<Value*>(this)->shared_from_this();
        auto out = std::make_shared<Value>(
            data + other->data,
            std::vector<ValuePtr>{self, other},
            "+"
        );
        
        // Capture by value (shared_ptr copies are cheap)
        auto self_ptr = self;
        auto other_ptr = other;
        out->_backward = [out_weak = std::weak_ptr<Value>(out), self_ptr, other_ptr]() {
            if (auto out = out_weak.lock()) {
                // d(a+b)/da = 1, d(a+b)/db = 1
                self_ptr->grad += out->grad;
                other_ptr->grad += out->grad;
            }
        };
        
        return out;
    }

    /// @brief Multiplication: out = this * other
    /// 
    /// Gradient: d(out)/d(this) = other, d(out)/d(other) = this
    [[nodiscard]] ValuePtr operator*(const ValuePtr& other) const
    {
        auto self = const_cast<Value*>(this)->shared_from_this();
        auto out = std::make_shared<Value>(
            data * other->data,
            std::vector<ValuePtr>{self, other},
            "*"
        );
        
        auto self_ptr = self;
        auto other_ptr = other;
        out->_backward = [out_weak = std::weak_ptr<Value>(out), self_ptr, other_ptr]() {
            if (auto out = out_weak.lock()) {
                // d(a*b)/da = b, d(a*b)/db = a
                self_ptr->grad += other_ptr->data * out->grad;
                other_ptr->grad += self_ptr->data * out->grad;
            }
        };
        
        return out;
    }

    /// @brief Subtraction: out = this - other
    [[nodiscard]] ValuePtr operator-(const ValuePtr& other) const
    {
        auto self = const_cast<Value*>(this)->shared_from_this();
        auto out = std::make_shared<Value>(
            data - other->data,
            std::vector<ValuePtr>{self, other},
            "-"
        );
        
        auto self_ptr = self;
        auto other_ptr = other;
        out->_backward = [out_weak = std::weak_ptr<Value>(out), self_ptr, other_ptr]() {
            if (auto out = out_weak.lock()) {
                self_ptr->grad += out->grad;
                other_ptr->grad -= out->grad;
            }
        };
        
        return out;
    }

    /// @brief Division: out = this / other
    [[nodiscard]] ValuePtr operator/(const ValuePtr& other) const
    {
        auto self = const_cast<Value*>(this)->shared_from_this();
        auto out = std::make_shared<Value>(
            data / other->data,
            std::vector<ValuePtr>{self, other},
            "/"
        );
        
        auto self_ptr = self;
        auto other_ptr = other;
        out->_backward = [out_weak = std::weak_ptr<Value>(out), self_ptr, other_ptr]() {
            if (auto out = out_weak.lock()) {
                // d(a/b)/da = 1/b, d(a/b)/db = -a/b²
                self_ptr->grad += out->grad / other_ptr->data;
                other_ptr->grad -= self_ptr->data * out->grad / (other_ptr->data * other_ptr->data);
            }
        };
        
        return out;
    }

    /// @brief Negation: out = -this
    [[nodiscard]] ValuePtr operator-() const
    {
        auto self = const_cast<Value*>(this)->shared_from_this();
        auto out = std::make_shared<Value>(
            -data,
            std::vector<ValuePtr>{self},
            "neg"
        );
        
        auto self_ptr = self;
        out->_backward = [out_weak = std::weak_ptr<Value>(out), self_ptr]() {
            if (auto out = out_weak.lock()) {
                self_ptr->grad -= out->grad;
            }
        };
        
        return out;
    }

    /// @brief Power: out = this^exp (exp is constant)
    [[nodiscard]] ValuePtr pow(double exp) const
    {
        auto self = const_cast<Value*>(this)->shared_from_this();
        auto out = std::make_shared<Value>(
            std::pow(data, exp),
            std::vector<ValuePtr>{self},
            "pow"
        );
        
        auto self_ptr = self;
        out->_backward = [out_weak = std::weak_ptr<Value>(out), self_ptr, exp]() {
            if (auto out = out_weak.lock()) {
                // d(x^n)/dx = n * x^(n-1)
                self_ptr->grad += exp * std::pow(self_ptr->data, exp - 1) * out->grad;
            }
        };
        
        return out;
    }

    // ========================================================================
    // Activation Functions
    // ========================================================================

    /// @brief Hyperbolic tangent: out = tanh(this)
    /// 
    /// tanh(x) = (e^x - e^-x) / (e^x + e^-x)
    /// d(tanh)/dx = 1 - tanh²(x)
    [[nodiscard]] ValuePtr tanh() const
    {
        auto self = const_cast<Value*>(this)->shared_from_this();
        double t = std::tanh(data);
        auto out = std::make_shared<Value>(
            t,
            std::vector<ValuePtr>{self},
            "tanh"
        );
        
        auto self_ptr = self;
        out->_backward = [out_weak = std::weak_ptr<Value>(out), self_ptr, t]() {
            if (auto out = out_weak.lock()) {
                // d(tanh(x))/dx = 1 - tanh²(x)
                self_ptr->grad += (1.0 - t * t) * out->grad;
            }
        };
        
        return out;
    }

    /// @brief ReLU: out = max(0, this)
    [[nodiscard]] ValuePtr relu() const
    {
        auto self = const_cast<Value*>(this)->shared_from_this();
        auto out = std::make_shared<Value>(
            data > 0 ? data : 0.0,
            std::vector<ValuePtr>{self},
            "relu"
        );
        
        auto self_ptr = self;
        out->_backward = [out_weak = std::weak_ptr<Value>(out), self_ptr]() {
            if (auto out = out_weak.lock()) {
                // d(relu(x))/dx = 1 if x > 0, else 0
                self_ptr->grad += (self_ptr->data > 0 ? 1.0 : 0.0) * out->grad;
            }
        };
        
        return out;
    }

    /// @brief Sigmoid: out = 1 / (1 + e^-x)
    [[nodiscard]] ValuePtr sigmoid() const
    {
        auto self = const_cast<Value*>(this)->shared_from_this();
        double s = 1.0 / (1.0 + std::exp(-data));
        auto out = std::make_shared<Value>(
            s,
            std::vector<ValuePtr>{self},
            "sigmoid"
        );
        
        auto self_ptr = self;
        out->_backward = [out_weak = std::weak_ptr<Value>(out), self_ptr, s]() {
            if (auto out = out_weak.lock()) {
                // d(sigmoid(x))/dx = sigmoid(x) * (1 - sigmoid(x))
                self_ptr->grad += s * (1.0 - s) * out->grad;
            }
        };
        
        return out;
    }

    /// @brief Exponential: out = e^this
    [[nodiscard]] ValuePtr exp() const
    {
        auto self = const_cast<Value*>(this)->shared_from_this();
        double e = std::exp(data);
        auto out = std::make_shared<Value>(
            e,
            std::vector<ValuePtr>{self},
            "exp"
        );
        
        auto self_ptr = self;
        out->_backward = [out_weak = std::weak_ptr<Value>(out), self_ptr, e]() {
            if (auto out = out_weak.lock()) {
                // d(e^x)/dx = e^x
                self_ptr->grad += e * out->grad;
            }
        };
        
        return out;
    }

    /// @brief Natural log: out = ln(this)
    [[nodiscard]] ValuePtr log() const
    {
        auto self = const_cast<Value*>(this)->shared_from_this();
        auto out = std::make_shared<Value>(
            std::log(data),
            std::vector<ValuePtr>{self},
            "log"
        );
        
        auto self_ptr = self;
        out->_backward = [out_weak = std::weak_ptr<Value>(out), self_ptr]() {
            if (auto out = out_weak.lock()) {
                // d(ln(x))/dx = 1/x
                self_ptr->grad += out->grad / self_ptr->data;
            }
        };
        
        return out;
    }

    // ========================================================================
    // Debugging
    // ========================================================================

    /// @brief String representation for debugging
    [[nodiscard]] std::string repr() const
    {
        std::ostringstream oss;
        oss << "Value(data=" << std::fixed << std::setprecision(4) << data
            << ", grad=" << grad;
        if (!label.empty()) {
            oss << ", label=" << label;
        }
        oss << ")";
        return oss.str();
    }

    friend std::ostream& operator<<(std::ostream& os, const Value& v)
    {
        return os << v.repr();
    }

    // ========================================================================
    // Graph Access (for debugging/visualization)
    // ========================================================================

    [[nodiscard]] const std::vector<ValuePtr>& children() const { return _prev; }
    [[nodiscard]] const std::string& op() const { return _op; }

private:
    std::vector<ValuePtr> _prev;           ///< Children (inputs to this op)
    std::string _op;                       ///< Operation that created this
    std::function<void()> _backward;       ///< Backward function (computes grads)
};

// ============================================================================
// Factory Function
// ============================================================================

[[nodiscard]] inline ValuePtr make_value(double data, const std::string& label)
{
    return std::make_shared<Value>(data, label);
}

// ============================================================================
// Free Function Operators (for natural syntax)
// ============================================================================

// ValuePtr + ValuePtr
[[nodiscard]] inline ValuePtr operator+(const ValuePtr& a, const ValuePtr& b)
{
    return (*a) + b;
}

// ValuePtr * ValuePtr
[[nodiscard]] inline ValuePtr operator*(const ValuePtr& a, const ValuePtr& b)
{
    return (*a) * b;
}

// ValuePtr - ValuePtr
[[nodiscard]] inline ValuePtr operator-(const ValuePtr& a, const ValuePtr& b)
{
    return (*a) - b;
}

// ValuePtr / ValuePtr
[[nodiscard]] inline ValuePtr operator/(const ValuePtr& a, const ValuePtr& b)
{
    return (*a) / b;
}

// -ValuePtr
[[nodiscard]] inline ValuePtr operator-(const ValuePtr& a)
{
    return -(*a);
}

// ValuePtr + scalar
[[nodiscard]] inline ValuePtr operator+(const ValuePtr& a, double b)
{
    return a + make_value(b);
}

// scalar + ValuePtr
[[nodiscard]] inline ValuePtr operator+(double a, const ValuePtr& b)
{
    return make_value(a) + b;
}

// ValuePtr * scalar
[[nodiscard]] inline ValuePtr operator*(const ValuePtr& a, double b)
{
    return a * make_value(b);
}

// scalar * ValuePtr
[[nodiscard]] inline ValuePtr operator*(double a, const ValuePtr& b)
{
    return make_value(a) * b;
}

// ValuePtr - scalar
[[nodiscard]] inline ValuePtr operator-(const ValuePtr& a, double b)
{
    return a - make_value(b);
}

// scalar - ValuePtr
[[nodiscard]] inline ValuePtr operator-(double a, const ValuePtr& b)
{
    return make_value(a) - b;
}

// ValuePtr / scalar
[[nodiscard]] inline ValuePtr operator/(const ValuePtr& a, double b)
{
    return a / make_value(b);
}

// scalar / ValuePtr
[[nodiscard]] inline ValuePtr operator/(double a, const ValuePtr& b)
{
    return make_value(a) / b;
}

// ============================================================================
// Math Function Wrappers
// ============================================================================

[[nodiscard]] inline ValuePtr tanh(const ValuePtr& a) { return a->tanh(); }
[[nodiscard]] inline ValuePtr relu(const ValuePtr& a) { return a->relu(); }
[[nodiscard]] inline ValuePtr sigmoid(const ValuePtr& a) { return a->sigmoid(); }
[[nodiscard]] inline ValuePtr exp(const ValuePtr& a) { return a->exp(); }
[[nodiscard]] inline ValuePtr log(const ValuePtr& a) { return a->log(); }
[[nodiscard]] inline ValuePtr pow(const ValuePtr& a, double exp) { return a->pow(exp); }

} // namespace autograd
} // namespace micrograd
