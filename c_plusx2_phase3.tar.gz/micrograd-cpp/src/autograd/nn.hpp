// filepath: src/autograd/nn.hpp
// Neural Network Building Blocks
// Phase 3: Neuron, Layer, MLP with automatic differentiation
#pragma once

#include "value.hpp"
#include <vector>
#include <random>
#include <cassert>

namespace micrograd {
namespace autograd {

// ============================================================================
// Neuron
// ============================================================================

/// @brief A single neuron: out = activation(sum(w_i * x_i) + b)
/// 
/// A neuron computes:
///   z = w[0]*x[0] + w[1]*x[1] + ... + w[n]*x[n] + b
///   out = activation(z)
/// 
/// Gradients are automatically computed via the Value class.
class Neuron
{
public:
    /// @brief Construct a neuron with nin inputs
    /// @param nin Number of input connections
    /// @param nonlin Whether to apply tanh activation (default: true)
    explicit Neuron(size_t nin, bool nonlin = true)
        : nonlin_(nonlin)
    {
        // Initialize weights with small random values
        std::random_device rd;
        std::mt19937 gen(rd());
        std::uniform_real_distribution<double> dist(-1.0, 1.0);
        
        weights_.reserve(nin);
        for (size_t i = 0; i < nin; ++i) {
            weights_.push_back(make_value(dist(gen)));
        }
        bias_ = make_value(0.0);
    }

    /// @brief Forward pass: compute output from inputs
    /// @param x Input values
    /// @return Output value (with gradient tracking)
    [[nodiscard]] ValuePtr operator()(const std::vector<ValuePtr>& x) const
    {
        assert(x.size() == weights_.size() && "Input size must match weight count");
        
        // Compute weighted sum: sum(w_i * x_i) + b
        ValuePtr act = bias_;
        for (size_t i = 0; i < weights_.size(); ++i) {
            act = act + weights_[i] * x[i];
        }
        
        // Apply activation
        return nonlin_ ? act->tanh() : act;
    }

    /// @brief Get all trainable parameters
    [[nodiscard]] std::vector<ValuePtr> parameters() const
    {
        std::vector<ValuePtr> params;
        params.reserve(weights_.size() + 1);
        for (const auto& w : weights_) {
            params.push_back(w);
        }
        params.push_back(bias_);
        return params;
    }

    /// @brief Number of parameters
    [[nodiscard]] size_t num_parameters() const
    {
        return weights_.size() + 1;
    }

private:
    std::vector<ValuePtr> weights_;
    ValuePtr bias_;
    bool nonlin_;
};

// ============================================================================
// Layer
// ============================================================================

/// @brief A layer of neurons
/// 
/// Each neuron in the layer receives the same input and produces one output.
/// Together they form a fully-connected (dense) layer.
class Layer
{
public:
    /// @brief Construct a layer with nin inputs and nout neurons
    /// @param nin Number of inputs to each neuron
    /// @param nout Number of neurons (outputs) in the layer
    /// @param nonlin Whether neurons use activation (default: true)
    Layer(size_t nin, size_t nout, bool nonlin = true)
    {
        neurons_.reserve(nout);
        for (size_t i = 0; i < nout; ++i) {
            neurons_.emplace_back(nin, nonlin);
        }
    }

    /// @brief Forward pass through the layer
    /// @param x Input values
    /// @return Vector of output values
    [[nodiscard]] std::vector<ValuePtr> operator()(const std::vector<ValuePtr>& x) const
    {
        std::vector<ValuePtr> out;
        out.reserve(neurons_.size());
        for (const auto& n : neurons_) {
            out.push_back(n(x));
        }
        return out;
    }

    /// @brief Get all trainable parameters
    [[nodiscard]] std::vector<ValuePtr> parameters() const
    {
        std::vector<ValuePtr> params;
        for (const auto& n : neurons_) {
            auto np = n.parameters();
            params.insert(params.end(), np.begin(), np.end());
        }
        return params;
    }

    /// @brief Number of neurons in this layer
    [[nodiscard]] size_t size() const { return neurons_.size(); }

private:
    std::vector<Neuron> neurons_;
};

// ============================================================================
// MLP (Multi-Layer Perceptron)
// ============================================================================

/// @brief Multi-Layer Perceptron neural network
/// 
/// An MLP is a stack of fully-connected layers:
/// ```
/// Input -> Layer1 -> Layer2 -> ... -> Output
/// ```
/// 
/// ## Example: XOR Network
/// ```cpp
/// // 2 inputs, hidden layer with 4 neurons, 1 output
/// MLP mlp(2, {4, 1});
/// 
/// auto x = {make_value(1.0), make_value(0.0)};
/// auto y = mlp(x);  // Forward pass
/// 
/// // y[0] is the output with gradient tracking
/// ```
class MLP
{
public:
    /// @brief Construct an MLP
    /// @param nin Number of inputs
    /// @param nouts Sizes of each layer (last is output size)
    /// 
    /// Example: MLP(2, {4, 4, 1}) creates:
    /// - Input: 2 features
    /// - Hidden layer 1: 4 neurons (with activation)
    /// - Hidden layer 2: 4 neurons (with activation)
    /// - Output layer: 1 neuron (no activation)
    MLP(size_t nin, std::initializer_list<size_t> nouts)
        : MLP(nin, std::vector<size_t>(nouts))
    {}

    MLP(size_t nin, const std::vector<size_t>& nouts)
    {
        std::vector<size_t> sz;
        sz.push_back(nin);
        for (auto n : nouts) {
            sz.push_back(n);
        }
        
        layers_.reserve(nouts.size());
        for (size_t i = 0; i < nouts.size(); ++i) {
            // Last layer has no activation (for regression/logits)
            bool nonlin = (i != nouts.size() - 1);
            layers_.emplace_back(sz[i], sz[i + 1], nonlin);
        }
    }

    /// @brief Forward pass through the network
    /// @param x Input values
    /// @return Output values
    [[nodiscard]] std::vector<ValuePtr> operator()(const std::vector<ValuePtr>& x) const
    {
        std::vector<ValuePtr> out = x;
        for (const auto& layer : layers_) {
            out = layer(out);
        }
        return out;
    }

    /// @brief Get all trainable parameters
    [[nodiscard]] std::vector<ValuePtr> parameters() const
    {
        std::vector<ValuePtr> params;
        for (const auto& layer : layers_) {
            auto lp = layer.parameters();
            params.insert(params.end(), lp.begin(), lp.end());
        }
        return params;
    }

    /// @brief Total number of trainable parameters
    [[nodiscard]] size_t num_parameters() const
    {
        return parameters().size();
    }

    /// @brief Zero all gradients (call before each training step)
    void zero_grad()
    {
        for (auto& p : parameters()) {
            p->grad = 0.0;
        }
    }

    /// @brief Number of layers
    [[nodiscard]] size_t num_layers() const { return layers_.size(); }

private:
    std::vector<Layer> layers_;
};

// ============================================================================
// Loss Functions
// ============================================================================

/// @brief Mean Squared Error loss
/// @param predictions Network outputs
/// @param targets Ground truth values
/// @return Scalar loss value (with gradient tracking)
[[nodiscard]] inline ValuePtr mse_loss(
    const std::vector<ValuePtr>& predictions,
    const std::vector<ValuePtr>& targets)
{
    assert(predictions.size() == targets.size());
    
    ValuePtr loss = make_value(0.0);
    for (size_t i = 0; i < predictions.size(); ++i) {
        auto diff = predictions[i] - targets[i];
        loss = loss + diff->pow(2);
    }
    return loss / static_cast<double>(predictions.size());
}

/// @brief Simple sum-of-squared-errors loss
[[nodiscard]] inline ValuePtr sse_loss(
    const std::vector<ValuePtr>& predictions,
    const std::vector<ValuePtr>& targets)
{
    assert(predictions.size() == targets.size());
    
    ValuePtr loss = make_value(0.0);
    for (size_t i = 0; i < predictions.size(); ++i) {
        auto diff = predictions[i] - targets[i];
        loss = loss + diff->pow(2);
    }
    return loss;
}

// ============================================================================
// SGD Optimizer
// ============================================================================

/// @brief Stochastic Gradient Descent optimizer
class SGD
{
public:
    /// @brief Construct SGD optimizer
    /// @param parameters Parameters to optimize (from model.parameters())
    /// @param learning_rate Step size for updates
    SGD(std::vector<ValuePtr> parameters, double learning_rate)
        : params_(std::move(parameters)), lr_(learning_rate) {}

    /// @brief Perform one optimization step
    /// 
    /// Updates each parameter: p = p - lr * grad
    void step()
    {
        for (auto& p : params_) {
            p->data -= lr_ * p->grad;
        }
    }

    /// @brief Zero all gradients
    void zero_grad()
    {
        for (auto& p : params_) {
            p->grad = 0.0;
        }
    }

    /// @brief Get/set learning rate
    [[nodiscard]] double learning_rate() const { return lr_; }
    void set_learning_rate(double lr) { lr_ = lr; }

private:
    std::vector<ValuePtr> params_;
    double lr_;
};

} // namespace autograd
} // namespace micrograd
