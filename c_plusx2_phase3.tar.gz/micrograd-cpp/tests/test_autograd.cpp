// filepath: tests/test_autograd.cpp
// Autograd Tests - Phase 3
// Verifies: computational graphs, gradients, backprop, neural networks
#include <gtest/gtest.h>
#include "autograd/autograd.hpp"
#include <cmath>

using namespace micrograd::autograd;

// ============================================================================
// Value Construction Tests
// ============================================================================

TEST(AutogradTest, Value_Construct_HasData)
{
    auto v = make_value(3.14);
    EXPECT_DOUBLE_EQ(v->data, 3.14);
    EXPECT_DOUBLE_EQ(v->grad, 0.0);
}

TEST(AutogradTest, Value_WithLabel_Correct)
{
    auto v = make_value(42.0, "answer");
    EXPECT_EQ(v->label, "answer");
}

// ============================================================================
// Basic Arithmetic Tests
// ============================================================================

TEST(AutogradTest, Add_ForwardPass_Correct)
{
    auto a = make_value(2.0);
    auto b = make_value(3.0);
    auto c = a + b;
    
    EXPECT_DOUBLE_EQ(c->data, 5.0);
}

TEST(AutogradTest, Add_Backward_Correct)
{
    auto a = make_value(2.0);
    auto b = make_value(3.0);
    auto c = a + b;
    
    c->backward();
    
    // dc/da = 1, dc/db = 1
    EXPECT_DOUBLE_EQ(a->grad, 1.0);
    EXPECT_DOUBLE_EQ(b->grad, 1.0);
}

TEST(AutogradTest, Mul_ForwardPass_Correct)
{
    auto a = make_value(2.0);
    auto b = make_value(3.0);
    auto c = a * b;
    
    EXPECT_DOUBLE_EQ(c->data, 6.0);
}

TEST(AutogradTest, Mul_Backward_Correct)
{
    auto a = make_value(2.0);
    auto b = make_value(3.0);
    auto c = a * b;
    
    c->backward();
    
    // dc/da = b = 3, dc/db = a = 2
    EXPECT_DOUBLE_EQ(a->grad, 3.0);
    EXPECT_DOUBLE_EQ(b->grad, 2.0);
}

TEST(AutogradTest, Sub_Backward_Correct)
{
    auto a = make_value(5.0);
    auto b = make_value(3.0);
    auto c = a - b;
    
    c->backward();
    
    EXPECT_DOUBLE_EQ(c->data, 2.0);
    EXPECT_DOUBLE_EQ(a->grad, 1.0);
    EXPECT_DOUBLE_EQ(b->grad, -1.0);
}

TEST(AutogradTest, Div_Backward_Correct)
{
    auto a = make_value(6.0);
    auto b = make_value(2.0);
    auto c = a / b;
    
    c->backward();
    
    EXPECT_DOUBLE_EQ(c->data, 3.0);
    // dc/da = 1/b = 0.5
    EXPECT_DOUBLE_EQ(a->grad, 0.5);
    // dc/db = -a/b² = -6/4 = -1.5
    EXPECT_DOUBLE_EQ(b->grad, -1.5);
}

TEST(AutogradTest, Neg_Backward_Correct)
{
    auto a = make_value(3.0);
    auto b = -a;
    
    b->backward();
    
    EXPECT_DOUBLE_EQ(b->data, -3.0);
    EXPECT_DOUBLE_EQ(a->grad, -1.0);
}

TEST(AutogradTest, Pow_Backward_Correct)
{
    auto a = make_value(3.0);
    auto b = a->pow(2);  // b = a²
    
    b->backward();
    
    EXPECT_DOUBLE_EQ(b->data, 9.0);
    // db/da = 2a = 6
    EXPECT_DOUBLE_EQ(a->grad, 6.0);
}

// ============================================================================
// Scalar Operations Tests
// ============================================================================

TEST(AutogradTest, AddScalar_Backward_Correct)
{
    auto a = make_value(2.0);
    auto b = a + 5.0;
    
    b->backward();
    
    EXPECT_DOUBLE_EQ(b->data, 7.0);
    EXPECT_DOUBLE_EQ(a->grad, 1.0);
}

TEST(AutogradTest, MulScalar_Backward_Correct)
{
    auto a = make_value(3.0);
    auto b = a * 4.0;
    
    b->backward();
    
    EXPECT_DOUBLE_EQ(b->data, 12.0);
    EXPECT_DOUBLE_EQ(a->grad, 4.0);
}

TEST(AutogradTest, ScalarMul_Backward_Correct)
{
    auto a = make_value(3.0);
    auto b = 4.0 * a;
    
    b->backward();
    
    EXPECT_DOUBLE_EQ(b->data, 12.0);
    EXPECT_DOUBLE_EQ(a->grad, 4.0);
}

// ============================================================================
// Activation Function Tests
// ============================================================================

TEST(AutogradTest, Tanh_ForwardBackward_Correct)
{
    auto a = make_value(0.0);
    auto b = a->tanh();
    
    b->backward();
    
    EXPECT_DOUBLE_EQ(b->data, 0.0);
    // d(tanh(0))/dx = 1 - tanh²(0) = 1 - 0 = 1
    EXPECT_DOUBLE_EQ(a->grad, 1.0);
}

TEST(AutogradTest, ReLU_Positive_Correct)
{
    auto a = make_value(3.0);
    auto b = a->relu();
    
    b->backward();
    
    EXPECT_DOUBLE_EQ(b->data, 3.0);
    EXPECT_DOUBLE_EQ(a->grad, 1.0);
}

TEST(AutogradTest, ReLU_Negative_Correct)
{
    auto a = make_value(-3.0);
    auto b = a->relu();
    
    b->backward();
    
    EXPECT_DOUBLE_EQ(b->data, 0.0);
    EXPECT_DOUBLE_EQ(a->grad, 0.0);
}

TEST(AutogradTest, Sigmoid_Forward_Correct)
{
    auto a = make_value(0.0);
    auto b = a->sigmoid();
    
    EXPECT_DOUBLE_EQ(b->data, 0.5);
    
    b->backward();
    // d(sigmoid(0))/dx = 0.5 * (1 - 0.5) = 0.25
    EXPECT_DOUBLE_EQ(a->grad, 0.25);
}

TEST(AutogradTest, Exp_Backward_Correct)
{
    auto a = make_value(0.0);
    auto b = a->exp();
    
    b->backward();
    
    EXPECT_DOUBLE_EQ(b->data, 1.0);
    EXPECT_DOUBLE_EQ(a->grad, 1.0);  // d(e^x)/dx = e^x = e^0 = 1
}

TEST(AutogradTest, Log_Backward_Correct)
{
    auto a = make_value(2.0);
    auto b = a->log();
    
    b->backward();
    
    EXPECT_NEAR(b->data, 0.693147, 1e-5);
    EXPECT_DOUBLE_EQ(a->grad, 0.5);  // d(ln(x))/dx = 1/x = 0.5
}

// ============================================================================
// Chain Rule Tests
// ============================================================================

TEST(AutogradTest, ChainRule_Simple_Correct)
{
    // f(x) = (x + 3) * (x - 5)
    // f'(x) = (x - 5) + (x + 3) = 2x - 2
    // f'(4) = 6
    auto x = make_value(4.0);
    auto f = (x + 3.0) * (x - 5.0);
    
    f->backward();
    
    EXPECT_DOUBLE_EQ(f->data, -7.0);  // (4+3)*(4-5) = 7*(-1) = -7
    EXPECT_DOUBLE_EQ(x->grad, 6.0);   // 2*4 - 2 = 6
}

TEST(AutogradTest, ChainRule_Nested_Correct)
{
    // f(x) = tanh(x * 2)
    // f'(x) = 2 * (1 - tanh²(x*2))
    auto x = make_value(0.0);
    auto f = tanh(x * 2.0);
    
    f->backward();
    
    EXPECT_DOUBLE_EQ(f->data, 0.0);
    EXPECT_DOUBLE_EQ(x->grad, 2.0);  // 2 * (1 - 0) = 2
}

// ============================================================================
// Gradient Accumulation Tests
// ============================================================================

TEST(AutogradTest, GradientAccumulation_SameVariable)
{
    // f = a + a = 2a
    // df/da = 2
    auto a = make_value(3.0);
    auto f = a + a;
    
    f->backward();
    
    EXPECT_DOUBLE_EQ(f->data, 6.0);
    EXPECT_DOUBLE_EQ(a->grad, 2.0);
}

TEST(AutogradTest, GradientAccumulation_Multiple)
{
    // f = a * a = a²
    // df/da = 2a
    auto a = make_value(3.0);
    auto f = a * a;
    
    f->backward();
    
    EXPECT_DOUBLE_EQ(f->data, 9.0);
    EXPECT_DOUBLE_EQ(a->grad, 6.0);
}

TEST(AutogradTest, GradientAccumulation_Complex)
{
    // f = a * a + a = a² + a
    // df/da = 2a + 1 = 7 when a=3
    auto a = make_value(3.0);
    auto f = a * a + a;
    
    f->backward();
    
    EXPECT_DOUBLE_EQ(f->data, 12.0);  // 9 + 3
    EXPECT_DOUBLE_EQ(a->grad, 7.0);    // 2*3 + 1
}

// ============================================================================
// Neural Network Tests
// ============================================================================

TEST(AutogradTest, Neuron_Forward_Works)
{
    Neuron n(2, true);  // 2 inputs, with activation
    
    std::vector<ValuePtr> x = {make_value(1.0), make_value(2.0)};
    auto out = n(x);
    
    // Output should be in [-1, 1] due to tanh
    EXPECT_GE(out->data, -1.0);
    EXPECT_LE(out->data, 1.0);
}

TEST(AutogradTest, Neuron_Parameters_Correct)
{
    Neuron n(3, true);  // 3 inputs
    auto params = n.parameters();
    
    // 3 weights + 1 bias = 4 parameters
    EXPECT_EQ(params.size(), 4);
}

TEST(AutogradTest, Layer_Forward_Works)
{
    Layer layer(2, 4, true);  // 2 inputs, 4 neurons
    
    std::vector<ValuePtr> x = {make_value(1.0), make_value(2.0)};
    auto out = layer(x);
    
    EXPECT_EQ(out.size(), 4);
}

TEST(AutogradTest, MLP_Forward_Works)
{
    MLP mlp(2, {4, 1});  // 2 inputs -> 4 hidden -> 1 output
    
    std::vector<ValuePtr> x = {make_value(1.0), make_value(0.0)};
    auto out = mlp(x);
    
    EXPECT_EQ(out.size(), 1);
}

TEST(AutogradTest, MLP_Parameters_Count)
{
    // 2 inputs -> 4 hidden -> 1 output
    // Hidden layer: 4 neurons * (2 weights + 1 bias) = 12 params
    // Output layer: 1 neuron * (4 weights + 1 bias) = 5 params
    // Total: 17 params
    MLP mlp(2, {4, 1});
    
    EXPECT_EQ(mlp.num_parameters(), 17);
}

TEST(AutogradTest, MLP_Backward_Works)
{
    MLP mlp(2, {4, 1});
    
    std::vector<ValuePtr> x = {make_value(1.0), make_value(0.0)};
    auto out = mlp(x);
    auto target = make_value(1.0);
    auto loss = (out[0] - target)->pow(2);
    
    loss->backward();
    
    // All parameters should have non-zero gradients (in general)
    auto params = mlp.parameters();
    bool has_nonzero_grad = false;
    for (const auto& p : params) {
        if (std::abs(p->grad) > 1e-10) {
            has_nonzero_grad = true;
            break;
        }
    }
    EXPECT_TRUE(has_nonzero_grad);
}

// ============================================================================
// Loss Function Tests
// ============================================================================

TEST(AutogradTest, MSELoss_Correct)
{
    std::vector<ValuePtr> preds = {make_value(1.0), make_value(2.0)};
    std::vector<ValuePtr> targets = {make_value(0.0), make_value(0.0)};
    
    auto loss = mse_loss(preds, targets);
    
    // MSE = ((1-0)² + (2-0)²) / 2 = (1 + 4) / 2 = 2.5
    EXPECT_DOUBLE_EQ(loss->data, 2.5);
}

TEST(AutogradTest, SSELoss_Correct)
{
    std::vector<ValuePtr> preds = {make_value(1.0), make_value(2.0)};
    std::vector<ValuePtr> targets = {make_value(0.0), make_value(0.0)};
    
    auto loss = sse_loss(preds, targets);
    
    // SSE = (1-0)² + (2-0)² = 1 + 4 = 5
    EXPECT_DOUBLE_EQ(loss->data, 5.0);
}

// ============================================================================
// Optimizer Tests
// ============================================================================

TEST(AutogradTest, SGD_Step_UpdatesParams)
{
    auto p = make_value(5.0);
    p->grad = 2.0;  // Pretend gradient
    
    SGD optimizer({p}, 0.1);
    optimizer.step();
    
    // p = p - lr * grad = 5 - 0.1 * 2 = 4.8
    EXPECT_DOUBLE_EQ(p->data, 4.8);
}

TEST(AutogradTest, SGD_ZeroGrad_Works)
{
    auto p = make_value(5.0);
    p->grad = 2.0;
    
    SGD optimizer({p}, 0.1);
    optimizer.zero_grad();
    
    EXPECT_DOUBLE_EQ(p->grad, 0.0);
}

// ============================================================================
// Integration Test: XOR Training
// ============================================================================

TEST(AutogradTest, XOR_Training_Converges)
{
    // XOR problem: NOT linearly separable, requires hidden layer
    // Input:  Output:
    // 0, 0 -> 0
    // 0, 1 -> 1
    // 1, 0 -> 1
    // 1, 1 -> 0
    
    MLP mlp(2, {4, 1});  // 2 -> 4 -> 1
    SGD optimizer(mlp.parameters(), 0.5);
    
    // Training data
    std::vector<std::vector<double>> X = {{0,0}, {0,1}, {1,0}, {1,1}};
    std::vector<double> Y = {0, 1, 1, 0};
    
    double initial_loss = 0.0;
    double final_loss = 0.0;
    
    // Training loop
    for (int epoch = 0; epoch < 200; ++epoch) {
        optimizer.zero_grad();
        
        ValuePtr total_loss = make_value(0.0);
        for (size_t i = 0; i < X.size(); ++i) {
            std::vector<ValuePtr> inputs = {
                make_value(X[i][0]), 
                make_value(X[i][1])
            };
            auto pred = mlp(inputs)[0];
            auto target = make_value(Y[i]);
            total_loss = total_loss + (pred - target)->pow(2);
        }
        
        if (epoch == 0) initial_loss = total_loss->data;
        if (epoch == 199) final_loss = total_loss->data;
        
        total_loss->backward();
        optimizer.step();
    }
    
    // Loss should decrease significantly
    EXPECT_LT(final_loss, initial_loss * 0.5);
}
