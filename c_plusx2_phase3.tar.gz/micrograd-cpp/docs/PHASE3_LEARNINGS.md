# Phase 3 Learnings: Automatic Differentiation

**Completed:** Phase 3 of MicroGrad++  
**Level:** Graduate/PhD  
**Duration:** Weeks 7-9

---

## 🎓 What You Learned

### 1. Computational Graphs

**Concept:** A directed acyclic graph (DAG) where nodes are operations and edges are data flow.

```cpp
auto a = make_value(2.0);
auto b = make_value(3.0);
auto c = a * b;        // Node: multiply
auto d = c + a;        // Node: add (note: 'a' used twice)

// Graph structure:
//     a ----+---> (*) ---> c ---> (+) ---> d
//           |                      ^
//     b ----+                      |
//                                  |
//     a -------------------------+
```

**Why DAG?**
- Directed: Data flows one way (forward)
- Acyclic: No loops (ensures finite computation)
- Graph: Values can be reused (gradient accumulation)

---

### 2. Reverse-Mode Autodiff (Backpropagation)

**Concept:** Compute gradients by traversing the graph backward from output to inputs.

**Forward mode** (not used here):
- Compute ∂output/∂input while computing output
- Good for: few inputs, many outputs
- Complexity: O(inputs)

**Reverse mode** (used in deep learning):
- Compute ∂output/∂input after forward pass
- Good for: many inputs (parameters), few outputs (loss)
- Complexity: O(outputs)

**Chain Rule:**
```
If y = f(g(x)), then dy/dx = dy/dg · dg/dx
```

**In code:**
```cpp
// f = (a * b) + c
// df/da = df/d(a*b) · d(a*b)/da = 1 · b = b
// df/db = df/d(a*b) · d(a*b)/db = 1 · a = a
// df/dc = 1

auto a = make_value(2.0);
auto b = make_value(3.0);
auto c = make_value(1.0);
auto f = a * b + c;

f->backward();
// a->grad = 3.0 (= b)
// b->grad = 2.0 (= a)
// c->grad = 1.0
```

---

### 3. Topological Sort

**Concept:** Order nodes so children are processed before parents.

**Why needed:**
- Must compute dL/d(intermediate) before dL/d(input)
- Guarantees gradients are available when needed

**Algorithm:**
```cpp
void backward() {
    // 1. Build topological order via DFS
    std::vector<Value*> topo;
    std::unordered_set<Value*> visited;
    
    std::function<void(Value*)> build_topo = [&](Value* v) {
        if (visited.find(v) == visited.end()) {
            visited.insert(v);
            for (auto& child : v->_prev) {
                build_topo(child.get());
            }
            topo.push_back(v);
        }
    };
    build_topo(this);
    
    // 2. Set output gradient
    this->grad = 1.0;
    
    // 3. Process in REVERSE order
    for (auto it = topo.rbegin(); it != topo.rend(); ++it) {
        (*it)->_backward();
    }
}
```

---

### 4. std::function and Lambda Captures

**Concept:** Store callable objects that compute local gradients.

**Lambda with captures:**
```cpp
ValuePtr operator*(const ValuePtr& other) {
    auto out = make_shared<Value>(data * other->data, {self, other});
    
    // Lambda captures self, other by value (shared_ptr copy)
    out->_backward = [self_ptr=self, other_ptr=other, 
                      out_weak=weak_ptr(out)]() {
        if (auto out = out_weak.lock()) {
            // d(a*b)/da = b
            self_ptr->grad += other_ptr->data * out->grad;
            // d(a*b)/db = a
            other_ptr->grad += self_ptr->data * out->grad;
        }
    };
    return out;
}
```

**Why weak_ptr for out?**
- Prevents circular reference: out holds lambda, lambda holds out
- `weak_ptr` breaks the cycle
- `lock()` returns nullptr if out is deleted

---

### 5. Gradient Accumulation

**Concept:** When a value is used multiple times, gradients ADD.

```cpp
// f = a + a = 2a
// df/da = 2 (not 1!)

auto a = make_value(3.0);
auto f = a + a;
f->backward();
// a->grad = 2.0

// Why? Chain rule:
// f = a + a, let's call them a₁ and a₂ (same object)
// df/da = df/da₁ + df/da₂ = 1 + 1 = 2
```

**Implementation:** Use `+=` not `=`
```cpp
self_ptr->grad += out->grad;  // ✓ Accumulates
self_ptr->grad = out->grad;   // ✗ Overwrites
```

---

### 6. Neural Network Abstractions

**Neuron:**
```cpp
class Neuron {
    vector<ValuePtr> weights;
    ValuePtr bias;
    bool nonlin;
    
    ValuePtr operator()(const vector<ValuePtr>& x) {
        ValuePtr act = bias;
        for (size_t i = 0; i < weights.size(); ++i) {
            act = act + weights[i] * x[i];
        }
        return nonlin ? act->tanh() : act;
    }
};
```

**Layer:** Collection of neurons (dense/fully-connected)
```cpp
class Layer {
    vector<Neuron> neurons;
    
    vector<ValuePtr> operator()(const vector<ValuePtr>& x) {
        vector<ValuePtr> out;
        for (auto& n : neurons) out.push_back(n(x));
        return out;
    }
};
```

**MLP:** Stack of layers
```cpp
class MLP {
    vector<Layer> layers;
    
    vector<ValuePtr> operator()(const vector<ValuePtr>& x) {
        auto out = x;
        for (auto& layer : layers) out = layer(out);
        return out;
    }
};
```

---

### 7. Training Loop Pattern

```cpp
for (int epoch = 0; epoch < epochs; ++epoch) {
    // 1. Zero gradients (prevent accumulation across batches)
    optimizer.zero_grad();
    
    // 2. Forward pass
    auto predictions = model(inputs);
    auto loss = compute_loss(predictions, targets);
    
    // 3. Backward pass (compute gradients)
    loss->backward();
    
    // 4. Update parameters
    optimizer.step();  // p = p - lr * grad
}
```

---

## 🔑 Key C++ Patterns Learned

### enable_shared_from_this
Allows getting `shared_ptr<this>` from within a method:
```cpp
class Value : public std::enable_shared_from_this<Value> {
    ValuePtr operator+(ValuePtr other) {
        auto self = shared_from_this();  // Safe!
        // ...
    }
};

// Without enable_shared_from_this:
// shared_ptr<Value>(this);  // DANGEROUS: double-delete!
```

### Lambda Lifetime Management
```cpp
// Problem: lambda might outlive captured objects
out->_backward = [out]() { ... };  // Circular ref!

// Solution: weak_ptr breaks cycle
out->_backward = [weak = weak_ptr(out)]() {
    if (auto out = weak.lock()) { ... }
};
```

### std::function Type Erasure
```cpp
std::function<void()> _backward;

// Can store any callable:
_backward = []() { ... };                    // Lambda
_backward = some_function;                    // Function ptr
_backward = std::bind(&Class::method, obj);  // Bound method
```

---

## 📊 Gradient Derivations

| Operation | Forward | Backward (local gradients) |
|-----------|---------|----------------------------|
| `a + b` | `a + b` | ∂/∂a = 1, ∂/∂b = 1 |
| `a - b` | `a - b` | ∂/∂a = 1, ∂/∂b = -1 |
| `a * b` | `a * b` | ∂/∂a = b, ∂/∂b = a |
| `a / b` | `a / b` | ∂/∂a = 1/b, ∂/∂b = -a/b² |
| `a^n` | `pow(a,n)` | ∂/∂a = n·a^(n-1) |
| `tanh(a)` | `tanh(a)` | ∂/∂a = 1 - tanh²(a) |
| `relu(a)` | `max(0,a)` | ∂/∂a = 1 if a>0, else 0 |
| `sigmoid(a)` | `1/(1+e^-a)` | ∂/∂a = σ(a)·(1-σ(a)) |
| `exp(a)` | `e^a` | ∂/∂a = e^a |
| `log(a)` | `ln(a)` | ∂/∂a = 1/a |

---

## 🔗 Zuup/Visionblox Application

| Technique | Platform Application |
|-----------|---------------------|
| **Autodiff** | Symbion: Gradient-based optimization for signal processing |
| **Computational Graph** | Aureon: Traceable scoring with full audit trail |
| **Lambda Captures** | Civium: Deferred compliance validation callbacks |
| **Neural Networks** | Orb: 3DGS parameter optimization |
| **Training Loop** | Veyra: Online learning for autonomy policies |

**Example: Aureon Explainable Scoring**
```cpp
// Every score is a Value with gradient tracking
auto technical_score = evaluate_technical(proposal);  // ValuePtr
auto cost_score = evaluate_cost(proposal);            // ValuePtr
auto past_perf = evaluate_past_performance(proposal); // ValuePtr

// Weighted combination
auto final_score = technical_score * 0.5 + cost_score * 0.3 + past_perf * 0.2;

// Explanation: How much did each factor contribute?
final_score->backward();
// technical_score->grad = 0.5 (50% weight)
// cost_score->grad = 0.3 (30% weight)
// past_perf->grad = 0.2 (20% weight)
```

---

## ➡️ Next Phase Preview

**Phase 4: Performance Optimization** will introduce:
- SIMD vectorization (AVX2)
- Memory alignment (`alignas(32)`)
- Cache-aware algorithms
- Loop unrolling
- OpenMP parallelization
- Target: 10x speedup on matmul

---

*Generated for MicroGrad++ learning project*
