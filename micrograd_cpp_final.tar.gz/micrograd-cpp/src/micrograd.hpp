// filepath: src/micrograd.hpp
// MicroGrad++ - Convenience header including all public API
// Repository: github.com/khaaliswooden-max/c_plusx2_project
#pragma once

// Core
#include "shape.hpp"

// Choose tensor implementation:
// - tensor.hpp: Phase 1 (no expression templates)
// - tensor_expr.hpp: Phase 2+ (with expression templates)
#ifndef MICROGRAD_NO_EXPR_TEMPLATES
    #include "tensor_expr.hpp"  // Phase 2+: With expression templates
#else
    #include "tensor.hpp"       // Phase 1: Without expression templates
    #include "ops_basic.hpp"    // Eager operations
#endif

// Phase 3+: Autodiff
// #include "autograd/variable.hpp"

// Phase 4+: Performance
// #include "optim/simd.hpp"

/// @brief MicroGrad++ namespace
/// 
/// A minimal autodiff tensor library for learning C++.
/// 
/// @section quickstart Quick Start
/// ```cpp
/// #include <micrograd.hpp>
/// using namespace micrograd;
/// 
/// int main() {
///     // Create tensors
///     auto a = Tensor<float>::ones({2, 3});
///     auto b = Tensor<float>::rand({2, 3});
///     
///     // Element-wise operations
///     auto c = a + b;
///     auto d = c * 2.0f;
///     
///     // Reductions
///     float sum = d.sum();
///     float mean = d.mean();
///     
///     // Matrix operations
///     auto x = Tensor<float>::randn({2, 4});
///     auto y = Tensor<float>::randn({4, 3});
///     auto z = matmul(x, y);  // Shape: (2, 3)
///     
///     std::cout << z << std::endl;
///     return 0;
/// }
/// ```
/// 
/// @section phases Learning Phases
/// - Phase 1: Foundations (RAII, templates, operators)
/// - Phase 2: Expression templates (lazy evaluation)
/// - Phase 3: Autodiff (computational graphs, gradients)
/// - Phase 4: Performance (SIMD, threading, allocators)
/// - Phase 5: Extensions (CUDA/sparse/quantization)
namespace micrograd {}
