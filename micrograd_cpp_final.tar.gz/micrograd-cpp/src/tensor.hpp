// filepath: src/tensor.hpp
// Core Tensor class for MicroGrad++ - Phase 1: Foundations
#pragma once

#include "shape.hpp"

#include <memory>
#include <algorithm>
#include <stdexcept>
#include <type_traits>
#include <iostream>
#include <iomanip>
#include <random>
#include <cmath>
#include <cassert>

namespace micrograd {

/// @brief N-dimensional dense tensor with contiguous row-major storage
/// @tparam T Element type (float, double recommended)
/// 
/// This class demonstrates:
/// - RAII (Resource Acquisition Is Initialization)
/// - Rule of 5 (destructor, copy ctor, move ctor, copy assign, move assign)
/// - Smart pointers (std::unique_ptr for exclusive ownership)
/// - Operator overloading ([], (), <<)
/// - Templates with type constraints
/// 
/// @example
/// ```cpp
/// Tensor<float> a({2, 3});      // 2x3 matrix, uninitialized
/// a.fill(1.0f);                 // All elements = 1.0
/// Tensor<float> b = a;          // Deep copy
/// Tensor<float> c = std::move(a);  // Move (a is now empty)
/// std::cout << c << std::endl;  // Pretty print
/// ```
template<typename T = float>
class Tensor
{
    // Compile-time constraint: only arithmetic types allowed
    static_assert(
        std::is_arithmetic_v<T>,
        "Tensor element type must be arithmetic (int, float, double, etc.)"
    );

public:
    // ========================================================================
    // Type Aliases
    // ========================================================================
    using value_type = T;
    using size_type = size_t;
    using pointer = T*;
    using const_pointer = const T*;
    using reference = T&;
    using const_reference = const T&;

    // ========================================================================
    // Constructors / Destructor (Rule of 5)
    // ========================================================================

    /// @brief Default constructor - creates empty tensor
    Tensor() noexcept = default;

    /// @brief Construct tensor with given shape (uninitialized data)
    /// @param shape Dimensions of the tensor
    /// @throws std::invalid_argument if shape is empty or has zero dimensions
    explicit Tensor(Shape shape)
        : shape_(std::move(shape))
        , strides_(shape_strides(shape_))
        , data_(std::make_unique<T[]>(size()))
    {
        validate_shape(shape_);
    }

    /// @brief Construct tensor with shape from initializer list
    /// @param shape Dimensions as initializer list
    explicit Tensor(std::initializer_list<size_t> shape)
        : Tensor(Shape(shape))
    {}

    /// @brief Destructor - unique_ptr handles memory cleanup (RAII)
    ~Tensor() = default;

    /// @brief Copy constructor - deep copy of data
    /// @param other Tensor to copy from
    Tensor(const Tensor& other)
        : shape_(other.shape_)
        , strides_(other.strides_)
        , data_(other.data_ ? std::make_unique<T[]>(other.size()) : nullptr)
    {
        if (data_) {
            std::copy(other.data_.get(), other.data_.get() + size(), data_.get());
        }
    }

    /// @brief Move constructor - transfer ownership (no copy)
    /// @param other Tensor to move from (will be empty after)
    Tensor(Tensor&& other) noexcept
        : shape_(std::move(other.shape_))
        , strides_(std::move(other.strides_))
        , data_(std::move(other.data_))
    {
        // other is now in valid but empty state
        other.shape_.clear();
        other.strides_.clear();
    }

    /// @brief Copy assignment - deep copy
    /// @param other Tensor to copy from
    /// @return Reference to this tensor
    Tensor& operator=(const Tensor& other)
    {
        if (this != &other) {
            // Use copy-and-swap idiom for exception safety
            Tensor tmp(other);
            swap(*this, tmp);
        }
        return *this;
    }

    /// @brief Move assignment - transfer ownership
    /// @param other Tensor to move from
    /// @return Reference to this tensor
    Tensor& operator=(Tensor&& other) noexcept
    {
        if (this != &other) {
            shape_ = std::move(other.shape_);
            strides_ = std::move(other.strides_);
            data_ = std::move(other.data_);
            other.shape_.clear();
            other.strides_.clear();
        }
        return *this;
    }

    /// @brief Swap two tensors (used by copy-and-swap idiom)
    friend void swap(Tensor& a, Tensor& b) noexcept
    {
        using std::swap;
        swap(a.shape_, b.shape_);
        swap(a.strides_, b.strides_);
        swap(a.data_, b.data_);
    }

    // ========================================================================
    // Static Factory Methods
    // ========================================================================

    /// @brief Create tensor filled with zeros
    [[nodiscard]] static Tensor zeros(Shape shape)
    {
        Tensor t(std::move(shape));
        t.fill(T{0});
        return t;
    }

    /// @brief Create tensor filled with ones
    [[nodiscard]] static Tensor ones(Shape shape)
    {
        Tensor t(std::move(shape));
        t.fill(T{1});
        return t;
    }

    /// @brief Create tensor with uniform random values in [0, 1)
    [[nodiscard]] static Tensor rand(Shape shape)
    {
        Tensor t(std::move(shape));
        std::random_device rd;
        std::mt19937 gen(rd());
        std::uniform_real_distribution<T> dist(T{0}, T{1});
        for (size_t i = 0; i < t.size(); ++i) {
            t[i] = dist(gen);
        }
        return t;
    }

    /// @brief Create tensor with standard normal random values
    [[nodiscard]] static Tensor randn(Shape shape)
    {
        Tensor t(std::move(shape));
        std::random_device rd;
        std::mt19937 gen(rd());
        std::normal_distribution<T> dist(T{0}, T{1});
        for (size_t i = 0; i < t.size(); ++i) {
            t[i] = dist(gen);
        }
        return t;
    }

    /// @brief Create tensor from raw data (copies data)
    [[nodiscard]] static Tensor from_data(Shape shape, const T* data)
    {
        Tensor t(std::move(shape));
        std::copy(data, data + t.size(), t.data_.get());
        return t;
    }

    /// @brief Create tensor from initializer list (1D)
    [[nodiscard]] static Tensor from_list(std::initializer_list<T> data)
    {
        Tensor t(Shape{data.size()});
        std::copy(data.begin(), data.end(), t.data_.get());
        return t;
    }

    // ========================================================================
    // Accessors
    // ========================================================================

    /// @brief Get tensor shape (dimensions)
    [[nodiscard]] const Shape& shape() const noexcept { return shape_; }

    /// @brief Get tensor strides
    [[nodiscard]] const Strides& strides() const noexcept { return strides_; }

    /// @brief Get number of dimensions (rank)
    [[nodiscard]] size_t ndim() const noexcept { return shape_.size(); }

    /// @brief Get total number of elements
    [[nodiscard]] size_t size() const noexcept { return shape_size(shape_); }

    /// @brief Check if tensor is empty
    [[nodiscard]] bool empty() const noexcept { return shape_.empty() || !data_; }

    /// @brief Get raw pointer to data (mutable)
    [[nodiscard]] pointer data() noexcept { return data_.get(); }

    /// @brief Get raw pointer to data (const)
    [[nodiscard]] const_pointer data() const noexcept { return data_.get(); }

    // ========================================================================
    // Element Access
    // ========================================================================

    /// @brief Access element by flat index (mutable)
    /// @param i Flat index into contiguous storage
    /// @return Reference to element
    [[nodiscard]] reference operator[](size_t i)
    {
        assert(i < size() && "Index out of bounds");
        return data_[i];
    }

    /// @brief Access element by flat index (const)
    [[nodiscard]] const_reference operator[](size_t i) const
    {
        assert(i < size() && "Index out of bounds");
        return data_[i];
    }

    /// @brief Access element by multi-dimensional index
    /// @param indices Index for each dimension
    /// @return Reference to element
    [[nodiscard]] reference at(const std::vector<size_t>& indices)
    {
        return data_[ravel_index(indices, shape_)];
    }

    /// @brief Access element by multi-dimensional index (const)
    [[nodiscard]] const_reference at(const std::vector<size_t>& indices) const
    {
        return data_[ravel_index(indices, shape_)];
    }

    /// @brief Access element by multi-dimensional index (variadic)
    /// @param indices Index values for each dimension
    template<typename... Indices>
    [[nodiscard]] reference operator()(Indices... indices)
    {
        static_assert(sizeof...(indices) > 0, "At least one index required");
        return at({static_cast<size_t>(indices)...});
    }

    /// @brief Access element by multi-dimensional index (variadic, const)
    template<typename... Indices>
    [[nodiscard]] const_reference operator()(Indices... indices) const
    {
        static_assert(sizeof...(indices) > 0, "At least one index required");
        return at({static_cast<size_t>(indices)...});
    }

    // ========================================================================
    // Mutators
    // ========================================================================

    /// @brief Fill all elements with a value
    void fill(T value) noexcept
    {
        std::fill(data_.get(), data_.get() + size(), value);
    }

    /// @brief Set all elements to zero
    void zero() noexcept { fill(T{0}); }

    /// @brief Apply a function to all elements in-place
    /// @param fn Function taking T& and modifying it
    template<typename Fn>
    void apply(Fn&& fn)
    {
        for (size_t i = 0; i < size(); ++i) {
            fn(data_[i]);
        }
    }

    /// @brief Transform all elements in-place
    /// @param fn Function T -> T
    template<typename Fn>
    void transform(Fn&& fn)
    {
        for (size_t i = 0; i < size(); ++i) {
            data_[i] = fn(data_[i]);
        }
    }

    // ========================================================================
    // Operations (return new tensor)
    // ========================================================================

    /// @brief Create a deep copy of this tensor
    [[nodiscard]] Tensor clone() const
    {
        return Tensor(*this);
    }

    /// @brief Reshape tensor (must have same total size)
    /// @param new_shape New dimensions
    /// @return New tensor with reshaped view
    /// @throws std::invalid_argument if sizes don't match
    [[nodiscard]] Tensor reshape(Shape new_shape) const
    {
        validate_shape(new_shape);
        if (shape_size(new_shape) != size()) {
            throw std::invalid_argument(
                "Cannot reshape from " + shape_to_string(shape_) +
                " to " + shape_to_string(new_shape) +
                ": size mismatch (" + std::to_string(size()) +
                " vs " + std::to_string(shape_size(new_shape)) + ")"
            );
        }
        
        Tensor result(std::move(new_shape));
        std::copy(data_.get(), data_.get() + size(), result.data_.get());
        return result;
    }

    /// @brief Flatten tensor to 1D
    [[nodiscard]] Tensor flatten() const
    {
        return reshape(Shape{size()});
    }

    // ========================================================================
    // Reductions
    // ========================================================================

    /// @brief Sum of all elements
    [[nodiscard]] T sum() const noexcept
    {
        T result{0};
        for (size_t i = 0; i < size(); ++i) {
            result += data_[i];
        }
        return result;
    }

    /// @brief Mean of all elements
    [[nodiscard]] T mean() const noexcept
    {
        return size() > 0 ? sum() / static_cast<T>(size()) : T{0};
    }

    /// @brief Maximum element
    [[nodiscard]] T max() const
    {
        if (empty()) throw std::runtime_error("Cannot find max of empty tensor");
        return *std::max_element(data_.get(), data_.get() + size());
    }

    /// @brief Minimum element
    [[nodiscard]] T min() const
    {
        if (empty()) throw std::runtime_error("Cannot find min of empty tensor");
        return *std::min_element(data_.get(), data_.get() + size());
    }

    // ========================================================================
    // Comparison
    // ========================================================================

    /// @brief Check if all elements are close to another tensor
    /// @param other Tensor to compare
    /// @param rtol Relative tolerance
    /// @param atol Absolute tolerance
    [[nodiscard]] bool allclose(const Tensor& other, T rtol = T{1e-5}, T atol = T{1e-8}) const
    {
        if (shape_ != other.shape_) return false;
        for (size_t i = 0; i < size(); ++i) {
            const T diff = std::abs(data_[i] - other.data_[i]);
            const T tol = atol + rtol * std::abs(other.data_[i]);
            if (diff > tol) return false;
        }
        return true;
    }

    // ========================================================================
    // I/O
    // ========================================================================

    /// @brief Pretty print tensor to stream
    friend std::ostream& operator<<(std::ostream& os, const Tensor& t)
    {
        os << "Tensor" << shape_to_string(t.shape_) << ":\n";
        
        if (t.empty()) {
            os << "  (empty)\n";
            return os;
        }

        // For 1D/2D, print nicely; for higher dims, print flat
        if (t.ndim() == 1) {
            os << "  [";
            for (size_t i = 0; i < t.size(); ++i) {
                if (i > 0) os << ", ";
                os << std::setprecision(4) << t[i];
            }
            os << "]\n";
        } else if (t.ndim() == 2) {
            for (size_t i = 0; i < t.shape_[0]; ++i) {
                os << "  [";
                for (size_t j = 0; j < t.shape_[1]; ++j) {
                    if (j > 0) os << ", ";
                    os << std::setw(8) << std::setprecision(4) << t.at({i, j});
                }
                os << "]\n";
            }
        } else {
            // Flat print for higher dimensions
            os << "  [";
            const size_t max_show = 10;
            for (size_t i = 0; i < std::min(t.size(), max_show); ++i) {
                if (i > 0) os << ", ";
                os << std::setprecision(4) << t[i];
            }
            if (t.size() > max_show) os << ", ...";
            os << "]\n";
        }
        
        return os;
    }

private:
    Shape shape_;                      ///< Tensor dimensions
    Strides strides_;                  ///< Strides for each dimension
    std::unique_ptr<T[]> data_;        ///< Contiguous data storage (RAII)
};

// ============================================================================
// Type Aliases for Common Types
// ============================================================================

using FloatTensor = Tensor<float>;
using DoubleTensor = Tensor<double>;
using IntTensor = Tensor<int>;

} // namespace micrograd
