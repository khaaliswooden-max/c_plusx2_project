// filepath: src/ops_basic.hpp
// Element-wise operations for MicroGrad++ - Phase 1: Foundations
#pragma once

#include "tensor.hpp"
#include <cmath>
#include <functional>

namespace micrograd {

// ============================================================================
// Binary Operations (Tensor op Tensor)
// ============================================================================

/// @brief Element-wise addition
/// @param a First tensor
/// @param b Second tensor (must have same shape)
/// @return New tensor with a + b
/// @throws std::invalid_argument if shapes don't match
template<typename T>
[[nodiscard]] Tensor<T> operator+(const Tensor<T>& a, const Tensor<T>& b)
{
    if (a.shape() != b.shape()) {
        throw std::invalid_argument(
            "Shape mismatch for addition: " +
            shape_to_string(a.shape()) + " vs " + shape_to_string(b.shape())
        );
    }
    
    Tensor<T> result(a.shape());
    for (size_t i = 0; i < a.size(); ++i) {
        result[i] = a[i] + b[i];
    }
    return result;
}

/// @brief Element-wise subtraction
template<typename T>
[[nodiscard]] Tensor<T> operator-(const Tensor<T>& a, const Tensor<T>& b)
{
    if (a.shape() != b.shape()) {
        throw std::invalid_argument(
            "Shape mismatch for subtraction: " +
            shape_to_string(a.shape()) + " vs " + shape_to_string(b.shape())
        );
    }
    
    Tensor<T> result(a.shape());
    for (size_t i = 0; i < a.size(); ++i) {
        result[i] = a[i] - b[i];
    }
    return result;
}

/// @brief Element-wise multiplication (Hadamard product)
template<typename T>
[[nodiscard]] Tensor<T> operator*(const Tensor<T>& a, const Tensor<T>& b)
{
    if (a.shape() != b.shape()) {
        throw std::invalid_argument(
            "Shape mismatch for multiplication: " +
            shape_to_string(a.shape()) + " vs " + shape_to_string(b.shape())
        );
    }
    
    Tensor<T> result(a.shape());
    for (size_t i = 0; i < a.size(); ++i) {
        result[i] = a[i] * b[i];
    }
    return result;
}

/// @brief Element-wise division
template<typename T>
[[nodiscard]] Tensor<T> operator/(const Tensor<T>& a, const Tensor<T>& b)
{
    if (a.shape() != b.shape()) {
        throw std::invalid_argument(
            "Shape mismatch for division: " +
            shape_to_string(a.shape()) + " vs " + shape_to_string(b.shape())
        );
    }
    
    Tensor<T> result(a.shape());
    for (size_t i = 0; i < a.size(); ++i) {
        result[i] = a[i] / b[i];
    }
    return result;
}

// ============================================================================
// Unary Operations
// ============================================================================

/// @brief Element-wise negation
template<typename T>
[[nodiscard]] Tensor<T> operator-(const Tensor<T>& a)
{
    Tensor<T> result(a.shape());
    for (size_t i = 0; i < a.size(); ++i) {
        result[i] = -a[i];
    }
    return result;
}

// ============================================================================
// Scalar Operations (Tensor op Scalar)
// ============================================================================

/// @brief Add scalar to each element
template<typename T>
[[nodiscard]] Tensor<T> operator+(const Tensor<T>& a, T scalar)
{
    Tensor<T> result(a.shape());
    for (size_t i = 0; i < a.size(); ++i) {
        result[i] = a[i] + scalar;
    }
    return result;
}

/// @brief Add scalar to each element (scalar on left)
template<typename T>
[[nodiscard]] Tensor<T> operator+(T scalar, const Tensor<T>& a)
{
    return a + scalar;  // Commutative
}

/// @brief Subtract scalar from each element
template<typename T>
[[nodiscard]] Tensor<T> operator-(const Tensor<T>& a, T scalar)
{
    Tensor<T> result(a.shape());
    for (size_t i = 0; i < a.size(); ++i) {
        result[i] = a[i] - scalar;
    }
    return result;
}

/// @brief Subtract each element from scalar
template<typename T>
[[nodiscard]] Tensor<T> operator-(T scalar, const Tensor<T>& a)
{
    Tensor<T> result(a.shape());
    for (size_t i = 0; i < a.size(); ++i) {
        result[i] = scalar - a[i];
    }
    return result;
}

/// @brief Multiply each element by scalar
template<typename T>
[[nodiscard]] Tensor<T> operator*(const Tensor<T>& a, T scalar)
{
    Tensor<T> result(a.shape());
    for (size_t i = 0; i < a.size(); ++i) {
        result[i] = a[i] * scalar;
    }
    return result;
}

/// @brief Multiply scalar by each element (scalar on left)
template<typename T>
[[nodiscard]] Tensor<T> operator*(T scalar, const Tensor<T>& a)
{
    return a * scalar;  // Commutative
}

/// @brief Divide each element by scalar
template<typename T>
[[nodiscard]] Tensor<T> operator/(const Tensor<T>& a, T scalar)
{
    Tensor<T> result(a.shape());
    for (size_t i = 0; i < a.size(); ++i) {
        result[i] = a[i] / scalar;
    }
    return result;
}

/// @brief Divide scalar by each element
template<typename T>
[[nodiscard]] Tensor<T> operator/(T scalar, const Tensor<T>& a)
{
    Tensor<T> result(a.shape());
    for (size_t i = 0; i < a.size(); ++i) {
        result[i] = scalar / a[i];
    }
    return result;
}

// ============================================================================
// Compound Assignment Operators
// ============================================================================

/// @brief In-place addition
template<typename T>
Tensor<T>& operator+=(Tensor<T>& a, const Tensor<T>& b)
{
    if (a.shape() != b.shape()) {
        throw std::invalid_argument("Shape mismatch for +=");
    }
    for (size_t i = 0; i < a.size(); ++i) {
        a[i] += b[i];
    }
    return a;
}

/// @brief In-place scalar addition
template<typename T>
Tensor<T>& operator+=(Tensor<T>& a, T scalar)
{
    for (size_t i = 0; i < a.size(); ++i) {
        a[i] += scalar;
    }
    return a;
}

/// @brief In-place subtraction
template<typename T>
Tensor<T>& operator-=(Tensor<T>& a, const Tensor<T>& b)
{
    if (a.shape() != b.shape()) {
        throw std::invalid_argument("Shape mismatch for -=");
    }
    for (size_t i = 0; i < a.size(); ++i) {
        a[i] -= b[i];
    }
    return a;
}

/// @brief In-place scalar subtraction
template<typename T>
Tensor<T>& operator-=(Tensor<T>& a, T scalar)
{
    for (size_t i = 0; i < a.size(); ++i) {
        a[i] -= scalar;
    }
    return a;
}

/// @brief In-place multiplication
template<typename T>
Tensor<T>& operator*=(Tensor<T>& a, const Tensor<T>& b)
{
    if (a.shape() != b.shape()) {
        throw std::invalid_argument("Shape mismatch for *=");
    }
    for (size_t i = 0; i < a.size(); ++i) {
        a[i] *= b[i];
    }
    return a;
}

/// @brief In-place scalar multiplication
template<typename T>
Tensor<T>& operator*=(Tensor<T>& a, T scalar)
{
    for (size_t i = 0; i < a.size(); ++i) {
        a[i] *= scalar;
    }
    return a;
}

/// @brief In-place division
template<typename T>
Tensor<T>& operator/=(Tensor<T>& a, const Tensor<T>& b)
{
    if (a.shape() != b.shape()) {
        throw std::invalid_argument("Shape mismatch for /=");
    }
    for (size_t i = 0; i < a.size(); ++i) {
        a[i] /= b[i];
    }
    return a;
}

/// @brief In-place scalar division
template<typename T>
Tensor<T>& operator/=(Tensor<T>& a, T scalar)
{
    for (size_t i = 0; i < a.size(); ++i) {
        a[i] /= scalar;
    }
    return a;
}

// ============================================================================
// Math Functions
// ============================================================================

/// @brief Element-wise exponential
template<typename T>
[[nodiscard]] Tensor<T> exp(const Tensor<T>& a)
{
    Tensor<T> result(a.shape());
    for (size_t i = 0; i < a.size(); ++i) {
        result[i] = std::exp(a[i]);
    }
    return result;
}

/// @brief Element-wise natural logarithm
template<typename T>
[[nodiscard]] Tensor<T> log(const Tensor<T>& a)
{
    Tensor<T> result(a.shape());
    for (size_t i = 0; i < a.size(); ++i) {
        result[i] = std::log(a[i]);
    }
    return result;
}

/// @brief Element-wise power
template<typename T>
[[nodiscard]] Tensor<T> pow(const Tensor<T>& a, T exponent)
{
    Tensor<T> result(a.shape());
    for (size_t i = 0; i < a.size(); ++i) {
        result[i] = std::pow(a[i], exponent);
    }
    return result;
}

/// @brief Element-wise square root
template<typename T>
[[nodiscard]] Tensor<T> sqrt(const Tensor<T>& a)
{
    Tensor<T> result(a.shape());
    for (size_t i = 0; i < a.size(); ++i) {
        result[i] = std::sqrt(a[i]);
    }
    return result;
}

/// @brief Element-wise absolute value
template<typename T>
[[nodiscard]] Tensor<T> abs(const Tensor<T>& a)
{
    Tensor<T> result(a.shape());
    for (size_t i = 0; i < a.size(); ++i) {
        result[i] = std::abs(a[i]);
    }
    return result;
}

/// @brief Element-wise ReLU (max(0, x))
template<typename T>
[[nodiscard]] Tensor<T> relu(const Tensor<T>& a)
{
    Tensor<T> result(a.shape());
    for (size_t i = 0; i < a.size(); ++i) {
        result[i] = std::max(T{0}, a[i]);
    }
    return result;
}

/// @brief Element-wise sigmoid (1 / (1 + exp(-x)))
template<typename T>
[[nodiscard]] Tensor<T> sigmoid(const Tensor<T>& a)
{
    Tensor<T> result(a.shape());
    for (size_t i = 0; i < a.size(); ++i) {
        result[i] = T{1} / (T{1} + std::exp(-a[i]));
    }
    return result;
}

/// @brief Element-wise tanh
template<typename T>
[[nodiscard]] Tensor<T> tanh(const Tensor<T>& a)
{
    Tensor<T> result(a.shape());
    for (size_t i = 0; i < a.size(); ++i) {
        result[i] = std::tanh(a[i]);
    }
    return result;
}

// ============================================================================
// Linear Algebra (Basic)
// ============================================================================

/// @brief Dot product of two 1D tensors
/// @param a First vector
/// @param b Second vector
/// @return Scalar result
template<typename T>
[[nodiscard]] T dot(const Tensor<T>& a, const Tensor<T>& b)
{
    if (a.ndim() != 1 || b.ndim() != 1) {
        throw std::invalid_argument("dot requires 1D tensors");
    }
    if (a.size() != b.size()) {
        throw std::invalid_argument("dot requires equal-sized tensors");
    }
    
    T result{0};
    for (size_t i = 0; i < a.size(); ++i) {
        result += a[i] * b[i];
    }
    return result;
}

/// @brief Matrix multiplication (2D tensors only for Phase 1)
/// @param a Matrix of shape (M, K)
/// @param b Matrix of shape (K, N)
/// @return Matrix of shape (M, N)
template<typename T>
[[nodiscard]] Tensor<T> matmul(const Tensor<T>& a, const Tensor<T>& b)
{
    if (a.ndim() != 2 || b.ndim() != 2) {
        throw std::invalid_argument("matmul requires 2D tensors");
    }
    if (a.shape()[1] != b.shape()[0]) {
        throw std::invalid_argument(
            "matmul shape mismatch: " + shape_to_string(a.shape()) +
            " @ " + shape_to_string(b.shape())
        );
    }
    
    const size_t M = a.shape()[0];
    const size_t K = a.shape()[1];
    const size_t N = b.shape()[1];
    
    Tensor<T> result = Tensor<T>::zeros({M, N});
    
    // Naive triple-loop (optimize in Phase 4)
    for (size_t i = 0; i < M; ++i) {
        for (size_t j = 0; j < N; ++j) {
            T sum{0};
            for (size_t k = 0; k < K; ++k) {
                sum += a.at({i, k}) * b.at({k, j});
            }
            result.at({i, j}) = sum;
        }
    }
    
    return result;
}

/// @brief Transpose a 2D tensor
/// @param a Matrix of shape (M, N)
/// @return Transposed matrix of shape (N, M)
template<typename T>
[[nodiscard]] Tensor<T> transpose(const Tensor<T>& a)
{
    if (a.ndim() != 2) {
        throw std::invalid_argument("transpose requires 2D tensor");
    }
    
    const size_t M = a.shape()[0];
    const size_t N = a.shape()[1];
    
    Tensor<T> result({N, M});
    for (size_t i = 0; i < M; ++i) {
        for (size_t j = 0; j < N; ++j) {
            result.at({j, i}) = a.at({i, j});
        }
    }
    
    return result;
}

} // namespace micrograd
