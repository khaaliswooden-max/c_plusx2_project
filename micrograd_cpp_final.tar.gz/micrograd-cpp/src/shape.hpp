// filepath: src/shape.hpp
// Shape utilities for MicroGrad++ tensor library
#pragma once

#include <vector>
#include <numeric>
#include <string>
#include <sstream>
#include <stdexcept>
#include <initializer_list>
#include <algorithm>
#include <cassert>

namespace micrograd {

/// @brief Type alias for tensor shape (dimensions)
using Shape = std::vector<size_t>;

/// @brief Type alias for tensor strides (bytes between elements along each axis)
using Strides = std::vector<size_t>;

// ============================================================================
// Shape Utilities
// ============================================================================

/// @brief Compute total number of elements from shape
/// @param shape Tensor dimensions
/// @return Product of all dimensions (1 for empty shape)
/// @example shape_size({2, 3, 4}) == 24
[[nodiscard]] inline size_t shape_size(const Shape& shape) noexcept
{
    if (shape.empty()) return 0;
    return std::accumulate(
        shape.begin(), shape.end(), 
        size_t{1}, 
        std::multiplies<size_t>{}
    );
}

/// @brief Compute row-major strides from shape
/// @param shape Tensor dimensions
/// @return Strides for each dimension
/// @example shape_strides({2, 3, 4}) == {12, 4, 1}
[[nodiscard]] inline Strides shape_strides(const Shape& shape) noexcept
{
    if (shape.empty()) return {};
    
    Strides strides(shape.size());
    size_t stride = 1;
    for (size_t i = shape.size(); i > 0; --i) {
        strides[i - 1] = stride;
        stride *= shape[i - 1];
    }
    return strides;
}

/// @brief Convert shape to string representation
/// @param shape Tensor dimensions
/// @return String like "(2, 3, 4)"
[[nodiscard]] inline std::string shape_to_string(const Shape& shape)
{
    std::ostringstream oss;
    oss << "(";
    for (size_t i = 0; i < shape.size(); ++i) {
        if (i > 0) oss << ", ";
        oss << shape[i];
    }
    oss << ")";
    return oss.str();
}

/// @brief Check if two shapes are equal
/// @param a First shape
/// @param b Second shape
/// @return true if shapes have same rank and dimensions
[[nodiscard]] inline bool shapes_equal(const Shape& a, const Shape& b) noexcept
{
    return a == b;
}

/// @brief Check if two shapes are broadcastable (NumPy-style)
/// @param a First shape
/// @param b Second shape
/// @return true if shapes can be broadcast together
/// @note Broadcasting rules: dimensions match if equal or one is 1
[[nodiscard]] inline bool shapes_broadcastable(const Shape& a, const Shape& b) noexcept
{
    const size_t max_rank = std::max(a.size(), b.size());
    
    for (size_t i = 0; i < max_rank; ++i) {
        // Get dimensions from right (broadcasting aligns from trailing dims)
        const size_t dim_a = (i < a.size()) ? a[a.size() - 1 - i] : 1;
        const size_t dim_b = (i < b.size()) ? b[b.size() - 1 - i] : 1;
        
        if (dim_a != dim_b && dim_a != 1 && dim_b != 1) {
            return false;
        }
    }
    return true;
}

/// @brief Compute broadcast result shape
/// @param a First shape
/// @param b Second shape
/// @return Result shape after broadcasting
/// @throws std::invalid_argument if shapes not broadcastable
[[nodiscard]] inline Shape broadcast_shapes(const Shape& a, const Shape& b)
{
    if (!shapes_broadcastable(a, b)) {
        throw std::invalid_argument(
            "Cannot broadcast shapes " + shape_to_string(a) + 
            " and " + shape_to_string(b)
        );
    }
    
    const size_t max_rank = std::max(a.size(), b.size());
    Shape result(max_rank);
    
    for (size_t i = 0; i < max_rank; ++i) {
        const size_t dim_a = (i < a.size()) ? a[a.size() - 1 - i] : 1;
        const size_t dim_b = (i < b.size()) ? b[b.size() - 1 - i] : 1;
        result[max_rank - 1 - i] = std::max(dim_a, dim_b);
    }
    return result;
}

/// @brief Validate shape is non-empty and has no zero dimensions
/// @param shape Shape to validate
/// @throws std::invalid_argument if shape is invalid
inline void validate_shape(const Shape& shape)
{
    if (shape.empty()) {
        throw std::invalid_argument("Shape cannot be empty");
    }
    for (size_t i = 0; i < shape.size(); ++i) {
        if (shape[i] == 0) {
            throw std::invalid_argument(
                "Shape dimension " + std::to_string(i) + " cannot be zero"
            );
        }
    }
}

/// @brief Convert flat index to multi-dimensional indices
/// @param flat_index Linear index into data
/// @param shape Tensor shape
/// @return Vector of indices for each dimension
[[nodiscard]] inline std::vector<size_t> unravel_index(size_t flat_index, const Shape& shape)
{
    assert(!shape.empty() && "Cannot unravel index for empty shape");
    assert(flat_index < shape_size(shape) && "Index out of bounds");
    
    std::vector<size_t> indices(shape.size());
    for (size_t i = shape.size(); i > 0; --i) {
        indices[i - 1] = flat_index % shape[i - 1];
        flat_index /= shape[i - 1];
    }
    return indices;
}

/// @brief Convert multi-dimensional indices to flat index
/// @param indices Index for each dimension
/// @param shape Tensor shape
/// @return Linear index into data
[[nodiscard]] inline size_t ravel_index(const std::vector<size_t>& indices, const Shape& shape)
{
    assert(indices.size() == shape.size() && "Index rank must match shape rank");
    
    size_t flat = 0;
    size_t stride = 1;
    for (size_t i = shape.size(); i > 0; --i) {
        assert(indices[i - 1] < shape[i - 1] && "Index out of bounds");
        flat += indices[i - 1] * stride;
        stride *= shape[i - 1];
    }
    return flat;
}

} // namespace micrograd
