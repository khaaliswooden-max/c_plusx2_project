// filepath: src/tensor_expr.hpp
// Tensor with Expression Template Support - Phase 2
//
// This extends the Phase 1 Tensor with:
// 1. CRTP inheritance from Expr (Tensor IS an expression)
// 2. Constructor from expressions (triggers lazy evaluation)
// 3. Assignment from expressions
//
// The key insight: Tensor<T>(expr) loops once over expr[i], computing
// each element on-demand. No intermediate allocations!
#pragma once

#include "shape.hpp"
#include "expr/expr_base.hpp"
#include "expr/expr_ops.hpp"

#include <memory>
#include <algorithm>
#include <stdexcept>
#include <type_traits>
#include <iostream>
#include <iomanip>
#include <random>
#include <cmath>
#include <cassert>

namespace micrograd {

/// @brief N-dimensional tensor with expression template support
/// @tparam T Element type (float, double)
///
/// Phase 2 additions:
/// - Inherits from Expr<Tensor<T>, T> (Tensor IS an expression)
/// - Can be constructed from any expression (lazy evaluation)
/// - Assignment from expressions triggers single-loop evaluation
template<typename T = float>
class Tensor : public expr::Expr<Tensor<T>, T>
{
    static_assert(
        std::is_arithmetic_v<T>,
        "Tensor element type must be arithmetic"
    );

public:
    using value_type = T;
    using size_type = size_t;
    using pointer = T*;
    using const_pointer = const T*;
    using reference = T&;
    using const_reference = const T&;

    // ========================================================================
    // Constructors (Phase 1 - unchanged)
    // ========================================================================

    Tensor() noexcept = default;

    explicit Tensor(Shape shape)
        : shape_(std::move(shape))
        , strides_(shape_strides(shape_))
        , data_(std::make_unique<T[]>(size()))
    {
        validate_shape(shape_);
    }

    explicit Tensor(std::initializer_list<size_t> shape)
        : Tensor(Shape(shape))
    {}

    // ========================================================================
    // NEW: Constructor from Expression (Phase 2)
    // ========================================================================

    /// @brief Construct tensor by evaluating an expression
    /// @tparam E Expression type (AddExpr, MulExpr, etc.)
    /// @param expr The expression to evaluate
    ///
    /// This is where the magic happens! The expression is evaluated
    /// element-by-element in a single loop. No temporaries!
    ///
    /// @example
    /// ```cpp
    /// Tensor<float> a({100}), b({100}), c({100});
    /// // This creates ONE tensor, loops once:
    /// Tensor<float> result = a + b * c;  // Calls this constructor
    /// ```
    template<typename E,
             typename = std::enable_if_t<!std::is_same_v<std::decay_t<E>, Tensor<T>>>>
    Tensor(const expr::Expr<E, T>& expr)
        : shape_(expr.self().shape())
        , strides_(shape_strides(shape_))
        , data_(std::make_unique<T[]>(expr.self().size()))
    {
        const auto& e = expr.self();
        const size_t n = e.size();
        
        // Single loop - expression elements computed on-demand
        for (size_t i = 0; i < n; ++i) {
            data_[i] = e[i];  // e[i] computes lazily through expression tree
        }
    }

    // ========================================================================
    // Rule of 5 (Phase 1 - unchanged)
    // ========================================================================

    ~Tensor() = default;

    Tensor(const Tensor& other)
        : shape_(other.shape_)
        , strides_(other.strides_)
        , data_(other.data_ ? std::make_unique<T[]>(other.size()) : nullptr)
    {
        if (data_) {
            std::copy(other.data_.get(), other.data_.get() + size(), data_.get());
        }
    }

    Tensor(Tensor&& other) noexcept
        : shape_(std::move(other.shape_))
        , strides_(std::move(other.strides_))
        , data_(std::move(other.data_))
    {
        other.shape_.clear();
        other.strides_.clear();
    }

    Tensor& operator=(const Tensor& other)
    {
        if (this != &other) {
            Tensor tmp(other);
            swap(*this, tmp);
        }
        return *this;
    }

    Tensor& operator=(Tensor&& other) noexcept
    {
        if (this != &other) {
            shape_ = std::move(other.shape_);
            strides_ = std::move(other.strides_);
            data_ = std::move(other.data_);
            other.shape_.clear();
            other.strides_.clear();
        }
        return *this;
    }

    // ========================================================================
    // NEW: Assignment from Expression (Phase 2)
    // ========================================================================

    /// @brief Assign from an expression (evaluates lazily)
    /// @tparam E Expression type
    /// @param expr Expression to evaluate
    /// @return Reference to this tensor
    ///
    /// If shapes match, reuses existing memory. Otherwise reallocates.
    template<typename E>
    Tensor& operator=(const expr::Expr<E, T>& expr)
    {
        const auto& e = expr.self();
        const size_t n = e.size();
        
        // Reallocate if size changed
        if (size() != n) {
            shape_ = Shape(e.shape());
            strides_ = shape_strides(shape_);
            data_ = std::make_unique<T[]>(n);
        }
        
        // Evaluate expression
        for (size_t i = 0; i < n; ++i) {
            data_[i] = e[i];
        }
        
        return *this;
    }

    friend void swap(Tensor& a, Tensor& b) noexcept
    {
        using std::swap;
        swap(a.shape_, b.shape_);
        swap(a.strides_, b.strides_);
        swap(a.data_, b.data_);
    }

    // ========================================================================
    // Static Factories (Phase 1 - unchanged)
    // ========================================================================

    [[nodiscard]] static Tensor zeros(Shape shape)
    {
        Tensor t(std::move(shape));
        t.fill(T{0});
        return t;
    }

    [[nodiscard]] static Tensor ones(Shape shape)
    {
        Tensor t(std::move(shape));
        t.fill(T{1});
        return t;
    }

    [[nodiscard]] static Tensor rand(Shape shape)
    {
        Tensor t(std::move(shape));
        std::random_device rd;
        std::mt19937 gen(rd());
        std::uniform_real_distribution<T> dist(T{0}, T{1});
        for (size_t i = 0; i < t.size(); ++i) {
            t[i] = dist(gen);
        }
        return t;
    }

    [[nodiscard]] static Tensor randn(Shape shape)
    {
        Tensor t(std::move(shape));
        std::random_device rd;
        std::mt19937 gen(rd());
        std::normal_distribution<T> dist(T{0}, T{1});
        for (size_t i = 0; i < t.size(); ++i) {
            t[i] = dist(gen);
        }
        return t;
    }

    [[nodiscard]] static Tensor from_data(Shape shape, const T* data)
    {
        Tensor t(std::move(shape));
        std::copy(data, data + t.size(), t.data_.get());
        return t;
    }

    [[nodiscard]] static Tensor from_list(std::initializer_list<T> data)
    {
        Tensor t(Shape{data.size()});
        std::copy(data.begin(), data.end(), t.data_.get());
        return t;
    }

    // ========================================================================
    // Accessors (Phase 1 - unchanged)
    // ========================================================================

    [[nodiscard]] const Shape& shape() const noexcept { return shape_; }
    [[nodiscard]] const Strides& strides() const noexcept { return strides_; }
    [[nodiscard]] size_t ndim() const noexcept { return shape_.size(); }
    [[nodiscard]] size_t size() const noexcept { return shape_size(shape_); }
    [[nodiscard]] bool empty() const noexcept { return shape_.empty() || !data_; }
    [[nodiscard]] pointer data() noexcept { return data_.get(); }
    [[nodiscard]] const_pointer data() const noexcept { return data_.get(); }

    // ========================================================================
    // Element Access (Phase 1 - unchanged)
    // ========================================================================

    [[nodiscard]] reference operator[](size_t i)
    {
        assert(i < size() && "Index out of bounds");
        return data_[i];
    }

    [[nodiscard]] const_reference operator[](size_t i) const
    {
        assert(i < size() && "Index out of bounds");
        return data_[i];
    }

    [[nodiscard]] reference at(const std::vector<size_t>& indices)
    {
        return data_[ravel_index(indices, shape_)];
    }

    [[nodiscard]] const_reference at(const std::vector<size_t>& indices) const
    {
        return data_[ravel_index(indices, shape_)];
    }

    template<typename... Indices>
    [[nodiscard]] reference operator()(Indices... indices)
    {
        return at({static_cast<size_t>(indices)...});
    }

    template<typename... Indices>
    [[nodiscard]] const_reference operator()(Indices... indices) const
    {
        return at({static_cast<size_t>(indices)...});
    }

    // ========================================================================
    // Mutators (Phase 1 - unchanged)
    // ========================================================================

    void fill(T value) noexcept
    {
        std::fill(data_.get(), data_.get() + size(), value);
    }

    void zero() noexcept { fill(T{0}); }

    template<typename Fn>
    void apply(Fn&& fn)
    {
        for (size_t i = 0; i < size(); ++i) {
            fn(data_[i]);
        }
    }

    template<typename Fn>
    void transform(Fn&& fn)
    {
        for (size_t i = 0; i < size(); ++i) {
            data_[i] = fn(data_[i]);
        }
    }

    // ========================================================================
    // Operations (Phase 1 - unchanged)
    // ========================================================================

    [[nodiscard]] Tensor clone() const { return Tensor(*this); }

    [[nodiscard]] Tensor reshape(Shape new_shape) const
    {
        validate_shape(new_shape);
        if (shape_size(new_shape) != size()) {
            throw std::invalid_argument("Cannot reshape: size mismatch");
        }
        Tensor result(std::move(new_shape));
        std::copy(data_.get(), data_.get() + size(), result.data_.get());
        return result;
    }

    [[nodiscard]] Tensor flatten() const { return reshape(Shape{size()}); }

    // ========================================================================
    // Reductions (Phase 1 - unchanged)
    // ========================================================================

    [[nodiscard]] T sum() const noexcept
    {
        T result{0};
        for (size_t i = 0; i < size(); ++i) result += data_[i];
        return result;
    }

    [[nodiscard]] T mean() const noexcept
    {
        return size() > 0 ? sum() / static_cast<T>(size()) : T{0};
    }

    [[nodiscard]] T max() const
    {
        if (empty()) throw std::runtime_error("Cannot find max of empty tensor");
        return *std::max_element(data_.get(), data_.get() + size());
    }

    [[nodiscard]] T min() const
    {
        if (empty()) throw std::runtime_error("Cannot find min of empty tensor");
        return *std::min_element(data_.get(), data_.get() + size());
    }

    // ========================================================================
    // Comparison (Phase 1 - unchanged)
    // ========================================================================

    [[nodiscard]] bool allclose(const Tensor& other, T rtol = T{1e-5}, T atol = T{1e-8}) const
    {
        if (shape_ != other.shape_) return false;
        for (size_t i = 0; i < size(); ++i) {
            const T diff = std::abs(data_[i] - other.data_[i]);
            const T tol = atol + rtol * std::abs(other.data_[i]);
            if (diff > tol) return false;
        }
        return true;
    }

    // ========================================================================
    // I/O (Phase 1 - unchanged)
    // ========================================================================

    friend std::ostream& operator<<(std::ostream& os, const Tensor& t)
    {
        os << "Tensor" << shape_to_string(t.shape_) << ":\n";
        if (t.empty()) {
            os << "  (empty)\n";
            return os;
        }

        if (t.ndim() == 1) {
            os << "  [";
            for (size_t i = 0; i < t.size(); ++i) {
                if (i > 0) os << ", ";
                os << std::setprecision(4) << t[i];
            }
            os << "]\n";
        } else if (t.ndim() == 2) {
            for (size_t i = 0; i < t.shape_[0]; ++i) {
                os << "  [";
                for (size_t j = 0; j < t.shape_[1]; ++j) {
                    if (j > 0) os << ", ";
                    os << std::setw(8) << std::setprecision(4) << t.at({i, j});
                }
                os << "]\n";
            }
        } else {
            os << "  [";
            const size_t max_show = 10;
            for (size_t i = 0; i < std::min(t.size(), max_show); ++i) {
                if (i > 0) os << ", ";
                os << std::setprecision(4) << t[i];
            }
            if (t.size() > max_show) os << ", ...";
            os << "]\n";
        }
        return os;
    }

private:
    Shape shape_;
    Strides strides_;
    std::unique_ptr<T[]> data_;
};

// ============================================================================
// Type Aliases
// ============================================================================

using FloatTensor = Tensor<float>;
using DoubleTensor = Tensor<double>;
using IntTensor = Tensor<int>;

// ============================================================================
// Non-Expression Operations (still need explicit evaluation)
// ============================================================================

/// @brief Matrix multiplication (not lazy - returns Tensor directly)
/// Expression templates don't work well for matmul due to index dependencies
template<typename T>
[[nodiscard]] Tensor<T> matmul(const Tensor<T>& a, const Tensor<T>& b)
{
    if (a.ndim() != 2 || b.ndim() != 2) {
        throw std::invalid_argument("matmul requires 2D tensors");
    }
    if (a.shape()[1] != b.shape()[0]) {
        throw std::invalid_argument("matmul shape mismatch");
    }

    const size_t M = a.shape()[0];
    const size_t K = a.shape()[1];
    const size_t N = b.shape()[1];

    Tensor<T> result = Tensor<T>::zeros({M, N});

    for (size_t i = 0; i < M; ++i) {
        for (size_t j = 0; j < N; ++j) {
            T sum{0};
            for (size_t k = 0; k < K; ++k) {
                sum += a.at({i, k}) * b.at({k, j});
            }
            result.at({i, j}) = sum;
        }
    }

    return result;
}

/// @brief Transpose (not lazy)
template<typename T>
[[nodiscard]] Tensor<T> transpose(const Tensor<T>& a)
{
    if (a.ndim() != 2) {
        throw std::invalid_argument("transpose requires 2D tensor");
    }

    const size_t M = a.shape()[0];
    const size_t N = a.shape()[1];

    Tensor<T> result({N, M});
    for (size_t i = 0; i < M; ++i) {
        for (size_t j = 0; j < N; ++j) {
            result.at({j, i}) = a.at({i, j});
        }
    }

    return result;
}

/// @brief Dot product of two 1D tensors
template<typename T>
[[nodiscard]] T dot(const Tensor<T>& a, const Tensor<T>& b)
{
    if (a.ndim() != 1 || b.ndim() != 1) {
        throw std::invalid_argument("dot requires 1D tensors");
    }
    if (a.size() != b.size()) {
        throw std::invalid_argument("dot requires equal-sized tensors");
    }

    T result{0};
    for (size_t i = 0; i < a.size(); ++i) {
        result += a[i] * b[i];
    }
    return result;
}

// ============================================================================
// Compound Assignment with Expressions
// ============================================================================

/// @brief In-place addition from expression
template<typename T, typename E>
Tensor<T>& operator+=(Tensor<T>& a, const expr::Expr<E, T>& expr)
{
    const auto& e = expr.self();
    assert(a.size() == e.size() && "Size mismatch");
    for (size_t i = 0; i < a.size(); ++i) {
        a[i] += e[i];
    }
    return a;
}

/// @brief In-place subtraction from expression
template<typename T, typename E>
Tensor<T>& operator-=(Tensor<T>& a, const expr::Expr<E, T>& expr)
{
    const auto& e = expr.self();
    assert(a.size() == e.size() && "Size mismatch");
    for (size_t i = 0; i < a.size(); ++i) {
        a[i] -= e[i];
    }
    return a;
}

/// @brief In-place multiplication from expression
template<typename T, typename E>
Tensor<T>& operator*=(Tensor<T>& a, const expr::Expr<E, T>& expr)
{
    const auto& e = expr.self();
    assert(a.size() == e.size() && "Size mismatch");
    for (size_t i = 0; i < a.size(); ++i) {
        a[i] *= e[i];
    }
    return a;
}

/// @brief In-place scalar operations
template<typename T>
Tensor<T>& operator+=(Tensor<T>& a, T scalar)
{
    for (size_t i = 0; i < a.size(); ++i) a[i] += scalar;
    return a;
}

template<typename T>
Tensor<T>& operator-=(Tensor<T>& a, T scalar)
{
    for (size_t i = 0; i < a.size(); ++i) a[i] -= scalar;
    return a;
}

template<typename T>
Tensor<T>& operator*=(Tensor<T>& a, T scalar)
{
    for (size_t i = 0; i < a.size(); ++i) a[i] *= scalar;
    return a;
}

template<typename T>
Tensor<T>& operator/=(Tensor<T>& a, T scalar)
{
    for (size_t i = 0; i < a.size(); ++i) a[i] /= scalar;
    return a;
}

} // namespace micrograd
