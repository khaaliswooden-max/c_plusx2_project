# Changelog

All notable changes to MicroGrad++ are documented here.

## [0.4.0] - 2024-12-28

### Phase 4: Performance Optimization

#### Added
- `src/simd/simd_detect.hpp` - Runtime SIMD capability detection (SSE, AVX, AVX2, AVX-512, NEON)
- `src/simd/simd_ops.hpp` - Vectorized element-wise operations using AVX2 intrinsics
- `src/simd/matmul_fast.hpp` - Optimized matrix multiplication with cache blocking + SIMD + OpenMP
- `src/simd/aligned_tensor.hpp` - AlignedTensor class with 32-byte aligned memory
- `benchmarks/bench_simd.cpp` - Comprehensive performance benchmark suite
- `tests/test_simd.cpp` - SIMD correctness tests
- `docs/PHASE4_LEARNINGS.md` - Systems programming learnings documentation
- OpenMP support in CMakeLists.txt

#### Performance
- **22x speedup** on 1024×1024 matrix multiply (naive → blocked+SIMD)
- **6-8x speedup** on element-wise operations with AVX2
- 10.1 GFLOPS achieved on matrix operations

---

## [0.3.0] - 2024-12-28

### Phase 3: Automatic Differentiation

#### Added
- `src/autograd/value.hpp` - Scalar autodiff node with gradient tracking
- `src/autograd/nn.hpp` - Neural network layers (Linear, MLP, SGD optimizer)
- `src/autograd/autograd.hpp` - Convenience header
- `examples/xor_mlp.cpp` - XOR neural network training example
- `tests/test_autograd.cpp` - Comprehensive gradient verification tests
- `docs/PHASE3_LEARNINGS.md` - PhD-level autodiff concepts

#### Features
- Computational graph construction via operator overloading
- Reverse-mode automatic differentiation (backpropagation)
- Chain rule implementation for all operations
- Gradient accumulation for shared variables
- Topological sort for backward pass ordering
- MSE and BCE loss functions
- Xavier/Glorot weight initialization

---

## [0.2.0] - 2024-12-28

### Phase 2: Expression Templates

#### Added
- `src/expr/expr_base.hpp` - CRTP base class and Expression concept
- `src/expr/expr_ops.hpp` - Lazy binary/unary operations
- `src/expr/expr_tensor.hpp` - TensorExpr with materialization
- `benchmarks/bench_expr.cpp` - Phase 1 vs Phase 2 comparison
- `tests/test_expr.cpp` - Expression template tests
- `docs/PHASE2_LEARNINGS.md` - Graduate-level C++ concepts

#### Features
- Zero-allocation chained operations (`a + b + c` → 1 allocation)
- CRTP for static polymorphism (no virtual overhead)
- C++20 concepts for type constraints
- Lazy evaluation with single-pass materialization
- 3-4x speedup over naive implementation

---

## [0.1.0] - 2024-12-28

### Phase 1: C++ Foundations

#### Added
- `src/tensor.hpp` - Core Tensor class with RAII
- `src/shape.hpp` - Shape utilities and stride computation
- `src/ops_basic.hpp` - Element-wise operations
- `tests/test_tensor.cpp` - Tensor construction and access tests
- `tests/test_shape.cpp` - Shape manipulation tests
- `tests/test_ops.cpp` - Operation correctness tests
- `docs/PHASE1_LEARNINGS.md` - Undergraduate C++ concepts
- CMakeLists.txt with GoogleTest integration

#### Features
- Rule of 5 implementation (copy, move, destructor)
- `std::unique_ptr` for automatic memory management
- Template metaprogramming for generic types
- Factory methods (zeros, ones, randn, from_list)
- Element-wise arithmetic operators
- Matrix multiplication and transpose
- Comprehensive test suite

---

## Roadmap

### Future Phases

- [ ] **Phase 5**: CUDA GPU acceleration
- [ ] **Phase 5**: Sparse tensor support
- [ ] **Phase 5**: INT8/FP16 quantization
- [ ] **Phase 5**: Custom memory allocators (pools)
