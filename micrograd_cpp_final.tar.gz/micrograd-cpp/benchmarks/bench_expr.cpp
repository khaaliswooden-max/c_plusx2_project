// filepath: benchmarks/bench_expr.cpp
// Expression Template Benchmark - Phase 1 vs Phase 2 Comparison
// Fixed: Namespace separation to avoid operator conflicts
#include <chrono>
#include <iostream>
#include <iomanip>
#include <vector>

// Phase 1: Use original Tensor (eager evaluation)
// These operators are in namespace micrograd
#include "tensor.hpp"
#include "ops_basic.hpp"

// Phase 2: Use TensorExpr (lazy evaluation)
// Expression operators are in namespace micrograd::expr
#include "expr/expr.hpp"

// ============================================================================
// Timer Utility
// ============================================================================

class Timer
{
public:
    void start() { start_ = std::chrono::high_resolution_clock::now(); }
    void stop() { end_ = std::chrono::high_resolution_clock::now(); }
    
    double elapsed_ms() const
    {
        return std::chrono::duration<double, std::milli>(end_ - start_).count();
    }
    
    double elapsed_us() const
    {
        return std::chrono::duration<double, std::micro>(end_ - start_).count();
    }

private:
    std::chrono::high_resolution_clock::time_point start_, end_;
};

// ============================================================================
// Phase 1 Benchmarks (Eager - micrograd::Tensor)
// ============================================================================

namespace phase1 {

using micrograd::Tensor;

double bench_add_chain(size_t N, int iterations)
{
    auto a = Tensor<float>::ones({N});
    auto b = Tensor<float>::ones({N});
    auto c = Tensor<float>::ones({N});
    auto d = Tensor<float>::ones({N});
    
    Timer timer;
    timer.start();
    
    for (int i = 0; i < iterations; ++i) {
        // Each + creates a temporary Tensor (3 allocations)
        // Uses micrograd::operator+ from ops_basic.hpp
        Tensor<float> result = a + b + c + d;
        volatile float x = result[0];
        (void)x;
    }
    
    timer.stop();
    return timer.elapsed_ms() / iterations;
}

double bench_complex(size_t N, int iterations)
{
    auto a = Tensor<float>::randn({N});
    auto b = Tensor<float>::randn({N});
    auto c = Tensor<float>::randn({N});
    
    Timer timer;
    timer.start();
    
    for (int i = 0; i < iterations; ++i) {
        // (a * b) + (c * 2.0) - a = 4 temporaries
        Tensor<float> result = a * b + c * 2.0f - a;
        volatile float x = result[0];
        (void)x;
    }
    
    timer.stop();
    return timer.elapsed_ms() / iterations;
}

} // namespace phase1

// ============================================================================
// Phase 2 Benchmarks (Lazy - micrograd::TensorExpr)
// ============================================================================

namespace phase2 {

using micrograd::TensorExpr;
// Expression operators are found via ADL in micrograd::expr

double bench_add_chain(size_t N, int iterations)
{
    auto a = TensorExpr<float>::ones({N});
    auto b = TensorExpr<float>::ones({N});
    auto c = TensorExpr<float>::ones({N});
    auto d = TensorExpr<float>::ones({N});
    
    Timer timer;
    timer.start();
    
    for (int i = 0; i < iterations; ++i) {
        // Builds expression tree: AddExpr<AddExpr<AddExpr<a,b>,c>,d>
        // Only 1 allocation when assigned to result
        TensorExpr<float> result = a + b + c + d;
        volatile float x = result[0];
        (void)x;
    }
    
    timer.stop();
    return timer.elapsed_ms() / iterations;
}

double bench_complex(size_t N, int iterations)
{
    auto a = TensorExpr<float>::randn({N});
    auto b = TensorExpr<float>::randn({N});
    auto c = TensorExpr<float>::randn({N});
    
    Timer timer;
    timer.start();
    
    for (int i = 0; i < iterations; ++i) {
        // Expression tree - 1 allocation, 1 pass
        TensorExpr<float> result = a * b + c * 2.0f - a;
        volatile float x = result[0];
        (void)x;
    }
    
    timer.stop();
    return timer.elapsed_ms() / iterations;
}

double bench_lazy_only(size_t N, int iterations)
{
    auto a = TensorExpr<float>::ones({N});
    auto b = TensorExpr<float>::ones({N});
    auto c = TensorExpr<float>::ones({N});
    
    Timer timer;
    timer.start();
    
    float sum = 0.0f;
    for (int i = 0; i < iterations; ++i) {
        auto expr = a + b + c;
        // Evaluate only 10 elements (no full materialization)
        for (size_t j = 0; j < 10; ++j) {
            sum += expr[j];
        }
    }
    
    timer.stop();
    volatile float x = sum;
    (void)x;
    
    return timer.elapsed_us() / iterations;
}

} // namespace phase2

// ============================================================================
// Main
// ============================================================================

int main()
{
    std::cout << "================================================================\n";
    std::cout << "  MicroGrad++ Expression Template Benchmark\n";
    std::cout << "  Phase 1 (Eager) vs Phase 2 (Lazy Evaluation)\n";
    std::cout << "================================================================\n\n";

    const std::vector<size_t> sizes = {1000, 10000, 100000, 1000000};
    const int iterations = 100;

    // Test 1: Add chain
    std::cout << "[Test 1] Add Chain: a + b + c + d\n";
    std::cout << std::setw(12) << "Size" 
              << std::setw(15) << "Phase1 (ms)"
              << std::setw(15) << "Phase2 (ms)"
              << std::setw(12) << "Speedup"
              << "\n";
    std::cout << std::string(54, '-') << "\n";
    
    for (size_t N : sizes) {
        double t1 = phase1::bench_add_chain(N, iterations);
        double t2 = phase2::bench_add_chain(N, iterations);
        double speedup = t1 / t2;
        
        std::cout << std::setw(12) << N
                  << std::setw(15) << std::fixed << std::setprecision(3) << t1
                  << std::setw(15) << std::fixed << std::setprecision(3) << t2
                  << std::setw(11) << std::fixed << std::setprecision(2) << speedup << "x"
                  << "\n";
    }

    // Test 2: Complex expression
    std::cout << "\n[Test 2] Complex: a * b + c * 2 - a\n";
    std::cout << std::setw(12) << "Size" 
              << std::setw(15) << "Phase1 (ms)"
              << std::setw(15) << "Phase2 (ms)"
              << std::setw(12) << "Speedup"
              << "\n";
    std::cout << std::string(54, '-') << "\n";
    
    for (size_t N : sizes) {
        double t1 = phase1::bench_complex(N, iterations);
        double t2 = phase2::bench_complex(N, iterations);
        double speedup = t1 / t2;
        
        std::cout << std::setw(12) << N
                  << std::setw(15) << std::fixed << std::setprecision(3) << t1
                  << std::setw(15) << std::fixed << std::setprecision(3) << t2
                  << std::setw(11) << std::fixed << std::setprecision(2) << speedup << "x"
                  << "\n";
    }

    // Test 3: Lazy-only
    std::cout << "\n[Test 3] Partial Evaluation (10 elements only)\n";
    std::cout << std::setw(12) << "Size" 
              << std::setw(15) << "Phase2 (us)"
              << std::setw(15) << "Note"
              << "\n";
    std::cout << std::string(42, '-') << "\n";
    
    for (size_t N : sizes) {
        double t2 = phase2::bench_lazy_only(N, iterations);
        std::cout << std::setw(12) << N
                  << std::setw(15) << std::fixed << std::setprecision(3) << t2
                  << std::setw(15) << "O(1) not O(N)"
                  << "\n";
    }

    std::cout << "\n================================================================\n";
    std::cout << "Analysis:\n";
    std::cout << "- Phase 1: O(ops) allocations per expression chain\n";
    std::cout << "- Phase 2: Exactly 1 allocation regardless of chain length\n";
    std::cout << "- Speedup is memory-bandwidth bound (~2-4x typical)\n";
    std::cout << "================================================================\n";

    return 0;
}
