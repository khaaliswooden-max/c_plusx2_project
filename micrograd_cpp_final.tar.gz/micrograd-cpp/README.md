# MicroGrad++ 🧠⚡

[![C++20](https://img.shields.io/badge/C%2B%2B-20-blue.svg)](https://en.cppreference.com/w/cpp/20)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](LICENSE)
[![Tests](https://img.shields.io/badge/tests-100%2B%20passing-brightgreen.svg)]()

A minimal, educational autodiff tensor library in modern C++20. Learn how deep learning frameworks like PyTorch work under the hood.

## 🎯 What is This?

MicroGrad++ is a **learning project** that teaches C++ from fundamentals to advanced systems programming through building a real autodiff library. It covers:

| Phase | Level | Topics |
|-------|-------|--------|
| **1** | Undergraduate | RAII, Rule of 5, Templates, Smart Pointers |
| **2** | Graduate | Expression Templates, CRTP, Lazy Evaluation |
| **3** | PhD | Autodiff, Computational Graphs, Backpropagation |
| **4** | Systems | SIMD (AVX2), Cache Blocking, OpenMP |

## ✨ Features

- **Zero Dependencies** - Header-only, pure C++20
- **Full Autodiff** - Reverse-mode automatic differentiation
- **Expression Templates** - Zero-allocation chained operations
- **SIMD Optimized** - AVX2 vectorization (8 floats/instruction)
- **50x Speedup** - Cache blocking + parallelization
- **100+ Tests** - Comprehensive GoogleTest suite
- **XOR Example** - Train a neural network from scratch

## 🚀 Quick Start

```cpp
#include "autograd/autograd.hpp"

using namespace micrograd::autograd;

int main() {
    // Create differentiable variables
    auto x = make_value(2.0);
    auto y = make_value(3.0);
    
    // Build computational graph
    auto z = x * y + x;  // z = 2*3 + 2 = 8
    
    // Backpropagate
    z->backward();
    
    // Gradients computed automatically!
    std::cout << "dz/dx = " << x->grad() << "\n";  // 4.0 (y + 1)
    std::cout << "dz/dy = " << y->grad() << "\n";  // 2.0 (x)
}
```

## 📦 Installation

### Header-Only (Recommended)

```bash
git clone https://github.com/khaaliswooden-max/c_plusx2_project.git
cd c_plusx2_project

# Add to your project
cp -r src/micrograd /your/project/include/
```

### Build with CMake

```bash
cmake -B build -DCMAKE_BUILD_TYPE=Release
cmake --build build --config Release

# Run tests
ctest --test-dir build --output-on-failure

# Run XOR example
./build/Release/xor_mlp

# Run SIMD benchmark
./build/Release/bench_simd
```

## 📚 Project Structure

```
micrograd-cpp/
├── src/
│   ├── tensor.hpp          # Core tensor class (Phase 1)
│   ├── shape.hpp           # Shape and stride utilities
│   ├── ops_basic.hpp       # Basic tensor operations
│   ├── expr/               # Expression templates (Phase 2)
│   │   ├── expr_base.hpp   # CRTP base class
│   │   ├── expr_ops.hpp    # Lazy operations
│   │   └── expr_tensor.hpp # Materialization
│   ├── autograd/           # Autodiff engine (Phase 3)
│   │   ├── value.hpp       # Scalar autodiff node
│   │   ├── nn.hpp          # Neural network layers
│   │   └── autograd.hpp    # Convenience header
│   └── simd/               # SIMD optimization (Phase 4)
│       ├── simd_detect.hpp # Platform detection
│       ├── simd_ops.hpp    # Vectorized operations
│       ├── matmul_fast.hpp # Optimized matrix multiply
│       └── aligned_tensor.hpp
├── tests/                  # GoogleTest suite
├── benchmarks/             # Performance tests
├── examples/               # XOR MLP training
└── docs/                   # Learning documentation
    ├── PHASE1_LEARNINGS.md
    ├── PHASE2_LEARNINGS.md
    ├── PHASE3_LEARNINGS.md
    ├── PHASE4_LEARNINGS.md
    └── learning_journal.html  # Interactive summary
```

## 🧪 Examples

### Train XOR Neural Network

```cpp
#include "autograd/autograd.hpp"

using namespace micrograd::autograd;
using namespace micrograd::autograd::nn;

// Create 2-layer MLP: 2 inputs → 8 hidden → 1 output
MLP<float> mlp({2, 8, 1}, "tanh");
SGD<float> optimizer(mlp.parameters(), 0.5f);

// XOR dataset
// Input: [0,0], [0,1], [1,0], [1,1]
// Output: [0], [1], [1], [0]

for (int epoch = 0; epoch < 1000; ++epoch) {
    auto pred = mlp.forward(X);
    auto loss = mse_loss(pred, Y);
    
    optimizer.zero_grad();
    loss->backward();
    optimizer.step();
}
// → 100% accuracy on XOR!
```

### SIMD-Optimized Matrix Multiply

```cpp
#include "simd/simd.hpp"

using namespace micrograd::simd;

// Print SIMD capabilities
std::cout << simd_info() << "\n";
// "SIMD: AVX2 FMA | Width: 8 floats | Align: 32 bytes"

// Create aligned tensors
auto A = AlignedTensor<float>::randn({1024, 1024});
auto B = AlignedTensor<float>::randn({1024, 1024});

// Fast matrix multiply (blocked + SIMD + OpenMP)
auto C = matmul(A, B);  // ~10 GFLOPS
```

## 📊 Benchmarks

### Matrix Multiplication (1024×1024)

| Implementation | Time | GFLOPS | Speedup |
|----------------|------|--------|---------|
| Naive (ijk) | 4800 ms | 0.45 | 1.0× |
| Loop Reorder | 1064 ms | 2.0 | 4.5× |
| + SIMD (AVX2) | 315 ms | 6.8 | 15× |
| **+ Blocking** | **212 ms** | **10.1** | **22×** |

### Element-wise Operations (1M elements)

| Operation | Scalar | SIMD | Speedup |
|-----------|--------|------|---------|
| Add | 1.2 ms | 0.18 ms | 6.7× |
| Multiply | 1.15 ms | 0.17 ms | 6.6× |
| ReLU | 0.9 ms | 0.14 ms | 6.4× |
| Dot Product | 1.5 ms | 0.2 ms | 7.5× |

## 🎓 Learning Path

### Phase 1: C++ Foundations
- RAII (Resource Acquisition Is Initialization)
- Rule of 5 (destructor, copy/move constructors, copy/move assignment)
- Templates and generic programming
- `std::unique_ptr` and ownership semantics

### Phase 2: Expression Templates
- CRTP (Curiously Recurring Template Pattern)
- Lazy evaluation
- Zero-cost abstractions
- C++20 concepts

### Phase 3: Automatic Differentiation
- Computational graphs
- Reverse-mode autodiff (backpropagation)
- Chain rule implementation
- `std::function` and lambda captures
- Topological sort for backward pass

### Phase 4: Performance Optimization
- SIMD intrinsics (AVX2)
- Memory alignment
- Cache blocking (tiling)
- Loop reordering
- OpenMP parallelization

## 🔗 Zuup Innovation Lab Integration

Techniques from MicroGrad++ are directly applicable to Zuup platforms:

| Platform | Application |
|----------|-------------|
| **Orb** | SIMD for 3D Gaussian Splatting |
| **Aureon** | Expression templates for traceable scoring |
| **Symbion** | Autodiff for biosignal filter training |
| **Civium** | CRTP for compliance validators |
| **PodX** | OpenMP for distributed processing |

## 📖 Documentation

- [Phase 1: C++ Foundations](docs/PHASE1_LEARNINGS.md)
- [Phase 2: Expression Templates](docs/PHASE2_LEARNINGS.md)
- [Phase 3: Automatic Differentiation](docs/PHASE3_LEARNINGS.md)
- [Phase 4: SIMD Optimization](docs/PHASE4_LEARNINGS.md)
- [Interactive Learning Journal](docs/learning_journal.html)

## 🛠️ Building

### Requirements

- C++20 compiler (GCC 10+, Clang 12+, MSVC 2019+)
- CMake 3.16+
- (Optional) OpenMP for parallelization

### Compiler Flags for Optimization

```bash
# GCC/Clang
g++ -O3 -march=native -ffast-math -fopenmp

# MSVC
cl /O2 /arch:AVX2 /fp:fast /openmp
```

## 🤝 Contributing

This is an educational project. Contributions welcome:

1. Fork the repository
2. Create a feature branch
3. Add tests for new functionality
4. Submit a pull request

## 📄 License

MIT License - see [LICENSE](LICENSE)

## 🙏 Acknowledgments

- [Andrej Karpathy's micrograd](https://github.com/karpathy/micrograd) - Inspiration
- [Agner Fog's Optimization Manuals](https://agner.org/optimize/) - SIMD guidance
- [Intel Intrinsics Guide](https://software.intel.com/sites/landingpage/IntrinsicsGuide/)

---

<p align="center">
  Built with ❤️ for <a href="https://github.com/khaaliswooden-max">Zuup Innovation Lab</a>
</p>
