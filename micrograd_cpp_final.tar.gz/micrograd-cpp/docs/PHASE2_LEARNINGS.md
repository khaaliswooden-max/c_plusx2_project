# Phase 2 Learnings: Expression Templates

**Completed:** Phase 2 of MicroGrad++  
**Level:** Graduate  
**Duration:** Weeks 4-6

---

## 🎓 What You Learned

### 1. CRTP (Curiously Recurring Template Pattern)

**Concept:** A class inherits from a template that takes the derived class as a parameter. Enables static polymorphism without virtual function overhead.

**Why it matters:** Zero runtime cost for polymorphic interfaces. Compiler resolves calls at compile time.

```cpp
// Base template takes Derived as parameter
template<typename Derived, typename T>
struct Expr
{
    // CRTP downcast - safe because Derived inherits from us
    const Derived& self() const
    {
        return static_cast<const Derived&>(*this);
    }
    
    // Delegate to derived class at compile time
    T operator[](size_t i) const
    {
        return self().eval(i);  // No vtable lookup!
    }
};

// Derived passes itself to base
template<typename L, typename R, typename T>
struct AddExpr : Expr<AddExpr<L, R, T>, T>
{
    T eval(size_t i) const { return lhs[i] + rhs[i]; }
};
```

**Key insight:** `static_cast<Derived&>(*this)` is always safe in CRTP because Derived *is* the actual type.

---

### 2. Lazy Evaluation

**Concept:** Defer computation until the result is actually needed. Build a description of computation (expression tree) instead of computing immediately.

**Without lazy evaluation (Phase 1):**
```cpp
// Each operation allocates and computes immediately
Tensor t1 = a + b;     // Allocate t1, compute a+b
Tensor t2 = t1 + c;    // Allocate t2, compute t1+c
Tensor result = t2;    // Copy
// Total: 2 unnecessary allocations, 3 data passes
```

**With lazy evaluation (Phase 2):**
```cpp
// Build expression tree (just types, no computation)
auto expr = a + b + c;  // Type: AddExpr<AddExpr<A,B>, C>

// Compute only when assigned to a Tensor
TensorExpr result = expr;  // ONE allocation, ONE pass
```

**How the expression tree works:**
```
a + b + c creates this type hierarchy:

    AddExpr
    /    \
 AddExpr   c
  /   \
 a     b

When you access result[i]:
1. AddExpr[i] calls lhs[i] + rhs[i]
2. lhs is AddExpr, so AddExpr[i] -> lhs[i] + rhs[i]
3. a[i] and b[i] are direct array accesses
4. All inlined by compiler into: result[i] = a[i] + b[i] + c[i]
```

---

### 3. Expression Templates Structure

**Pattern:** Each operation returns a lightweight struct storing references to operands.

```cpp
// Binary operation expression
template<typename L, typename R, typename Op, typename T>
struct BinaryExpr : Expr<BinaryExpr<L, R, Op, T>, T>
{
    const L& lhs;  // Reference, not copy
    const R& rhs;  // Reference, not copy
    Op op;         // Stateless functor (zero size)
    
    // Computation happens here, on-demand
    T eval(size_t i) const
    {
        return op(lhs[i], rhs[i]);
    }
};

// Operator builds expression, doesn't compute
template<typename L, typename R>
auto operator+(const L& lhs, const R& rhs)
{
    return BinaryExpr<L, R, ops::Add, typename L::value_type>(lhs, rhs);
}
```

**Key insight:** Expressions store *references*, not copies. sizeof(BinaryExpr) is typically just 2 pointers.

---

### 4. C++20 Concepts

**Concept:** Named constraints on template parameters. Clearer errors, better documentation.

**Without concepts (SFINAE):**
```cpp
template<typename E, typename = std::enable_if_t<is_expression_v<E>>>
auto operator-(const E& expr);
// Error messages: "no matching function for call..."
```

**With concepts:**
```cpp
// Define concept
template<typename E>
concept Expression = requires(const E& e, size_t i) {
    typename E::value_type;
    { e[i] } -> std::convertible_to<typename E::value_type>;
    { e.size() } -> std::same_as<size_t>;
};

// Use in function template
template<typename E>
requires Expression<E>
auto operator-(const E& expr);
// Error messages: "constraint not satisfied: Expression<int>"
```

**Key insight:** Concepts make template errors readable.

---

### 5. Copy Elision Verification

**Concept:** Compiler optimization that eliminates unnecessary copies. With C++17 guaranteed NRVO.

**How to verify no temporaries:**
```bash
# Compile with optimization
g++ -O2 -S -o output.s test.cpp

# Look at assembly
# Good: single loop with fused operations
# Bad: multiple loops, heap allocations in loop
```

**What to look for in assembly:**
```asm
# GOOD: Single loop
.L5:
    movss (%rdi,%rax,4), %xmm0   ; load a[i]
    addss (%rsi,%rax,4), %xmm0   ; add b[i]
    addss (%rdx,%rax,4), %xmm0   ; add c[i]
    movss %xmm0, (%rcx,%rax,4)   ; store result[i]
    incq %rax
    cmpq %r8, %rax
    jne .L5

# BAD: Multiple loops, heap allocations
    call operator new[]           ; allocation!
    ; ... loop 1 ...
    call operator new[]           ; another allocation!
    ; ... loop 2 ...
```

---

### 6. Expression Assignment Materialization

**Concept:** The moment lazy evaluation becomes eager - when expression is assigned to storage.

```cpp
// Expression constructor - materializes the computation
template<typename E>
requires Expression<E> && (!std::is_same_v<std::decay_t<E>, TensorExpr<T>>)
TensorExpr(const E& expr)
    : data_(std::make_unique<T[]>(expr.size()))
{
    // Single-pass evaluation of entire expression
    for (size_t i = 0; i < expr.size(); ++i) {
        data_[i] = expr[i];  // Compiler inlines entire tree
    }
}
```

**Why the constraint `!std::is_same_v<E, TensorExpr>`?**
- Prevents ambiguity with copy constructor
- TensorExpr is both an Expression AND a storage type
- Need to distinguish "copy this tensor" from "evaluate this expression"

---

## 🔑 Key Patterns Learned

### Expression Functor Pattern
Stateless operation types for compile-time dispatch:
```cpp
struct Add {
    template<typename T>
    constexpr T operator()(T a, T b) const { return a + b; }
};
// sizeof(Add) == 1 (empty base optimization)
```

### Type Erasure via Templates
Expression type captures operand types without virtual functions:
```cpp
// auto expr = a + b creates:
BinaryExpr<TensorExpr<float>, TensorExpr<float>, ops::Add, float>
```

### Reference Semantics for Operands
Expressions store references to avoid copies:
```cpp
const L& lhs;  // NOT: L lhs;
```
**Warning:** Expression must not outlive its operands!

---

## 📊 Performance Results

Benchmark: `a + b + c + d` with varying sizes

| Size | Phase 1 (Eager) | Phase 2 (Lazy) | Speedup |
|------|-----------------|----------------|---------|
| 1K | ~0.01 ms | ~0.003 ms | ~3x |
| 10K | ~0.1 ms | ~0.03 ms | ~3x |
| 100K | ~1 ms | ~0.3 ms | ~3x |
| 1M | ~10 ms | ~3 ms | ~3x |

**Why ~3x speedup?**
- Phase 1: 3 allocations + 3 data passes
- Phase 2: 1 allocation + 1 data pass
- Memory bandwidth bound → fewer passes = proportional speedup

---

## 🔗 Zuup/Visionblox Application

| Technique | Platform Application |
|-----------|---------------------|
| **CRTP** | Aureon: Zero-overhead policy interfaces for procurement rules |
| **Lazy Evaluation** | Orb: Defer 3DGS computations until render time |
| **Concepts** | Civium: Type-safe compliance validator constraints |
| **Expression Templates** | Symbion: Efficient biosignal filter chains |

**Example: Aureon Scoring Pipeline**
```cpp
// Define scoring concept
template<typename S>
concept Scorer = requires(S s, const Proposal& p) {
    { s.score(p) } -> std::convertible_to<float>;
};

// Lazy scoring chain
auto pipeline = technical_score + cost_score * 0.3f + past_performance * 0.2f;

// Evaluate only when needed
float final_score = pipeline.evaluate(proposal);
```

---

## ➡️ Next Phase Preview

**Phase 3: Autodiff Engine** will introduce:
- Computational graphs with `Variable` nodes
- Reverse-mode automatic differentiation
- `std::function` and lambda captures
- Topological sort for backward pass
- Train a neural network on XOR!

---

*Generated for MicroGrad++ learning project*
