# MicroGrad++ 🧠

A minimal autodiff tensor library built from scratch to learn C++ at undergraduate through PhD levels.

[![Build](https://github.com/khaaliswooden-max/c_plusx2_project/actions/workflows/ci.yml/badge.svg)](https://github.com/khaaliswooden-max/c_plusx2_project/actions)

## 🎯 Project Goals

Build a working tensor library with automatic differentiation while learning:

| Phase | Level | Techniques |
|-------|-------|------------|
| **1. Foundations** | Undergrad | RAII, Rule of 5, templates, operator overloading, CMake |
| **2. Expression Templates** | Grad | CRTP, lazy evaluation, concepts, copy elision |
| **3. Autodiff** | PhD | Computational graphs, reverse-mode AD, chain rule |
| **4. Performance** | PhD | SIMD, threading, custom allocators, profiling |
| **5. Extensions** | PhD | CUDA / Sparse / Quantization / Graph optimization |

## 🚀 Quick Start

```bash
# Clone
git clone https://github.com/khaaliswooden-max/c_plusx2_project.git
cd c_plusx2_project

# Build (Debug with sanitizers)
cmake -B build -DCMAKE_BUILD_TYPE=Debug
cmake --build build -j

# Test
ctest --test-dir build --output-on-failure

# Run tests directly
./build/test_tensor
```

## 📖 Usage

```cpp
#include <micrograd.hpp>
using namespace micrograd;

int main() {
    // Create tensors
    auto a = Tensor<float>::ones({2, 3});
    auto b = Tensor<float>::rand({2, 3});
    
    // Element-wise operations
    auto c = a + b;
    auto d = c * 2.0f;
    
    // Reductions
    float sum = d.sum();
    float mean = d.mean();
    
    // Matrix operations
    auto x = Tensor<float>::randn({2, 4});
    auto y = Tensor<float>::randn({4, 3});
    auto z = matmul(x, y);  // Shape: (2, 3)
    
    std::cout << z << std::endl;
    return 0;
}
```

## 📁 Project Structure

```
├── src/
│   ├── micrograd.hpp    # Convenience include
│   ├── tensor.hpp       # Phase 1: Core Tensor (RAII, Rule of 5)
│   ├── tensor_expr.hpp  # Phase 2: Tensor with expression templates
│   ├── shape.hpp        # Shape utilities
│   ├── ops_basic.hpp    # Phase 1 eager operations
│   ├── expr/            # Phase 2: Expression templates
│   │   ├── expr_base.hpp   # CRTP base class
│   │   └── expr_ops.hpp    # Binary/unary expression types
│   ├── autograd/        # [Phase 3] Autodiff engine
│   └── optim/           # [Phase 4] SIMD, threading
├── tests/
│   ├── test_tensor.cpp  # Tensor class tests
│   ├── test_shape.cpp   # Shape utilities tests
│   ├── test_ops.cpp     # Operations tests
│   └── test_expr.cpp    # Phase 2: Expression template tests
├── benchmarks/
│   └── bench_expr.cpp   # Phase 2: Lazy vs eager benchmark
├── docs/
│   ├── PHASE1_LEARNINGS.md
│   └── PHASE2_LEARNINGS.md
├── CMakeLists.txt
└── .cursorrules         # AI-assisted development rules
```

## 🔧 Development

### Prerequisites

- **Compiler:** GCC 10+ or Clang 10+ (C++20 support)
- **Build:** CMake 3.16+
- **Optional:** valgrind, clang-format, clangd

### Build Options

```bash
# Release build (optimized)
cmake -B build -DCMAKE_BUILD_TYPE=Release
cmake --build build -j

# With sanitizers (detect memory bugs)
cmake -B build -DCMAKE_BUILD_TYPE=Debug \
      -DCMAKE_CXX_FLAGS="-fsanitize=address,undefined"

# Disable tests
cmake -B build -DBUILD_TESTING=OFF
```

### Memory Check

```bash
valgrind --leak-check=full ./build/test_tensor
```

### Code Style

```bash
clang-format -i src/*.hpp tests/*.cpp
```

## 📚 Learning Resources

- *Effective Modern C++* (Meyers) — RAII, move semantics
- *C++ Templates: The Complete Guide* (Vandevoorde) — Template metaprogramming
- [micrograd](https://github.com/karpathy/micrograd) — Reference Python implementation
- [Eigen internals](https://eigen.tuxfamily.org/dox/TopicInsideEigenExample.html) — Expression templates

## 🏫 Academic References

This project maps to techniques taught at:
- Stanford CS 106L (Modern C++)
- MIT 6.172 (Performance Engineering)
- CMU 10-714 (Deep Learning Systems)
- Princeton COS 217 (Systems Programming)

## 📝 License

MIT License - Educational use encouraged.

## 🤝 Contributing

This is a learning project. PRs for bug fixes and documentation improvements welcome.

---

**Current Phase:** 2 - Expression Templates ✅
