// filepath: tests/test_tensor.cpp
// Tensor class unit tests - Phase 1: Foundations
// Tests: RAII, Rule of 5, smart pointers, operator overloading, templates
#include <gtest/gtest.h>
#include "tensor.hpp"

using namespace micrograd;

// ============================================================================
// Construction Tests
// ============================================================================

TEST(TensorTest, DefaultConstructor_CreatesEmptyTensor)
{
    Tensor<float> t;
    EXPECT_TRUE(t.empty());
    EXPECT_EQ(t.size(), 0);
    EXPECT_EQ(t.ndim(), 0);
}

TEST(TensorTest, ShapeConstructor_ValidShape_CreatesCorrectSize)
{
    Tensor<float> t({2, 3, 4});
    EXPECT_FALSE(t.empty());
    EXPECT_EQ(t.size(), 24);
    EXPECT_EQ(t.ndim(), 3);
    EXPECT_EQ(t.shape()[0], 2);
    EXPECT_EQ(t.shape()[1], 3);
    EXPECT_EQ(t.shape()[2], 4);
}

TEST(TensorTest, InitializerListConstructor_CreatesCorrectShape)
{
    Tensor<float> t{4, 5};
    EXPECT_EQ(t.size(), 20);
    EXPECT_EQ(t.ndim(), 2);
}

TEST(TensorTest, EmptyShapeConstructor_ThrowsInvalidArgument)
{
    EXPECT_THROW(Tensor<float>(Shape{}), std::invalid_argument);
}

TEST(TensorTest, ZeroInShapeConstructor_ThrowsInvalidArgument)
{
    EXPECT_THROW(Tensor<float>({2, 0, 3}), std::invalid_argument);
}

// ============================================================================
// Rule of 5 Tests (Copy/Move Semantics)
// ============================================================================

TEST(TensorTest, CopyConstructor_CreatesDeepCopy)
{
    Tensor<float> original({2, 3});
    original.fill(42.0f);
    
    Tensor<float> copy(original);  // Copy constructor
    
    // Verify copy has same data
    EXPECT_EQ(copy.shape(), original.shape());
    EXPECT_EQ(copy.size(), original.size());
    for (size_t i = 0; i < original.size(); ++i) {
        EXPECT_FLOAT_EQ(copy[i], original[i]);
    }
    
    // Verify independence (deep copy)
    copy[0] = 999.0f;
    EXPECT_FLOAT_EQ(original[0], 42.0f);  // Original unchanged
    EXPECT_FLOAT_EQ(copy[0], 999.0f);
}

TEST(TensorTest, MoveConstructor_TransfersOwnership)
{
    Tensor<float> original({2, 3});
    original.fill(42.0f);
    const float* original_ptr = original.data();
    
    Tensor<float> moved(std::move(original));  // Move constructor
    
    // Verify moved tensor has the data
    EXPECT_EQ(moved.size(), 6);
    EXPECT_FLOAT_EQ(moved[0], 42.0f);
    EXPECT_EQ(moved.data(), original_ptr);  // Same pointer (no copy!)
    
    // Original should be empty
    EXPECT_TRUE(original.empty());
    EXPECT_EQ(original.data(), nullptr);
}

TEST(TensorTest, CopyAssignment_CreatesDeepCopy)
{
    Tensor<float> original({2, 2});
    original.fill(7.0f);
    
    Tensor<float> copy({3, 3});  // Different size
    copy = original;  // Copy assignment
    
    EXPECT_EQ(copy.shape(), original.shape());
    for (size_t i = 0; i < original.size(); ++i) {
        EXPECT_FLOAT_EQ(copy[i], original[i]);
    }
    
    // Verify independence
    copy[0] = 123.0f;
    EXPECT_FLOAT_EQ(original[0], 7.0f);
}

TEST(TensorTest, MoveAssignment_TransfersOwnership)
{
    Tensor<float> original({2, 2});
    original.fill(3.14f);
    
    Tensor<float> target({5, 5});
    target = std::move(original);  // Move assignment
    
    EXPECT_EQ(target.size(), 4);
    EXPECT_FLOAT_EQ(target[0], 3.14f);
    EXPECT_TRUE(original.empty());
}

TEST(TensorTest, SelfAssignment_NoOp)
{
    Tensor<float> t({2, 2});
    t.fill(5.0f);
    
    t = t;  // Self-assignment
    
    EXPECT_EQ(t.size(), 4);
    EXPECT_FLOAT_EQ(t[0], 5.0f);
}

// ============================================================================
// Factory Method Tests
// ============================================================================

TEST(TensorTest, Zeros_AllElementsZero)
{
    auto t = Tensor<float>::zeros({3, 3});
    for (size_t i = 0; i < t.size(); ++i) {
        EXPECT_FLOAT_EQ(t[i], 0.0f);
    }
}

TEST(TensorTest, Ones_AllElementsOne)
{
    auto t = Tensor<double>::ones({2, 4});
    for (size_t i = 0; i < t.size(); ++i) {
        EXPECT_DOUBLE_EQ(t[i], 1.0);
    }
}

TEST(TensorTest, Rand_ValuesInRange)
{
    auto t = Tensor<float>::rand({100});
    for (size_t i = 0; i < t.size(); ++i) {
        EXPECT_GE(t[i], 0.0f);
        EXPECT_LT(t[i], 1.0f);
    }
}

TEST(TensorTest, Randn_HasVariance)
{
    auto t = Tensor<float>::randn({1000});
    float mean = t.mean();
    float variance = 0.0f;
    for (size_t i = 0; i < t.size(); ++i) {
        variance += (t[i] - mean) * (t[i] - mean);
    }
    variance /= static_cast<float>(t.size());
    
    // Should be close to mean=0, variance=1
    EXPECT_NEAR(mean, 0.0f, 0.1f);
    EXPECT_NEAR(variance, 1.0f, 0.2f);
}

TEST(TensorTest, FromData_CopiesCorrectly)
{
    float data[] = {1.0f, 2.0f, 3.0f, 4.0f, 5.0f, 6.0f};
    auto t = Tensor<float>::from_data({2, 3}, data);
    
    EXPECT_EQ(t.size(), 6);
    for (size_t i = 0; i < 6; ++i) {
        EXPECT_FLOAT_EQ(t[i], data[i]);
    }
}

TEST(TensorTest, FromList_Creates1DTensor)
{
    auto t = Tensor<float>::from_list({1.0f, 2.0f, 3.0f});
    EXPECT_EQ(t.ndim(), 1);
    EXPECT_EQ(t.size(), 3);
    EXPECT_FLOAT_EQ(t[0], 1.0f);
    EXPECT_FLOAT_EQ(t[2], 3.0f);
}

// ============================================================================
// Element Access Tests
// ============================================================================

TEST(TensorTest, BracketOperator_CorrectAccess)
{
    Tensor<float> t({3});
    t[0] = 1.0f;
    t[1] = 2.0f;
    t[2] = 3.0f;
    
    EXPECT_FLOAT_EQ(t[0], 1.0f);
    EXPECT_FLOAT_EQ(t[1], 2.0f);
    EXPECT_FLOAT_EQ(t[2], 3.0f);
}

TEST(TensorTest, AtMethod_MultiDimAccess)
{
    Tensor<float> t({2, 3});
    t.fill(0.0f);
    t.at({0, 0}) = 1.0f;
    t.at({0, 1}) = 2.0f;
    t.at({1, 2}) = 6.0f;
    
    EXPECT_FLOAT_EQ(t.at({0, 0}), 1.0f);
    EXPECT_FLOAT_EQ(t.at({0, 1}), 2.0f);
    EXPECT_FLOAT_EQ(t.at({1, 2}), 6.0f);
}

TEST(TensorTest, CallOperator_MultiDimAccess)
{
    Tensor<float> t({2, 3, 4});
    t.fill(0.0f);
    t(1, 2, 3) = 42.0f;
    
    EXPECT_FLOAT_EQ(t(1, 2, 3), 42.0f);
    EXPECT_FLOAT_EQ(t(0, 0, 0), 0.0f);
}

// ============================================================================
// Mutator Tests
// ============================================================================

TEST(TensorTest, Fill_AllElementsSameValue)
{
    Tensor<float> t({3, 3});
    t.fill(3.14f);
    
    for (size_t i = 0; i < t.size(); ++i) {
        EXPECT_FLOAT_EQ(t[i], 3.14f);
    }
}

TEST(TensorTest, Zero_AllElementsZero)
{
    Tensor<float> t({2, 2});
    t.fill(999.0f);
    t.zero();
    
    for (size_t i = 0; i < t.size(); ++i) {
        EXPECT_FLOAT_EQ(t[i], 0.0f);
    }
}

TEST(TensorTest, Apply_ModifiesInPlace)
{
    Tensor<float> t({3});
    t[0] = 1.0f; t[1] = 2.0f; t[2] = 3.0f;
    
    t.apply([](float& x) { x *= 2; });
    
    EXPECT_FLOAT_EQ(t[0], 2.0f);
    EXPECT_FLOAT_EQ(t[1], 4.0f);
    EXPECT_FLOAT_EQ(t[2], 6.0f);
}

TEST(TensorTest, Transform_AppliesFunction)
{
    Tensor<float> t({3});
    t[0] = 1.0f; t[1] = 4.0f; t[2] = 9.0f;
    
    t.transform([](float x) { return std::sqrt(x); });
    
    EXPECT_FLOAT_EQ(t[0], 1.0f);
    EXPECT_FLOAT_EQ(t[1], 2.0f);
    EXPECT_FLOAT_EQ(t[2], 3.0f);
}

// ============================================================================
// Operation Tests
// ============================================================================

TEST(TensorTest, Clone_CreatesIndependentCopy)
{
    Tensor<float> original({2, 2});
    original.fill(5.0f);
    
    auto clone = original.clone();
    clone[0] = 999.0f;
    
    EXPECT_FLOAT_EQ(original[0], 5.0f);  // Unchanged
}

TEST(TensorTest, Reshape_CorrectNewShape)
{
    auto t = Tensor<float>::from_list({1, 2, 3, 4, 5, 6});
    auto reshaped = t.reshape({2, 3});
    
    EXPECT_EQ(reshaped.shape()[0], 2);
    EXPECT_EQ(reshaped.shape()[1], 3);
    EXPECT_FLOAT_EQ(reshaped(0, 0), 1.0f);
    EXPECT_FLOAT_EQ(reshaped(1, 2), 6.0f);
}

TEST(TensorTest, Reshape_SizeMismatch_Throws)
{
    auto t = Tensor<float>::zeros({2, 3});  // 6 elements
    EXPECT_THROW(t.reshape({2, 2}), std::invalid_argument);  // 4 elements
}

TEST(TensorTest, Flatten_CreatesFlatTensor)
{
    auto t = Tensor<float>::zeros({2, 3, 4});  // 24 elements
    auto flat = t.flatten();
    
    EXPECT_EQ(flat.ndim(), 1);
    EXPECT_EQ(flat.size(), 24);
}

// ============================================================================
// Reduction Tests
// ============================================================================

TEST(TensorTest, Sum_CorrectResult)
{
    auto t = Tensor<float>::from_list({1, 2, 3, 4, 5});
    EXPECT_FLOAT_EQ(t.sum(), 15.0f);
}

TEST(TensorTest, Mean_CorrectResult)
{
    auto t = Tensor<float>::from_list({2, 4, 6, 8});
    EXPECT_FLOAT_EQ(t.mean(), 5.0f);
}

TEST(TensorTest, Max_CorrectResult)
{
    auto t = Tensor<float>::from_list({3, 1, 4, 1, 5, 9, 2, 6});
    EXPECT_FLOAT_EQ(t.max(), 9.0f);
}

TEST(TensorTest, Min_CorrectResult)
{
    auto t = Tensor<float>::from_list({3, 1, 4, 1, 5, 9, 2, 6});
    EXPECT_FLOAT_EQ(t.min(), 1.0f);
}

// ============================================================================
// Comparison Tests
// ============================================================================

TEST(TensorTest, Allclose_IdenticalTensors_ReturnsTrue)
{
    auto a = Tensor<float>::ones({2, 3});
    auto b = Tensor<float>::ones({2, 3});
    EXPECT_TRUE(a.allclose(b));
}

TEST(TensorTest, Allclose_SmallDifference_ReturnsTrue)
{
    auto a = Tensor<float>::ones({2, 3});
    auto b = Tensor<float>::ones({2, 3});
    b[0] = 1.0f + 1e-6f;
    EXPECT_TRUE(a.allclose(b));
}

TEST(TensorTest, Allclose_LargeDifference_ReturnsFalse)
{
    auto a = Tensor<float>::ones({2, 3});
    auto b = Tensor<float>::ones({2, 3});
    b[0] = 2.0f;
    EXPECT_FALSE(a.allclose(b));
}

TEST(TensorTest, Allclose_DifferentShapes_ReturnsFalse)
{
    auto a = Tensor<float>::ones({2, 3});
    auto b = Tensor<float>::ones({3, 2});
    EXPECT_FALSE(a.allclose(b));
}

// ============================================================================
// Type Tests
// ============================================================================

TEST(TensorTest, DoubleTensor_Works)
{
    auto t = Tensor<double>::randn({10});
    EXPECT_EQ(t.size(), 10);
}

TEST(TensorTest, IntTensor_Works)
{
    Tensor<int> t({3, 3});
    t.fill(42);
    EXPECT_EQ(t[0], 42);
}

// ============================================================================
// Edge Cases
// ============================================================================

TEST(TensorTest, SingleElement_Works)
{
    Tensor<float> t({1});
    t.fill(3.14f);
    EXPECT_EQ(t.size(), 1);
    EXPECT_FLOAT_EQ(t[0], 3.14f);
    EXPECT_FLOAT_EQ(t.sum(), 3.14f);
}

TEST(TensorTest, LargeTensor_DoesNotCrash)
{
    // 10 million elements (~40MB for float)
    Tensor<float> t({1000, 10000});
    t.fill(1.0f);
    EXPECT_EQ(t.size(), 10000000);
    EXPECT_FLOAT_EQ(t.sum(), 10000000.0f);
}
