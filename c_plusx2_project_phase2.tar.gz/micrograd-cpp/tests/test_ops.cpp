// filepath: tests/test_ops.cpp
// Operations unit tests - element-wise, scalar, math functions
#include <gtest/gtest.h>
#include "micrograd.hpp"

using namespace micrograd;

// ============================================================================
// Binary Operations (Tensor op Tensor)
// ============================================================================

TEST(OpsTest, Addition_SameShape_Correct)
{
    auto a = Tensor<float>::from_list({1, 2, 3});
    auto b = Tensor<float>::from_list({4, 5, 6});
    auto c = a + b;
    
    EXPECT_FLOAT_EQ(c[0], 5.0f);
    EXPECT_FLOAT_EQ(c[1], 7.0f);
    EXPECT_FLOAT_EQ(c[2], 9.0f);
}

TEST(OpsTest, Addition_ShapeMismatch_Throws)
{
    auto a = Tensor<float>::zeros({2, 3});
    auto b = Tensor<float>::zeros({3, 2});
    EXPECT_THROW(a + b, std::invalid_argument);
}

TEST(OpsTest, Subtraction_Correct)
{
    auto a = Tensor<float>::from_list({5, 7, 9});
    auto b = Tensor<float>::from_list({1, 2, 3});
    auto c = a - b;
    
    EXPECT_FLOAT_EQ(c[0], 4.0f);
    EXPECT_FLOAT_EQ(c[1], 5.0f);
    EXPECT_FLOAT_EQ(c[2], 6.0f);
}

TEST(OpsTest, Multiplication_ElementWise)
{
    auto a = Tensor<float>::from_list({2, 3, 4});
    auto b = Tensor<float>::from_list({5, 6, 7});
    auto c = a * b;
    
    EXPECT_FLOAT_EQ(c[0], 10.0f);
    EXPECT_FLOAT_EQ(c[1], 18.0f);
    EXPECT_FLOAT_EQ(c[2], 28.0f);
}

TEST(OpsTest, Division_ElementWise)
{
    auto a = Tensor<float>::from_list({10, 20, 30});
    auto b = Tensor<float>::from_list({2, 4, 5});
    auto c = a / b;
    
    EXPECT_FLOAT_EQ(c[0], 5.0f);
    EXPECT_FLOAT_EQ(c[1], 5.0f);
    EXPECT_FLOAT_EQ(c[2], 6.0f);
}

// ============================================================================
// Unary Operations
// ============================================================================

TEST(OpsTest, Negation_Correct)
{
    auto a = Tensor<float>::from_list({1, -2, 3});
    auto b = -a;
    
    EXPECT_FLOAT_EQ(b[0], -1.0f);
    EXPECT_FLOAT_EQ(b[1], 2.0f);
    EXPECT_FLOAT_EQ(b[2], -3.0f);
}

// ============================================================================
// Scalar Operations
// ============================================================================

TEST(OpsTest, AddScalar_TensorOnLeft)
{
    auto a = Tensor<float>::from_list({1, 2, 3});
    auto b = a + 10.0f;
    
    EXPECT_FLOAT_EQ(b[0], 11.0f);
    EXPECT_FLOAT_EQ(b[1], 12.0f);
    EXPECT_FLOAT_EQ(b[2], 13.0f);
}

TEST(OpsTest, AddScalar_ScalarOnLeft)
{
    auto a = Tensor<float>::from_list({1, 2, 3});
    auto b = 10.0f + a;
    
    EXPECT_FLOAT_EQ(b[0], 11.0f);
    EXPECT_FLOAT_EQ(b[1], 12.0f);
    EXPECT_FLOAT_EQ(b[2], 13.0f);
}

TEST(OpsTest, SubtractScalar_TensorOnLeft)
{
    auto a = Tensor<float>::from_list({10, 20, 30});
    auto b = a - 5.0f;
    
    EXPECT_FLOAT_EQ(b[0], 5.0f);
    EXPECT_FLOAT_EQ(b[1], 15.0f);
    EXPECT_FLOAT_EQ(b[2], 25.0f);
}

TEST(OpsTest, SubtractScalar_ScalarOnLeft)
{
    auto a = Tensor<float>::from_list({1, 2, 3});
    auto b = 10.0f - a;
    
    EXPECT_FLOAT_EQ(b[0], 9.0f);
    EXPECT_FLOAT_EQ(b[1], 8.0f);
    EXPECT_FLOAT_EQ(b[2], 7.0f);
}

TEST(OpsTest, MultiplyScalar)
{
    auto a = Tensor<float>::from_list({1, 2, 3});
    auto b = a * 2.0f;
    auto c = 2.0f * a;
    
    EXPECT_TRUE(b.allclose(c));
    EXPECT_FLOAT_EQ(b[0], 2.0f);
    EXPECT_FLOAT_EQ(b[2], 6.0f);
}

TEST(OpsTest, DivideScalar_TensorOnLeft)
{
    auto a = Tensor<float>::from_list({10, 20, 30});
    auto b = a / 2.0f;
    
    EXPECT_FLOAT_EQ(b[0], 5.0f);
    EXPECT_FLOAT_EQ(b[1], 10.0f);
    EXPECT_FLOAT_EQ(b[2], 15.0f);
}

TEST(OpsTest, DivideScalar_ScalarOnLeft)
{
    auto a = Tensor<float>::from_list({1, 2, 4});
    auto b = 8.0f / a;
    
    EXPECT_FLOAT_EQ(b[0], 8.0f);
    EXPECT_FLOAT_EQ(b[1], 4.0f);
    EXPECT_FLOAT_EQ(b[2], 2.0f);
}

// ============================================================================
// Compound Assignment
// ============================================================================

TEST(OpsTest, PlusEquals_Tensor)
{
    auto a = Tensor<float>::from_list({1, 2, 3});
    auto b = Tensor<float>::from_list({4, 5, 6});
    a += b;
    
    EXPECT_FLOAT_EQ(a[0], 5.0f);
    EXPECT_FLOAT_EQ(a[1], 7.0f);
    EXPECT_FLOAT_EQ(a[2], 9.0f);
}

TEST(OpsTest, PlusEquals_Scalar)
{
    auto a = Tensor<float>::from_list({1, 2, 3});
    a += 10.0f;
    
    EXPECT_FLOAT_EQ(a[0], 11.0f);
    EXPECT_FLOAT_EQ(a[1], 12.0f);
    EXPECT_FLOAT_EQ(a[2], 13.0f);
}

TEST(OpsTest, TimesEquals_Scalar)
{
    auto a = Tensor<float>::from_list({1, 2, 3});
    a *= 2.0f;
    
    EXPECT_FLOAT_EQ(a[0], 2.0f);
    EXPECT_FLOAT_EQ(a[1], 4.0f);
    EXPECT_FLOAT_EQ(a[2], 6.0f);
}

// ============================================================================
// Math Functions
// ============================================================================

TEST(OpsTest, Exp_Correct)
{
    auto a = Tensor<float>::from_list({0.0f, 1.0f, 2.0f});
    auto b = exp(a);
    
    EXPECT_FLOAT_EQ(b[0], 1.0f);
    EXPECT_NEAR(b[1], 2.718281828f, 1e-5f);
    EXPECT_NEAR(b[2], 7.389056099f, 1e-5f);
}

TEST(OpsTest, Log_Correct)
{
    auto a = Tensor<float>::from_list({1.0f, std::exp(1.0f), std::exp(2.0f)});
    auto b = log(a);
    
    EXPECT_NEAR(b[0], 0.0f, 1e-6f);
    EXPECT_NEAR(b[1], 1.0f, 1e-6f);
    EXPECT_NEAR(b[2], 2.0f, 1e-6f);
}

TEST(OpsTest, Pow_Correct)
{
    auto a = Tensor<float>::from_list({2.0f, 3.0f, 4.0f});
    auto b = pow(a, 2.0f);
    
    EXPECT_FLOAT_EQ(b[0], 4.0f);
    EXPECT_FLOAT_EQ(b[1], 9.0f);
    EXPECT_FLOAT_EQ(b[2], 16.0f);
}

TEST(OpsTest, Sqrt_Correct)
{
    auto a = Tensor<float>::from_list({1.0f, 4.0f, 9.0f, 16.0f});
    auto b = sqrt(a);
    
    EXPECT_FLOAT_EQ(b[0], 1.0f);
    EXPECT_FLOAT_EQ(b[1], 2.0f);
    EXPECT_FLOAT_EQ(b[2], 3.0f);
    EXPECT_FLOAT_EQ(b[3], 4.0f);
}

TEST(OpsTest, Abs_Correct)
{
    auto a = Tensor<float>::from_list({-1.0f, 2.0f, -3.0f});
    auto b = abs(a);
    
    EXPECT_FLOAT_EQ(b[0], 1.0f);
    EXPECT_FLOAT_EQ(b[1], 2.0f);
    EXPECT_FLOAT_EQ(b[2], 3.0f);
}

TEST(OpsTest, ReLU_Correct)
{
    auto a = Tensor<float>::from_list({-2.0f, -1.0f, 0.0f, 1.0f, 2.0f});
    auto b = relu(a);
    
    EXPECT_FLOAT_EQ(b[0], 0.0f);
    EXPECT_FLOAT_EQ(b[1], 0.0f);
    EXPECT_FLOAT_EQ(b[2], 0.0f);
    EXPECT_FLOAT_EQ(b[3], 1.0f);
    EXPECT_FLOAT_EQ(b[4], 2.0f);
}

TEST(OpsTest, Sigmoid_Correct)
{
    auto a = Tensor<float>::from_list({-10.0f, 0.0f, 10.0f});
    auto b = sigmoid(a);
    
    EXPECT_NEAR(b[0], 0.0f, 1e-4f);       // sigmoid(-10) ≈ 0
    EXPECT_FLOAT_EQ(b[1], 0.5f);          // sigmoid(0) = 0.5
    EXPECT_NEAR(b[2], 1.0f, 1e-4f);       // sigmoid(10) ≈ 1
}

TEST(OpsTest, Tanh_Correct)
{
    auto a = Tensor<float>::from_list({-10.0f, 0.0f, 10.0f});
    auto b = tanh(a);
    
    EXPECT_NEAR(b[0], -1.0f, 1e-4f);
    EXPECT_FLOAT_EQ(b[1], 0.0f);
    EXPECT_NEAR(b[2], 1.0f, 1e-4f);
}

// ============================================================================
// Linear Algebra
// ============================================================================

TEST(OpsTest, Dot_Correct)
{
    auto a = Tensor<float>::from_list({1, 2, 3});
    auto b = Tensor<float>::from_list({4, 5, 6});
    float result = dot(a, b);
    
    // 1*4 + 2*5 + 3*6 = 4 + 10 + 18 = 32
    EXPECT_FLOAT_EQ(result, 32.0f);
}

TEST(OpsTest, Dot_SizeMismatch_Throws)
{
    auto a = Tensor<float>::from_list({1, 2, 3});
    auto b = Tensor<float>::from_list({1, 2});
    EXPECT_THROW(dot(a, b), std::invalid_argument);
}

TEST(OpsTest, Matmul_2x3_times_3x4)
{
    // A: 2x3 matrix
    auto a = Tensor<float>::from_data({2, 3}, 
        std::vector<float>{1, 2, 3, 4, 5, 6}.data());
    
    // B: 3x4 matrix  
    auto b = Tensor<float>::from_data({3, 4},
        std::vector<float>{1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12}.data());
    
    auto c = matmul(a, b);
    
    EXPECT_EQ(c.shape()[0], 2);
    EXPECT_EQ(c.shape()[1], 4);
    
    // c[0,0] = 1*1 + 2*5 + 3*9 = 1 + 10 + 27 = 38
    EXPECT_FLOAT_EQ(c(0, 0), 38.0f);
}

TEST(OpsTest, Matmul_Identity)
{
    // Identity matrix
    auto eye = Tensor<float>::zeros({3, 3});
    eye(0, 0) = 1.0f;
    eye(1, 1) = 1.0f;
    eye(2, 2) = 1.0f;
    
    auto a = Tensor<float>::rand({3, 3});
    auto b = matmul(a, eye);
    
    EXPECT_TRUE(a.allclose(b));
}

TEST(OpsTest, Matmul_ShapeMismatch_Throws)
{
    auto a = Tensor<float>::zeros({2, 3});
    auto b = Tensor<float>::zeros({4, 5});  // 3 != 4
    EXPECT_THROW(matmul(a, b), std::invalid_argument);
}

TEST(OpsTest, Transpose_2D)
{
    auto a = Tensor<float>::from_data({2, 3},
        std::vector<float>{1, 2, 3, 4, 5, 6}.data());
    auto b = transpose(a);
    
    EXPECT_EQ(b.shape()[0], 3);
    EXPECT_EQ(b.shape()[1], 2);
    
    EXPECT_FLOAT_EQ(b(0, 0), 1.0f);  // a(0,0)
    EXPECT_FLOAT_EQ(b(0, 1), 4.0f);  // a(1,0)
    EXPECT_FLOAT_EQ(b(2, 0), 3.0f);  // a(0,2)
    EXPECT_FLOAT_EQ(b(2, 1), 6.0f);  // a(1,2)
}

TEST(OpsTest, Transpose_Twice_IsIdentity)
{
    auto a = Tensor<float>::rand({3, 5});
    auto b = transpose(transpose(a));
    EXPECT_TRUE(a.allclose(b));
}

// ============================================================================
// Expression Chaining (Phase 2 Preview)
// ============================================================================

TEST(OpsTest, ChainedOperations_Correct)
{
    auto a = Tensor<float>::ones({3});
    auto b = Tensor<float>::ones({3});
    
    // (a + b) * 2 - 1
    auto c = (a + b) * 2.0f - 1.0f;
    
    // Each element: (1 + 1) * 2 - 1 = 3
    EXPECT_FLOAT_EQ(c[0], 3.0f);
    EXPECT_FLOAT_EQ(c[1], 3.0f);
    EXPECT_FLOAT_EQ(c[2], 3.0f);
}
