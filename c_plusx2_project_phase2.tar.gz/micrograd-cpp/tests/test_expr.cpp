// filepath: tests/test_expr.cpp
// Expression Template Tests - Phase 2
// Verifies: lazy evaluation, CRTP, zero temporaries, correctness
#include <gtest/gtest.h>
#include "expr/expr.hpp"

using namespace micrograd;

// ============================================================================
// Basic Expression Tests
// ============================================================================

TEST(ExprTest, TensorExpr_Construct_ValidShape)
{
    TensorExpr<float> t({2, 3, 4});
    EXPECT_EQ(t.size(), 24);
    EXPECT_EQ(t.ndim(), 3);
}

TEST(ExprTest, TensorExpr_Fill_AllElements)
{
    TensorExpr<float> t({10});
    t.fill(3.14f);
    for (size_t i = 0; i < t.size(); ++i) {
        EXPECT_FLOAT_EQ(t[i], 3.14f);
    }
}

TEST(ExprTest, TensorExpr_FromList_Correct)
{
    auto t = TensorExpr<float>::from_list({1.0f, 2.0f, 3.0f, 4.0f, 5.0f});
    EXPECT_EQ(t.size(), 5);
    EXPECT_FLOAT_EQ(t[0], 1.0f);
    EXPECT_FLOAT_EQ(t[4], 5.0f);
}

// ============================================================================
// Expression Evaluation Tests
// ============================================================================

TEST(ExprTest, Add_TwoTensors_Correct)
{
    auto a = TensorExpr<float>::from_list({1.0f, 2.0f, 3.0f});
    auto b = TensorExpr<float>::from_list({4.0f, 5.0f, 6.0f});
    
    // a + b returns an expression, not a tensor
    auto expr = a + b;
    
    // Evaluate at specific indices
    EXPECT_FLOAT_EQ(expr[0], 5.0f);
    EXPECT_FLOAT_EQ(expr[1], 7.0f);
    EXPECT_FLOAT_EQ(expr[2], 9.0f);
}

TEST(ExprTest, Sub_TwoTensors_Correct)
{
    auto a = TensorExpr<float>::from_list({10.0f, 20.0f, 30.0f});
    auto b = TensorExpr<float>::from_list({1.0f, 2.0f, 3.0f});
    
    auto expr = a - b;
    
    EXPECT_FLOAT_EQ(expr[0], 9.0f);
    EXPECT_FLOAT_EQ(expr[1], 18.0f);
    EXPECT_FLOAT_EQ(expr[2], 27.0f);
}

TEST(ExprTest, Mul_TwoTensors_Correct)
{
    auto a = TensorExpr<float>::from_list({2.0f, 3.0f, 4.0f});
    auto b = TensorExpr<float>::from_list({5.0f, 6.0f, 7.0f});
    
    auto expr = a * b;
    
    EXPECT_FLOAT_EQ(expr[0], 10.0f);
    EXPECT_FLOAT_EQ(expr[1], 18.0f);
    EXPECT_FLOAT_EQ(expr[2], 28.0f);
}

TEST(ExprTest, Div_TwoTensors_Correct)
{
    auto a = TensorExpr<float>::from_list({10.0f, 20.0f, 30.0f});
    auto b = TensorExpr<float>::from_list({2.0f, 4.0f, 5.0f});
    
    auto expr = a / b;
    
    EXPECT_FLOAT_EQ(expr[0], 5.0f);
    EXPECT_FLOAT_EQ(expr[1], 5.0f);
    EXPECT_FLOAT_EQ(expr[2], 6.0f);
}

// ============================================================================
// Scalar Operations
// ============================================================================

TEST(ExprTest, AddScalar_Right_Correct)
{
    auto a = TensorExpr<float>::from_list({1.0f, 2.0f, 3.0f});
    auto expr = a + 10.0f;
    
    EXPECT_FLOAT_EQ(expr[0], 11.0f);
    EXPECT_FLOAT_EQ(expr[1], 12.0f);
    EXPECT_FLOAT_EQ(expr[2], 13.0f);
}

TEST(ExprTest, AddScalar_Left_Correct)
{
    auto a = TensorExpr<float>::from_list({1.0f, 2.0f, 3.0f});
    auto expr = 10.0f + a;
    
    EXPECT_FLOAT_EQ(expr[0], 11.0f);
    EXPECT_FLOAT_EQ(expr[1], 12.0f);
    EXPECT_FLOAT_EQ(expr[2], 13.0f);
}

TEST(ExprTest, MulScalar_Correct)
{
    auto a = TensorExpr<float>::from_list({1.0f, 2.0f, 3.0f});
    auto expr = a * 2.0f;
    
    EXPECT_FLOAT_EQ(expr[0], 2.0f);
    EXPECT_FLOAT_EQ(expr[1], 4.0f);
    EXPECT_FLOAT_EQ(expr[2], 6.0f);
}

TEST(ExprTest, SubScalar_Right_Correct)
{
    auto a = TensorExpr<float>::from_list({10.0f, 20.0f, 30.0f});
    auto expr = a - 5.0f;
    
    EXPECT_FLOAT_EQ(expr[0], 5.0f);
    EXPECT_FLOAT_EQ(expr[1], 15.0f);
    EXPECT_FLOAT_EQ(expr[2], 25.0f);
}

TEST(ExprTest, SubScalar_Left_Correct)
{
    auto a = TensorExpr<float>::from_list({1.0f, 2.0f, 3.0f});
    auto expr = 10.0f - a;
    
    EXPECT_FLOAT_EQ(expr[0], 9.0f);
    EXPECT_FLOAT_EQ(expr[1], 8.0f);
    EXPECT_FLOAT_EQ(expr[2], 7.0f);
}

TEST(ExprTest, DivScalar_Right_Correct)
{
    auto a = TensorExpr<float>::from_list({10.0f, 20.0f, 30.0f});
    auto expr = a / 2.0f;
    
    EXPECT_FLOAT_EQ(expr[0], 5.0f);
    EXPECT_FLOAT_EQ(expr[1], 10.0f);
    EXPECT_FLOAT_EQ(expr[2], 15.0f);
}

TEST(ExprTest, DivScalar_Left_Correct)
{
    auto a = TensorExpr<float>::from_list({1.0f, 2.0f, 4.0f});
    auto expr = 8.0f / a;
    
    EXPECT_FLOAT_EQ(expr[0], 8.0f);
    EXPECT_FLOAT_EQ(expr[1], 4.0f);
    EXPECT_FLOAT_EQ(expr[2], 2.0f);
}

// ============================================================================
// Unary Operations
// ============================================================================

TEST(ExprTest, Negation_Correct)
{
    auto a = TensorExpr<float>::from_list({1.0f, -2.0f, 3.0f});
    auto expr = -a;
    
    EXPECT_FLOAT_EQ(expr[0], -1.0f);
    EXPECT_FLOAT_EQ(expr[1], 2.0f);
    EXPECT_FLOAT_EQ(expr[2], -3.0f);
}

// ============================================================================
// Math Functions
// ============================================================================

TEST(ExprTest, Exp_Correct)
{
    auto a = TensorExpr<float>::from_list({0.0f, 1.0f});
    auto expr = expr::exp(a);
    
    EXPECT_FLOAT_EQ(expr[0], 1.0f);
    EXPECT_NEAR(expr[1], 2.718281828f, 1e-5f);
}

TEST(ExprTest, Log_Correct)
{
    auto a = TensorExpr<float>::from_list({1.0f, std::exp(1.0f)});
    auto expr = expr::log(a);
    
    EXPECT_NEAR(expr[0], 0.0f, 1e-6f);
    EXPECT_NEAR(expr[1], 1.0f, 1e-6f);
}

TEST(ExprTest, Sqrt_Correct)
{
    auto a = TensorExpr<float>::from_list({1.0f, 4.0f, 9.0f});
    auto expr = expr::sqrt(a);
    
    EXPECT_FLOAT_EQ(expr[0], 1.0f);
    EXPECT_FLOAT_EQ(expr[1], 2.0f);
    EXPECT_FLOAT_EQ(expr[2], 3.0f);
}

TEST(ExprTest, ReLU_Correct)
{
    auto a = TensorExpr<float>::from_list({-2.0f, -1.0f, 0.0f, 1.0f, 2.0f});
    auto expr = expr::relu(a);
    
    EXPECT_FLOAT_EQ(expr[0], 0.0f);
    EXPECT_FLOAT_EQ(expr[1], 0.0f);
    EXPECT_FLOAT_EQ(expr[2], 0.0f);
    EXPECT_FLOAT_EQ(expr[3], 1.0f);
    EXPECT_FLOAT_EQ(expr[4], 2.0f);
}

TEST(ExprTest, Sigmoid_Correct)
{
    auto a = TensorExpr<float>::from_list({0.0f});
    auto expr = expr::sigmoid(a);
    
    EXPECT_FLOAT_EQ(expr[0], 0.5f);
}

TEST(ExprTest, Tanh_Correct)
{
    auto a = TensorExpr<float>::from_list({0.0f});
    auto expr = expr::tanh(a);
    
    EXPECT_FLOAT_EQ(expr[0], 0.0f);
}

// ============================================================================
// Chained Operations (The Key Test!)
// ============================================================================

TEST(ExprTest, Chain_AddAddAdd_Correct)
{
    auto a = TensorExpr<float>::from_list({1.0f, 2.0f, 3.0f});
    auto b = TensorExpr<float>::from_list({4.0f, 5.0f, 6.0f});
    auto c = TensorExpr<float>::from_list({7.0f, 8.0f, 9.0f});
    
    // This builds: AddExpr<AddExpr<a, b>, c>
    // NO intermediate allocations!
    auto expr = a + b + c;
    
    // Verify correctness
    EXPECT_FLOAT_EQ(expr[0], 12.0f);  // 1 + 4 + 7
    EXPECT_FLOAT_EQ(expr[1], 15.0f);  // 2 + 5 + 8
    EXPECT_FLOAT_EQ(expr[2], 18.0f);  // 3 + 6 + 9
}

TEST(ExprTest, Chain_MixedOps_Correct)
{
    auto a = TensorExpr<float>::from_list({1.0f, 2.0f, 3.0f});
    auto b = TensorExpr<float>::from_list({4.0f, 5.0f, 6.0f});
    
    // (a + b) * 2 - 1
    auto expr = (a + b) * 2.0f - 1.0f;
    
    // (1+4)*2-1 = 9, (2+5)*2-1 = 13, (3+6)*2-1 = 17
    EXPECT_FLOAT_EQ(expr[0], 9.0f);
    EXPECT_FLOAT_EQ(expr[1], 13.0f);
    EXPECT_FLOAT_EQ(expr[2], 17.0f);
}

TEST(ExprTest, Chain_ComplexExpression_Correct)
{
    auto a = TensorExpr<float>::from_list({1.0f, 2.0f});
    auto b = TensorExpr<float>::from_list({3.0f, 4.0f});
    auto c = TensorExpr<float>::from_list({5.0f, 6.0f});
    
    // a * b + c * 2
    auto expr = a * b + c * 2.0f;
    
    // 1*3 + 5*2 = 13, 2*4 + 6*2 = 20
    EXPECT_FLOAT_EQ(expr[0], 13.0f);
    EXPECT_FLOAT_EQ(expr[1], 20.0f);
}

// ============================================================================
// Materialization Tests
// ============================================================================

TEST(ExprTest, Materialize_Constructor_Correct)
{
    auto a = TensorExpr<float>::from_list({1.0f, 2.0f, 3.0f});
    auto b = TensorExpr<float>::from_list({4.0f, 5.0f, 6.0f});
    
    // Expression tree
    auto expr = a + b;
    
    // Materialize via constructor
    TensorExpr<float> result = expr;
    
    EXPECT_EQ(result.size(), 3);
    EXPECT_FLOAT_EQ(result[0], 5.0f);
    EXPECT_FLOAT_EQ(result[1], 7.0f);
    EXPECT_FLOAT_EQ(result[2], 9.0f);
}

TEST(ExprTest, Materialize_Assignment_Correct)
{
    auto a = TensorExpr<float>::from_list({1.0f, 2.0f, 3.0f});
    auto b = TensorExpr<float>::from_list({4.0f, 5.0f, 6.0f});
    
    TensorExpr<float> result({3});
    result.fill(0.0f);
    
    // Materialize via assignment
    result = a + b;
    
    EXPECT_FLOAT_EQ(result[0], 5.0f);
    EXPECT_FLOAT_EQ(result[1], 7.0f);
    EXPECT_FLOAT_EQ(result[2], 9.0f);
}

TEST(ExprTest, Materialize_ChainedExpression_Correct)
{
    auto a = TensorExpr<float>::from_list({1.0f, 2.0f, 3.0f});
    auto b = TensorExpr<float>::from_list({1.0f, 1.0f, 1.0f});
    
    // Complex chain: (a + b) * (a - b) + 1
    // = (a² - b²) + 1
    // = (1-1)+1, (4-1)+1, (9-1)+1 = 1, 4, 9
    auto expr = (a + b) * (a - b) + 1.0f;
    
    TensorExpr<float> result = expr;
    
    EXPECT_FLOAT_EQ(result[0], 1.0f);
    EXPECT_FLOAT_EQ(result[1], 4.0f);
    EXPECT_FLOAT_EQ(result[2], 9.0f);
}

// ============================================================================
// Large Tensor Test (Performance Sanity)
// ============================================================================

TEST(ExprTest, LargeTensor_ChainedOps_NoTimeout)
{
    const size_t N = 1000000;  // 1 million elements
    
    auto a = TensorExpr<float>::ones({N});
    auto b = TensorExpr<float>::ones({N});
    auto c = TensorExpr<float>::ones({N});
    
    // This should be fast - single pass, no intermediates
    TensorExpr<float> result = a + b + c;
    
    EXPECT_EQ(result.size(), N);
    EXPECT_FLOAT_EQ(result[0], 3.0f);
    EXPECT_FLOAT_EQ(result[N-1], 3.0f);
}

// ============================================================================
// Rule of 5 Tests for TensorExpr
// ============================================================================

TEST(ExprTest, TensorExpr_CopyConstruct_DeepCopy)
{
    auto original = TensorExpr<float>::from_list({1.0f, 2.0f, 3.0f});
    TensorExpr<float> copy(original);
    
    copy[0] = 999.0f;
    EXPECT_FLOAT_EQ(original[0], 1.0f);  // Original unchanged
}

TEST(ExprTest, TensorExpr_MoveConstruct_TransferOwnership)
{
    auto original = TensorExpr<float>::from_list({1.0f, 2.0f, 3.0f});
    TensorExpr<float> moved(std::move(original));
    
    EXPECT_EQ(moved.size(), 3);
    EXPECT_TRUE(original.empty());
}

// ============================================================================
// Edge Cases
// ============================================================================

TEST(ExprTest, SingleElement_Works)
{
    auto a = TensorExpr<float>::from_list({42.0f});
    auto b = TensorExpr<float>::from_list({8.0f});
    
    TensorExpr<float> result = a + b;
    
    EXPECT_EQ(result.size(), 1);
    EXPECT_FLOAT_EQ(result[0], 50.0f);
}

TEST(ExprTest, NestedMathFunctions_Correct)
{
    auto a = TensorExpr<float>::from_list({1.0f, 4.0f, 9.0f});
    
    // sqrt(sqrt(a))
    auto expr = expr::sqrt(expr::sqrt(a));
    
    EXPECT_FLOAT_EQ(expr[0], 1.0f);
    EXPECT_NEAR(expr[1], std::sqrt(2.0f), 1e-6f);
    EXPECT_NEAR(expr[2], std::sqrt(3.0f), 1e-6f);
}
