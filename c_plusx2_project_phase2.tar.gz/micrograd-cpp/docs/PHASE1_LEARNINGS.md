# Phase 1 Learnings: C++ Foundations

**Completed:** Phase 1 of MicroGrad++  
**Level:** Undergraduate  
**Duration:** Weeks 1-3

---

## 🎓 What You Learned

### 1. RAII (Resource Acquisition Is Initialization)

**Concept:** Resources (memory, file handles, locks) are tied to object lifetime. Acquire in constructor, release in destructor.

**Why it matters:** Prevents resource leaks. No manual cleanup needed.

```cpp
// RAII in action: unique_ptr manages memory automatically
class Tensor {
    std::unique_ptr<T[]> data_;  // Acquired in ctor, freed in dtor
public:
    Tensor(Shape shape) 
        : data_(std::make_unique<T[]>(size())) {}  // Acquire
    ~Tensor() = default;  // unique_ptr auto-releases
};
```

**Key insight:** If you never write `delete`, you never leak memory.

---

### 2. Rule of 5

**Concept:** If a class manages resources, you must define all 5 special member functions:

| Function | Purpose |
|----------|---------|
| `~Tensor()` | Destructor - cleanup |
| `Tensor(const Tensor&)` | Copy constructor - deep copy |
| `Tensor(Tensor&&)` | Move constructor - transfer ownership |
| `Tensor& operator=(const Tensor&)` | Copy assignment |
| `Tensor& operator=(Tensor&&)` | Move assignment |

**Why it matters:** Compiler-generated defaults do shallow copies (pointer copy = double-free bug).

```cpp
// Copy constructor: deep copy (allocate + copy data)
Tensor(const Tensor& other)
    : shape_(other.shape_)
    , data_(std::make_unique<T[]>(other.size())) {
    std::copy(other.data_.get(), other.data_.get() + size(), data_.get());
}

// Move constructor: steal resources (no allocation)
Tensor(Tensor&& other) noexcept
    : shape_(std::move(other.shape_))
    , data_(std::move(other.data_)) {
    other.shape_.clear();  // Leave other in valid empty state
}
```

**Key insight:** Copy is expensive (O(n)), move is cheap (O(1)).

---

### 3. Smart Pointers

**Concept:** RAII wrappers around raw pointers that automatically manage lifetime.

| Type | Ownership | Use Case |
|------|-----------|----------|
| `unique_ptr<T>` | Exclusive | Single owner (Tensor's data) |
| `shared_ptr<T>` | Shared | Multiple owners (graph nodes) |
| `weak_ptr<T>` | Non-owning | Break cycles, observers |

```cpp
// unique_ptr for array storage
std::unique_ptr<T[]> data_ = std::make_unique<T[]>(size);

// Access underlying pointer when needed
T* raw = data_.get();
```

**Key insight:** `unique_ptr` has zero overhead vs raw pointer.

---

### 4. Templates

**Concept:** Generic programming - write code once, use with any type.

```cpp
// Class template
template<typename T = float>
class Tensor { ... };

// Function template
template<typename T>
Tensor<T> operator+(const Tensor<T>& a, const Tensor<T>& b);

// Usage - type deduction
Tensor<float> a({2, 3});
Tensor<double> b({2, 3});
auto c = a + a;  // T deduced as float
```

**Type constraints (C++20):**
```cpp
template<typename T>
requires std::is_arithmetic_v<T>  // Only numeric types
class Tensor { ... };

// Or using concepts
template<std::floating_point T>
class Tensor { ... };
```

**Key insight:** Templates are compile-time code generation.

---

### 5. Operator Overloading

**Concept:** Define custom behavior for operators on your types.

```cpp
// Element access
T& operator[](size_t i) { return data_[i]; }

// Multi-dimensional access
template<typename... Indices>
T& operator()(Indices... indices);

// Arithmetic
Tensor<T> operator+(const Tensor<T>& a, const Tensor<T>& b);

// Stream output
friend std::ostream& operator<<(std::ostream& os, const Tensor& t);
```

**Key insight:** Operators are just functions with special syntax.

---

### 6. CMake Build System

**Concept:** Cross-platform build configuration.

```cmake
# Minimum structure
cmake_minimum_required(VERSION 3.16)
project(micrograd_cpp LANGUAGES CXX)

set(CMAKE_CXX_STANDARD 20)

# Header-only library
add_library(micrograd INTERFACE)
target_include_directories(micrograd INTERFACE src/)

# Tests
add_executable(test_tensor tests/test_tensor.cpp)
target_link_libraries(test_tensor PRIVATE micrograd GTest::gtest)
```

**Build commands:**
```bash
cmake -B build -DCMAKE_BUILD_TYPE=Debug
cmake --build build -j
ctest --test-dir build
```

**Key insight:** CMake generates native build files (Makefiles, Ninja, VS solutions).

---

### 7. GoogleTest

**Concept:** Unit testing framework.

```cpp
TEST(TensorTest, Constructor_ValidShape_CreatesCorrectSize) {
    Tensor<float> t({2, 3, 4});
    EXPECT_EQ(t.size(), 24);  // Non-fatal assertion
    ASSERT_FALSE(t.empty()); // Fatal assertion (stops test)
}

// Floating point comparison
EXPECT_FLOAT_EQ(a, b);      // Exact (4 ULP)
EXPECT_NEAR(a, b, epsilon); // With tolerance

// Exception testing
EXPECT_THROW(Tensor<float>({}), std::invalid_argument);
```

**Key insight:** Tests document expected behavior and catch regressions.

---

## 🔑 Key Patterns Learned

### Copy-and-Swap Idiom
Exception-safe assignment via temporary:
```cpp
Tensor& operator=(const Tensor& other) {
    Tensor tmp(other);  // Copy
    swap(*this, tmp);   // Swap
    return *this;       // tmp destructor cleans old data
}
```

### Explicit Constructors
Prevent implicit conversions:
```cpp
explicit Tensor(Shape shape);  // Tensor t = {2,3} won't compile
```

### [[nodiscard]] Attribute
Compiler warns if return value ignored:
```cpp
[[nodiscard]] Tensor clone() const;
```

---

## 📊 Metrics Achieved

| Metric | Target | Actual |
|--------|--------|--------|
| Memory leaks | 0 | 0 (valgrind clean) |
| Test coverage | >80% | ~95% |
| Build time | <10s | ~5s |
| Sanitizer errors | 0 | 0 |

---

## 🔗 Zuup/Visionblox Application

| Technique | Platform Application |
|-----------|---------------------|
| **RAII** | Aureon: Database connections, Symbion: Sensor handles |
| **Templates** | Type-safe procurement data, compliance validators |
| **Rule of 5** | Relian: Safe legacy system wrappers |
| **CMake** | All platforms: Reproducible builds, CI/CD |
| **Testing** | All platforms: Contract enforcement |

---

## ➡️ Next Phase Preview

**Phase 2: Expression Templates** will introduce:
- CRTP (Curiously Recurring Template Pattern)
- Lazy evaluation
- Eliminating temporary allocations
- `a + b + c` compiles to single loop

---

*Generated for MicroGrad++ learning project*
