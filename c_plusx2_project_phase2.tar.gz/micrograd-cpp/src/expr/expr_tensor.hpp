// filepath: src/expr/expr_tensor.hpp
// TensorExpr - Bridge between Tensor and Expression Templates
// Phase 2: Lazy evaluation materialization
#pragma once

#include "expr_base.hpp"
#include "expr_ops.hpp"
#include "../shape.hpp"

#include <memory>
#include <algorithm>
#include <cassert>
#include <iostream>
#include <iomanip>
#include <random>
#include <cmath>

namespace micrograd {

/// @brief Expression-enabled Tensor with lazy evaluation support
/// @tparam T Scalar element type
/// 
/// This is an enhanced version of Tensor that:
/// 1. Satisfies the Expression concept (can be used in expr chains)
/// 2. Can be constructed from any Expression (materializes lazy results)
/// 3. Provides the same API as Phase 1 Tensor
/// 
/// Key difference from Phase 1:
/// - `a + b + c` returns an expression TYPE, not a Tensor
/// - Computation only happens when assigned to a Tensor
/// - Zero intermediate allocations
/// 
/// @example
/// ```cpp
/// TensorExpr<float> a({1000000}), b({1000000}), c({1000000});
/// 
/// // This builds an expression tree, NO computation yet
/// auto expr = a + b * c - 2.0f;
/// 
/// // Computation happens HERE, in a single pass
/// TensorExpr<float> result = expr;  // One allocation, one loop
/// ```
template<typename T = float>
class TensorExpr
{
    static_assert(std::is_arithmetic_v<T>, "TensorExpr requires arithmetic type");

public:
    // Required for Expression concept
    using value_type = T;
    using size_type = size_t;

    // ========================================================================
    // Constructors
    // ========================================================================

    /// @brief Default constructor - empty tensor
    TensorExpr() noexcept = default;

    /// @brief Construct with shape (uninitialized data)
    explicit TensorExpr(Shape shape)
        : shape_(std::move(shape))
        , strides_(shape_strides(shape_))
        , data_(std::make_unique<T[]>(this->size()))
    {
        validate_shape(shape_);
    }

    /// @brief Construct from initializer list shape
    explicit TensorExpr(std::initializer_list<size_t> shape)
        : TensorExpr(Shape(shape))
    {}

    /// @brief Construct from ANY expression (materializes lazy computation)
    /// @tparam E Expression type
    /// @param expr The expression to evaluate
    /// 
    /// This is where the magic happens:
    /// - expr is a tree of BinaryExpr/UnaryExpr types
    /// - We allocate ONE buffer
    /// - Single loop evaluates entire expression
    template<typename E>
    requires expr::Expression<E> && (!std::is_same_v<std::decay_t<E>, TensorExpr<T>>)
    TensorExpr(const E& expr)
        : data_(std::make_unique<T[]>(expr.size()))
    {
        // Determine shape from expression (assume 1D for now)
        // In production, would propagate shape through expressions
        shape_ = {expr.size()};
        strides_ = shape_strides(shape_);

        // Single-pass evaluation - this is the entire computation
        for (size_t i = 0; i < expr.size(); ++i) {
            data_[i] = expr[i];
        }
    }

    // ========================================================================
    // Rule of 5
    // ========================================================================

    ~TensorExpr() = default;

    TensorExpr(const TensorExpr& other)
        : shape_(other.shape_)
        , strides_(other.strides_)
        , data_(other.data_ ? std::make_unique<T[]>(other.size()) : nullptr)
    {
        if (data_) {
            std::copy(other.data_.get(), other.data_.get() + size(), data_.get());
        }
    }

    TensorExpr(TensorExpr&& other) noexcept
        : shape_(std::move(other.shape_))
        , strides_(std::move(other.strides_))
        , data_(std::move(other.data_))
    {
        other.shape_.clear();
        other.strides_.clear();
    }

    TensorExpr& operator=(const TensorExpr& other)
    {
        if (this != &other) {
            TensorExpr tmp(other);
            swap(*this, tmp);
        }
        return *this;
    }

    TensorExpr& operator=(TensorExpr&& other) noexcept
    {
        if (this != &other) {
            shape_ = std::move(other.shape_);
            strides_ = std::move(other.strides_);
            data_ = std::move(other.data_);
            other.shape_.clear();
            other.strides_.clear();
        }
        return *this;
    }

    /// @brief Assign from expression (materializes lazy computation)
    template<typename E>
    requires expr::Expression<E> && (!std::is_same_v<std::decay_t<E>, TensorExpr<T>>)
    TensorExpr& operator=(const E& expr)
    {
        // Resize if needed
        if (size() != expr.size()) {
            shape_ = {expr.size()};
            strides_ = shape_strides(shape_);
            data_ = std::make_unique<T[]>(expr.size());
        }

        // Evaluate expression in single pass
        for (size_t i = 0; i < expr.size(); ++i) {
            data_[i] = expr[i];
        }
        return *this;
    }

    friend void swap(TensorExpr& a, TensorExpr& b) noexcept
    {
        using std::swap;
        swap(a.shape_, b.shape_);
        swap(a.strides_, b.strides_);
        swap(a.data_, b.data_);
    }

    // ========================================================================
    // Factory Methods
    // ========================================================================

    [[nodiscard]] static TensorExpr zeros(Shape shape)
    {
        TensorExpr t(std::move(shape));
        t.fill(T{0});
        return t;
    }

    [[nodiscard]] static TensorExpr ones(Shape shape)
    {
        TensorExpr t(std::move(shape));
        t.fill(T{1});
        return t;
    }

    [[nodiscard]] static TensorExpr rand(Shape shape)
    {
        TensorExpr t(std::move(shape));
        std::random_device rd;
        std::mt19937 gen(rd());
        std::uniform_real_distribution<T> dist(T{0}, T{1});
        for (size_t i = 0; i < t.size(); ++i) {
            t[i] = dist(gen);
        }
        return t;
    }

    [[nodiscard]] static TensorExpr randn(Shape shape)
    {
        TensorExpr t(std::move(shape));
        std::random_device rd;
        std::mt19937 gen(rd());
        std::normal_distribution<T> dist(T{0}, T{1});
        for (size_t i = 0; i < t.size(); ++i) {
            t[i] = dist(gen);
        }
        return t;
    }

    [[nodiscard]] static TensorExpr from_data(Shape shape, const T* data)
    {
        TensorExpr t(std::move(shape));
        std::copy(data, data + t.size(), t.data_.get());
        return t;
    }

    [[nodiscard]] static TensorExpr from_list(std::initializer_list<T> data)
    {
        TensorExpr t(Shape{data.size()});
        std::copy(data.begin(), data.end(), t.data_.get());
        return t;
    }

    // ========================================================================
    // Accessors (Expression concept requirements)
    // ========================================================================

    [[nodiscard]] const Shape& shape() const noexcept { return shape_; }
    [[nodiscard]] const Strides& strides() const noexcept { return strides_; }
    [[nodiscard]] size_t ndim() const noexcept { return shape_.size(); }
    [[nodiscard]] bool empty() const noexcept { return shape_.empty() || !data_; }
    [[nodiscard]] T* data() noexcept { return data_.get(); }
    [[nodiscard]] const T* data() const noexcept { return data_.get(); }

    [[nodiscard]] size_t size() const noexcept
    {
        return shape_size(shape_);
    }

    // ========================================================================
    // Element Access (Expression concept requirements)
    // ========================================================================

    [[nodiscard]] T& operator[](size_t i)
    {
        assert(i < size() && "Index out of bounds");
        return data_[i];
    }

    [[nodiscard]] const T& operator[](size_t i) const
    {
        assert(i < size() && "Index out of bounds");
        return data_[i];
    }

    /// @brief For expression compatibility (same as operator[])
    [[nodiscard]] T eval(size_t i) const
    {
        return data_[i];
    }

    [[nodiscard]] T& at(const std::vector<size_t>& indices)
    {
        return data_[ravel_index(indices, shape_)];
    }

    [[nodiscard]] const T& at(const std::vector<size_t>& indices) const
    {
        return data_[ravel_index(indices, shape_)];
    }

    template<typename... Indices>
    [[nodiscard]] T& operator()(Indices... indices)
    {
        return at({static_cast<size_t>(indices)...});
    }

    template<typename... Indices>
    [[nodiscard]] const T& operator()(Indices... indices) const
    {
        return at({static_cast<size_t>(indices)...});
    }

    // ========================================================================
    // Mutators
    // ========================================================================

    void fill(T value) noexcept
    {
        std::fill(data_.get(), data_.get() + size(), value);
    }

    void zero() noexcept { fill(T{0}); }

    template<typename Fn>
    void apply(Fn&& fn)
    {
        for (size_t i = 0; i < size(); ++i) {
            fn(data_[i]);
        }
    }

    template<typename Fn>
    void transform(Fn&& fn)
    {
        for (size_t i = 0; i < size(); ++i) {
            data_[i] = fn(data_[i]);
        }
    }

    // ========================================================================
    // Operations
    // ========================================================================

    [[nodiscard]] TensorExpr clone() const { return TensorExpr(*this); }

    [[nodiscard]] TensorExpr reshape(Shape new_shape) const
    {
        validate_shape(new_shape);
        if (shape_size(new_shape) != size()) {
            throw std::invalid_argument("Reshape size mismatch");
        }
        TensorExpr result(std::move(new_shape));
        std::copy(data_.get(), data_.get() + size(), result.data_.get());
        return result;
    }

    [[nodiscard]] TensorExpr flatten() const
    {
        return reshape(Shape{size()});
    }

    // ========================================================================
    // Reductions
    // ========================================================================

    [[nodiscard]] T sum() const noexcept
    {
        T result{0};
        for (size_t i = 0; i < size(); ++i) {
            result += data_[i];
        }
        return result;
    }

    [[nodiscard]] T mean() const noexcept
    {
        return size() > 0 ? sum() / static_cast<T>(size()) : T{0};
    }

    [[nodiscard]] T max() const
    {
        if (empty()) throw std::runtime_error("Cannot find max of empty tensor");
        return *std::max_element(data_.get(), data_.get() + size());
    }

    [[nodiscard]] T min() const
    {
        if (empty()) throw std::runtime_error("Cannot find min of empty tensor");
        return *std::min_element(data_.get(), data_.get() + size());
    }

    // ========================================================================
    // Comparison
    // ========================================================================

    [[nodiscard]] bool allclose(const TensorExpr& other, T rtol = T{1e-5}, T atol = T{1e-8}) const
    {
        if (shape_ != other.shape_) return false;
        for (size_t i = 0; i < size(); ++i) {
            const T diff = std::abs(data_[i] - other.data_[i]);
            const T tol = atol + rtol * std::abs(other.data_[i]);
            if (diff > tol) return false;
        }
        return true;
    }

    // ========================================================================
    // I/O
    // ========================================================================

    friend std::ostream& operator<<(std::ostream& os, const TensorExpr& t)
    {
        os << "TensorExpr" << shape_to_string(t.shape_) << ":\n  [";
        const size_t max_show = 10;
        for (size_t i = 0; i < std::min(t.size(), max_show); ++i) {
            if (i > 0) os << ", ";
            os << std::setprecision(4) << t[i];
        }
        if (t.size() > max_show) os << ", ...";
        os << "]\n";
        return os;
    }

private:
    Shape shape_;
    Strides strides_;
    std::unique_ptr<T[]> data_;
};

// ============================================================================
// Type Aliases
// ============================================================================

using FloatTensorExpr = TensorExpr<float>;
using DoubleTensorExpr = TensorExpr<double>;

} // namespace micrograd
