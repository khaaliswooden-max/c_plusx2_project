// filepath: src/expr/expr_ops.hpp
// Expression Operations - Lazy Evaluation for Zero Temporaries
// Phase 2: Graduate-level C++
#pragma once

#include "expr_base.hpp"
#include <cmath>
#include <algorithm>

namespace micrograd {
namespace expr {

// ============================================================================
// Binary Expression Templates
// ============================================================================

/// @brief Binary operation expression (lazy evaluation)
/// @tparam L Left operand expression type
/// @tparam R Right operand expression type
/// @tparam Op Binary operation functor
/// @tparam T Scalar element type
/// 
/// This struct stores REFERENCES to operands, not copies.
/// Computation happens only when operator[] is called.
/// 
/// @example
/// ```cpp
/// // a + b doesn't compute anything yet
/// auto expr = a + b;  // BinaryExpr storing refs to a, b
/// 
/// // Computation happens here, element by element
/// float x = expr[0];  // Returns a[0] + b[0]
/// ```
template<typename L, typename R, typename Op, typename T>
struct BinaryExpr : Expr<BinaryExpr<L, R, Op, T>, T>
{
    using value_type = T;

    const L& lhs;
    const R& rhs;
    Op op;

    BinaryExpr(const L& l, const R& r, Op operation = Op{})
        : lhs(l), rhs(r), op(operation) {}

    /// @brief Evaluate at index (lazy - computed on demand)
    [[nodiscard]] T eval(size_t i) const
    {
        return op(lhs[i], rhs[i]);
    }

    [[nodiscard]] size_t size() const noexcept { return lhs.size(); }
};

/// @brief Scalar-Expression binary operation (scalar on left)
template<typename E, typename Op, typename T>
struct ScalarLeftExpr : Expr<ScalarLeftExpr<E, Op, T>, T>
{
    using value_type = T;

    T scalar;
    const E& expr;
    Op op;

    ScalarLeftExpr(T s, const E& e, Op operation = Op{})
        : scalar(s), expr(e), op(operation) {}

    [[nodiscard]] T eval(size_t i) const
    {
        return op(scalar, expr[i]);
    }

    [[nodiscard]] size_t size() const noexcept { return expr.size(); }
};

/// @brief Expression-Scalar binary operation (scalar on right)
template<typename E, typename Op, typename T>
struct ScalarRightExpr : Expr<ScalarRightExpr<E, Op, T>, T>
{
    using value_type = T;

    const E& expr;
    T scalar;
    Op op;

    ScalarRightExpr(const E& e, T s, Op operation = Op{})
        : expr(e), scalar(s), op(operation) {}

    [[nodiscard]] T eval(size_t i) const
    {
        return op(expr[i], scalar);
    }

    [[nodiscard]] size_t size() const noexcept { return expr.size(); }
};

// ============================================================================
// Unary Expression Templates
// ============================================================================

/// @brief Unary operation expression
template<typename E, typename Op, typename T>
struct UnaryExpr : Expr<UnaryExpr<E, Op, T>, T>
{
    using value_type = T;

    const E& expr;
    Op op;

    UnaryExpr(const E& e, Op operation = Op{})
        : expr(e), op(operation) {}

    [[nodiscard]] T eval(size_t i) const
    {
        return op(expr[i]);
    }

    [[nodiscard]] size_t size() const noexcept { return expr.size(); }
};

// ============================================================================
// Operation Functors
// ============================================================================

namespace ops {

struct Add {
    template<typename T>
    [[nodiscard]] constexpr T operator()(T a, T b) const noexcept { return a + b; }
};

struct Sub {
    template<typename T>
    [[nodiscard]] constexpr T operator()(T a, T b) const noexcept { return a - b; }
};

struct Mul {
    template<typename T>
    [[nodiscard]] constexpr T operator()(T a, T b) const noexcept { return a * b; }
};

struct Div {
    template<typename T>
    [[nodiscard]] constexpr T operator()(T a, T b) const noexcept { return a / b; }
};

struct Neg {
    template<typename T>
    [[nodiscard]] constexpr T operator()(T a) const noexcept { return -a; }
};

struct Exp {
    template<typename T>
    [[nodiscard]] T operator()(T a) const { return std::exp(a); }
};

struct Log {
    template<typename T>
    [[nodiscard]] T operator()(T a) const { return std::log(a); }
};

struct Sqrt {
    template<typename T>
    [[nodiscard]] T operator()(T a) const { return std::sqrt(a); }
};

struct Abs {
    template<typename T>
    [[nodiscard]] T operator()(T a) const { return std::abs(a); }
};

struct Tanh {
    template<typename T>
    [[nodiscard]] T operator()(T a) const { return std::tanh(a); }
};

struct Sigmoid {
    template<typename T>
    [[nodiscard]] T operator()(T a) const { return T{1} / (T{1} + std::exp(-a)); }
};

struct ReLU {
    template<typename T>
    [[nodiscard]] constexpr T operator()(T a) const noexcept { return a > T{0} ? a : T{0}; }
};

} // namespace ops

// ============================================================================
// Operator Overloads (Expression + Expression)
// ============================================================================

/// @brief Addition of two expressions: expr + expr
template<typename L, typename R>
requires Expression<L> && Expression<R>
[[nodiscard]] auto operator+(const L& lhs, const R& rhs)
{
    using T = typename L::value_type;
    return BinaryExpr<L, R, ops::Add, T>(lhs, rhs);
}

/// @brief Subtraction: expr - expr
template<typename L, typename R>
requires Expression<L> && Expression<R>
[[nodiscard]] auto operator-(const L& lhs, const R& rhs)
{
    using T = typename L::value_type;
    return BinaryExpr<L, R, ops::Sub, T>(lhs, rhs);
}

/// @brief Multiplication: expr * expr
template<typename L, typename R>
requires Expression<L> && Expression<R>
[[nodiscard]] auto operator*(const L& lhs, const R& rhs)
{
    using T = typename L::value_type;
    return BinaryExpr<L, R, ops::Mul, T>(lhs, rhs);
}

/// @brief Division: expr / expr
template<typename L, typename R>
requires Expression<L> && Expression<R>
[[nodiscard]] auto operator/(const L& lhs, const R& rhs)
{
    using T = typename L::value_type;
    return BinaryExpr<L, R, ops::Div, T>(lhs, rhs);
}

// ============================================================================
// Operator Overloads (Expression + Scalar)
// ============================================================================

/// @brief expr + scalar
template<typename E, typename S>
requires Expression<E> && Scalar<S>
[[nodiscard]] auto operator+(const E& expr, S scalar)
{
    using T = typename E::value_type;
    return ScalarRightExpr<E, ops::Add, T>(expr, static_cast<T>(scalar));
}

/// @brief scalar + expr
template<typename S, typename E>
requires Scalar<S> && Expression<E>
[[nodiscard]] auto operator+(S scalar, const E& expr)
{
    using T = typename E::value_type;
    return ScalarLeftExpr<E, ops::Add, T>(static_cast<T>(scalar), expr);
}

/// @brief expr - scalar
template<typename E, typename S>
requires Expression<E> && Scalar<S>
[[nodiscard]] auto operator-(const E& expr, S scalar)
{
    using T = typename E::value_type;
    return ScalarRightExpr<E, ops::Sub, T>(expr, static_cast<T>(scalar));
}

/// @brief scalar - expr
template<typename S, typename E>
requires Scalar<S> && Expression<E>
[[nodiscard]] auto operator-(S scalar, const E& expr)
{
    using T = typename E::value_type;
    return ScalarLeftExpr<E, ops::Sub, T>(static_cast<T>(scalar), expr);
}

/// @brief expr * scalar
template<typename E, typename S>
requires Expression<E> && Scalar<S>
[[nodiscard]] auto operator*(const E& expr, S scalar)
{
    using T = typename E::value_type;
    return ScalarRightExpr<E, ops::Mul, T>(expr, static_cast<T>(scalar));
}

/// @brief scalar * expr
template<typename S, typename E>
requires Scalar<S> && Expression<E>
[[nodiscard]] auto operator*(S scalar, const E& expr)
{
    using T = typename E::value_type;
    return ScalarLeftExpr<E, ops::Mul, T>(static_cast<T>(scalar), expr);
}

/// @brief expr / scalar
template<typename E, typename S>
requires Expression<E> && Scalar<S>
[[nodiscard]] auto operator/(const E& expr, S scalar)
{
    using T = typename E::value_type;
    return ScalarRightExpr<E, ops::Div, T>(expr, static_cast<T>(scalar));
}

/// @brief scalar / expr
template<typename S, typename E>
requires Scalar<S> && Expression<E>
[[nodiscard]] auto operator/(S scalar, const E& expr)
{
    using T = typename E::value_type;
    return ScalarLeftExpr<E, ops::Div, T>(static_cast<T>(scalar), expr);
}

// ============================================================================
// Unary Operators
// ============================================================================

/// @brief Negation: -expr
template<typename E>
requires Expression<E>
[[nodiscard]] auto operator-(const E& expr)
{
    using T = typename E::value_type;
    return UnaryExpr<E, ops::Neg, T>(expr);
}

// ============================================================================
// Math Functions (Expression -> Expression)
// ============================================================================

/// @brief Element-wise exp
template<typename E>
requires Expression<E>
[[nodiscard]] auto exp(const E& expr)
{
    using T = typename E::value_type;
    return UnaryExpr<E, ops::Exp, T>(expr);
}

/// @brief Element-wise log
template<typename E>
requires Expression<E>
[[nodiscard]] auto log(const E& expr)
{
    using T = typename E::value_type;
    return UnaryExpr<E, ops::Log, T>(expr);
}

/// @brief Element-wise sqrt
template<typename E>
requires Expression<E>
[[nodiscard]] auto sqrt(const E& expr)
{
    using T = typename E::value_type;
    return UnaryExpr<E, ops::Sqrt, T>(expr);
}

/// @brief Element-wise abs
template<typename E>
requires Expression<E>
[[nodiscard]] auto abs(const E& expr)
{
    using T = typename E::value_type;
    return UnaryExpr<E, ops::Abs, T>(expr);
}

/// @brief Element-wise tanh
template<typename E>
requires Expression<E>
[[nodiscard]] auto tanh(const E& expr)
{
    using T = typename E::value_type;
    return UnaryExpr<E, ops::Tanh, T>(expr);
}

/// @brief Element-wise sigmoid
template<typename E>
requires Expression<E>
[[nodiscard]] auto sigmoid(const E& expr)
{
    using T = typename E::value_type;
    return UnaryExpr<E, ops::Sigmoid, T>(expr);
}

/// @brief Element-wise ReLU
template<typename E>
requires Expression<E>
[[nodiscard]] auto relu(const E& expr)
{
    using T = typename E::value_type;
    return UnaryExpr<E, ops::ReLU, T>(expr);
}

} // namespace expr
} // namespace micrograd
