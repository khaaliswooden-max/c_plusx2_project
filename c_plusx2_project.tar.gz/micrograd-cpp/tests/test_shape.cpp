// filepath: tests/test_shape.cpp
// Shape utilities unit tests
#include <gtest/gtest.h>
#include "shape.hpp"

using namespace micrograd;

// ============================================================================
// shape_size Tests
// ============================================================================

TEST(ShapeTest, ShapeSize_EmptyShape_ReturnsZero)
{
    Shape s;
    EXPECT_EQ(shape_size(s), 0);
}

TEST(ShapeTest, ShapeSize_1D_ReturnsCorrect)
{
    EXPECT_EQ(shape_size({5}), 5);
    EXPECT_EQ(shape_size({100}), 100);
}

TEST(ShapeTest, ShapeSize_2D_ReturnsProduct)
{
    EXPECT_EQ(shape_size({2, 3}), 6);
    EXPECT_EQ(shape_size({10, 10}), 100);
}

TEST(ShapeTest, ShapeSize_ND_ReturnsProduct)
{
    EXPECT_EQ(shape_size({2, 3, 4}), 24);
    EXPECT_EQ(shape_size({2, 2, 2, 2}), 16);
}

// ============================================================================
// shape_strides Tests
// ============================================================================

TEST(ShapeTest, ShapeStrides_1D_ReturnsOne)
{
    auto strides = shape_strides({5});
    ASSERT_EQ(strides.size(), 1);
    EXPECT_EQ(strides[0], 1);
}

TEST(ShapeTest, ShapeStrides_2D_RowMajor)
{
    auto strides = shape_strides({2, 3});
    ASSERT_EQ(strides.size(), 2);
    EXPECT_EQ(strides[0], 3);  // Jump 3 to move to next row
    EXPECT_EQ(strides[1], 1);  // Jump 1 to move to next column
}

TEST(ShapeTest, ShapeStrides_3D_RowMajor)
{
    auto strides = shape_strides({2, 3, 4});
    ASSERT_EQ(strides.size(), 3);
    EXPECT_EQ(strides[0], 12);  // 3*4 to move to next "plane"
    EXPECT_EQ(strides[1], 4);   // 4 to move to next row
    EXPECT_EQ(strides[2], 1);   // 1 to move to next column
}

// ============================================================================
// shape_to_string Tests
// ============================================================================

TEST(ShapeTest, ShapeToString_Empty)
{
    EXPECT_EQ(shape_to_string({}), "()");
}

TEST(ShapeTest, ShapeToString_1D)
{
    EXPECT_EQ(shape_to_string({5}), "(5)");
}

TEST(ShapeTest, ShapeToString_2D)
{
    EXPECT_EQ(shape_to_string({2, 3}), "(2, 3)");
}

TEST(ShapeTest, ShapeToString_3D)
{
    EXPECT_EQ(shape_to_string({2, 3, 4}), "(2, 3, 4)");
}

// ============================================================================
// shapes_equal Tests
// ============================================================================

TEST(ShapeTest, ShapesEqual_Same_ReturnsTrue)
{
    EXPECT_TRUE(shapes_equal({2, 3}, {2, 3}));
    EXPECT_TRUE(shapes_equal({}, {}));
}

TEST(ShapeTest, ShapesEqual_Different_ReturnsFalse)
{
    EXPECT_FALSE(shapes_equal({2, 3}, {3, 2}));
    EXPECT_FALSE(shapes_equal({2, 3}, {2, 3, 1}));
}

// ============================================================================
// Broadcasting Tests
// ============================================================================

TEST(ShapeTest, ShapesBroadcastable_Same_ReturnsTrue)
{
    EXPECT_TRUE(shapes_broadcastable({2, 3}, {2, 3}));
}

TEST(ShapeTest, ShapesBroadcastable_ScalarBroadcast_ReturnsTrue)
{
    EXPECT_TRUE(shapes_broadcastable({2, 3}, {1}));
    EXPECT_TRUE(shapes_broadcastable({2, 3}, {3}));
    EXPECT_TRUE(shapes_broadcastable({2, 3}, {1, 3}));
    EXPECT_TRUE(shapes_broadcastable({2, 3}, {2, 1}));
}

TEST(ShapeTest, ShapesBroadcastable_DifferentRank_ReturnsTrue)
{
    EXPECT_TRUE(shapes_broadcastable({2, 3, 4}, {3, 4}));
    EXPECT_TRUE(shapes_broadcastable({2, 3, 4}, {4}));
}

TEST(ShapeTest, ShapesBroadcastable_Incompatible_ReturnsFalse)
{
    EXPECT_FALSE(shapes_broadcastable({2, 3}, {2, 4}));
    EXPECT_FALSE(shapes_broadcastable({2, 3}, {3, 3}));
}

TEST(ShapeTest, BroadcastShapes_Same_ReturnsSame)
{
    auto result = broadcast_shapes({2, 3}, {2, 3});
    EXPECT_EQ(result, Shape({2, 3}));
}

TEST(ShapeTest, BroadcastShapes_ScalarBroadcast)
{
    auto result = broadcast_shapes({2, 3}, {1});
    EXPECT_EQ(result, Shape({2, 3}));
}

TEST(ShapeTest, BroadcastShapes_DifferentRank)
{
    auto result = broadcast_shapes({2, 3, 4}, {3, 4});
    EXPECT_EQ(result, Shape({2, 3, 4}));
}

TEST(ShapeTest, BroadcastShapes_Incompatible_Throws)
{
    EXPECT_THROW(broadcast_shapes({2, 3}, {2, 4}), std::invalid_argument);
}

// ============================================================================
// validate_shape Tests
// ============================================================================

TEST(ShapeTest, ValidateShape_Valid_NoThrow)
{
    EXPECT_NO_THROW(validate_shape({2, 3}));
    EXPECT_NO_THROW(validate_shape({1}));
}

TEST(ShapeTest, ValidateShape_Empty_Throws)
{
    EXPECT_THROW(validate_shape({}), std::invalid_argument);
}

TEST(ShapeTest, ValidateShape_Zero_Throws)
{
    EXPECT_THROW(validate_shape({2, 0, 3}), std::invalid_argument);
}

// ============================================================================
// Index Conversion Tests
// ============================================================================

TEST(ShapeTest, UnravelIndex_1D)
{
    auto indices = unravel_index(3, {5});
    ASSERT_EQ(indices.size(), 1);
    EXPECT_EQ(indices[0], 3);
}

TEST(ShapeTest, UnravelIndex_2D)
{
    // Shape (2, 3): flat index 4 = row 1, col 1
    auto indices = unravel_index(4, {2, 3});
    ASSERT_EQ(indices.size(), 2);
    EXPECT_EQ(indices[0], 1);  // row
    EXPECT_EQ(indices[1], 1);  // col
}

TEST(ShapeTest, UnravelIndex_3D)
{
    // Shape (2, 3, 4): flat index 17 = [1, 0, 1]
    auto indices = unravel_index(17, {2, 3, 4});
    EXPECT_EQ(indices[0], 1);
    EXPECT_EQ(indices[1], 0);
    EXPECT_EQ(indices[2], 1);
}

TEST(ShapeTest, RavelIndex_1D)
{
    EXPECT_EQ(ravel_index({3}, {5}), 3);
}

TEST(ShapeTest, RavelIndex_2D)
{
    EXPECT_EQ(ravel_index({1, 1}, {2, 3}), 4);
    EXPECT_EQ(ravel_index({0, 0}, {2, 3}), 0);
    EXPECT_EQ(ravel_index({1, 2}, {2, 3}), 5);
}

TEST(ShapeTest, RavelUnravel_RoundTrip)
{
    Shape shape = {2, 3, 4};
    for (size_t i = 0; i < shape_size(shape); ++i) {
        auto indices = unravel_index(i, shape);
        size_t flat = ravel_index(indices, shape);
        EXPECT_EQ(flat, i) << "Failed at index " << i;
    }
}
