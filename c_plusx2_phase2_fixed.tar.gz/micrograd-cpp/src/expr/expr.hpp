// filepath: src/expr/expr.hpp
// Expression Templates - Convenience Header
// Phase 2: Zero-allocation lazy evaluation
#pragma once

#include "expr_base.hpp"
#include "expr_ops.hpp"
#include "expr_tensor.hpp"

/// @file expr.hpp
/// @brief Include this for expression template support
/// 
/// ## What are Expression Templates?
/// 
/// A technique to eliminate temporary allocations in chained operations.
/// 
/// ### Without expression templates (Phase 1):
/// ```cpp
/// Tensor c = a + b + c;
/// // Creates: temp1 = a + b   (allocation!)
/// //          temp2 = temp1 + c (allocation!)
/// //          c = temp2
/// // Result: 2 unnecessary allocations
/// ```
/// 
/// ### With expression templates (Phase 2):
/// ```cpp
/// TensorExpr c = a + b + c;
/// // Creates: AddExpr<AddExpr<a, b>, c> (just types, no allocation)
/// //          c = expr (ONE allocation, ONE loop)
/// // Result: 0 unnecessary allocations
/// ```
/// 
/// ## How It Works
/// 
/// 1. **Lazy Evaluation**: `a + b` returns a BinaryExpr type, not a Tensor
/// 2. **Expression Tree**: Chained ops build a type tree at compile time
/// 3. **Single Materialization**: Assignment to Tensor evaluates everything
/// 4. **CRTP**: Provides common interface without virtual function overhead
/// 
/// ## Usage
/// 
/// ```cpp
/// #include <expr/expr.hpp>
/// using namespace micrograd;
/// 
/// // Create tensors
/// TensorExpr<float> a = TensorExpr<float>::randn({1000000});
/// TensorExpr<float> b = TensorExpr<float>::randn({1000000});
/// TensorExpr<float> c = TensorExpr<float>::randn({1000000});
/// 
/// // This builds an expression tree (no computation yet)
/// auto expr = (a + b) * c - 2.0f;
/// 
/// // Computation happens in single pass
/// TensorExpr<float> result = expr;
/// 
/// // Or evaluate directly
/// for (size_t i = 0; i < 10; ++i) {
///     std::cout << expr[i] << "\n";  // Computes on-demand
/// }
/// ```
/// 
/// ## Performance
/// 
/// For `a + b + c` with 1M elements:
/// - Phase 1: ~3 allocations, ~3 passes over data
/// - Phase 2: ~1 allocation, ~1 pass over data
/// - Speedup: ~2-3x for memory-bound operations
/// 
/// ## Verification
/// 
/// Check assembly to verify no temporaries:
/// ```bash
/// objdump -d -C ./build/test_expr | grep -A 50 "test_chain"
/// ```
/// 
/// Look for:
/// - Single loop (one `jne` back to loop start)
/// - No `operator new` calls inside loop
/// - Fused add/mul instructions

namespace micrograd {
namespace expr {
    // All types already in expr namespace
} // namespace expr
} // namespace micrograd
