// filepath: src/expr/expr_base.hpp
// Expression Template Base - CRTP Pattern for Zero-Cost Abstractions
// Phase 2: Graduate-level C++ (Lazy Evaluation, Static Polymorphism)
#pragma once

#include <cstddef>
#include <type_traits>

namespace micrograd {
namespace expr {

// ============================================================================
// CRTP Base Class
// ============================================================================

/// @brief Base class for all expression templates using CRTP
/// @tparam Derived The derived expression type (e.g., AddExpr, MulExpr)
/// @tparam T The scalar element type (float, double)
/// 
/// CRTP (Curiously Recurring Template Pattern) enables:
/// - Static polymorphism (no virtual function overhead)
/// - Compile-time method dispatch
/// - Zero-cost abstractions
/// 
/// How it works:
/// 1. Derived class inherits from Expr<Derived, T>
/// 2. Base class casts `this` to Derived& via static_cast
/// 3. Compiler resolves calls at compile time (no vtable)
/// 
/// @example
/// ```cpp
/// template<typename L, typename R, typename T>
/// struct AddExpr : Expr<AddExpr<L, R, T>, T> {
///     T operator[](size_t i) const { return lhs[i] + rhs[i]; }
/// };
/// ```
template<typename Derived, typename T>
struct Expr
{
    using value_type = T;

    /// @brief Access the derived class (CRTP downcast)
    /// @return Const reference to derived type
    [[nodiscard]] const Derived& self() const noexcept
    {
        return static_cast<const Derived&>(*this);
    }

    /// @brief Access element at index (delegates to derived)
    /// @param i Flat index
    /// @return Element value at index
    [[nodiscard]] T operator[](size_t i) const
    {
        return self().eval(i);
    }

    /// @brief Get total number of elements
    [[nodiscard]] size_t size() const noexcept
    {
        return self().size();
    }
};

// ============================================================================
// Type Traits for Expression Detection
// ============================================================================

namespace detail {

/// @brief Primary template - not an expression
template<typename T, typename = void>
struct is_expression_impl : std::false_type {};

/// @brief Specialization - has value_type, size(), and eval() -> is expression
/// Note: Requires eval() to distinguish from Phase 1 Tensor
template<typename T>
struct is_expression_impl<T, std::void_t<
    typename T::value_type,
    decltype(std::declval<const T&>().size()),
    decltype(std::declval<const T&>().eval(std::declval<size_t>()))
>> : std::true_type {};

} // namespace detail

/// @brief Type trait to check if T is an expression-like type
template<typename T>
struct is_expression : detail::is_expression_impl<std::decay_t<T>> {};

/// @brief Helper variable template
template<typename T>
inline constexpr bool is_expression_v = is_expression<T>::value;

// ============================================================================
// Concepts (C++20)
// ============================================================================

/// @brief Concept for expression types (has eval(), size(), value_type)
/// Note: Requires eval() to distinguish from Phase 1 Tensor (which has [] but not eval())
template<typename E>
concept Expression = requires(const E& e, size_t i) {
    typename E::value_type;
    { e.eval(i) } -> std::convertible_to<typename E::value_type>;
    { e.size() } -> std::same_as<size_t>;
};

/// @brief Concept for scalar types compatible with expressions
template<typename T>
concept Scalar = std::is_arithmetic_v<T>;

} // namespace expr
} // namespace micrograd
